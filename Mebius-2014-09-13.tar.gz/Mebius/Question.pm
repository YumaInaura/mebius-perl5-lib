

use Mebius::Question::Basic;

1;

