
use strict;
package Mebius::SNS::Profile;
use Mebius::Question;


#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub my_question{


}





1;
