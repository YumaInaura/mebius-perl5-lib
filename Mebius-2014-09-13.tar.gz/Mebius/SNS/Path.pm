
use strict;
package Mebius::SNS::Path;
use base qw(Mebius::SNS::URL);

1;
