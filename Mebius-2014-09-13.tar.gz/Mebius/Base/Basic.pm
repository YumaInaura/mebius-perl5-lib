
use strict;
use Mebius::PageBack;
package Mebius::Base::Basic;

#-----------------------------------------------------------
# オブジェクト関連付け
#-----------------------------------------------------------
sub new {
my $self = shift;
bless {} , $self;
}

#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub access_judge{

my $self = shift;
my $main_limited_package_name = $self->main_limited_package_name();
my($flag);

	if($ENV{'SCRIPT_NAME'} =~ m!/${main_limited_package_name}\.cgi!){
		$flag = 1;
	} else {
		0;
	}

$flag;

}


#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub param_to_some_report_data{

my $self = shift;
my $key = shift;
my $objects = $self->objects_for_report();
my($report_data,$i);

my $keys = keys %{$objects};
#	if(Mebius::alocal_judge()){ Mebius::Debug::Error(qq($keys)); }


	foreach my $object_name ( keys %{$objects} ){

		my $object = $objects->{$object_name};
		$i++;

			if( $report_data = $object->param_to_report_data($key)){
				last;
			}

	}

$report_data;

}

#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub multi_data_to_each_url{

my $self = shift;
my $data = shift;
my $relay_use = shift;
my $use = shift;
my $link;
my $all_objects = $self->limited_all_objects();
my $main_limited_package_name = $self->main_limited_package_name();

	if($data->{'content_typeA'} ne $main_limited_package_name){
		return();
	}

	foreach my $object_name ( keys %{$all_objects} ){

		my $object = $all_objects->{$object_name};

			if(!$object->content_type_is_on_this_package($data)){
				next;
			}

		my $adjusted_data = $object->content_target_to_normal_data($data);

			if($use->{'Move'} || $use->{'WithMove'}){

					if( $link = $object->data_to_url_with_move($adjusted_data,$relay_use)){
						last;
					} else {
						0;
					}

			} elsif($use->{'History'}){

					if( $link = $object->data_to_url_with_response_history($adjusted_data,$relay_use)){

						last;
					} else {
						0;
					}


			} else {

					if( $link = $object->data_to_url($adjusted_data,$relay_use)){
						last;
					} else {
						0;
					}

			}
	}


$link;

}


#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub multi_data_to_each_url_with_move{

my $self = shift;
my $data = shift;
my $relay_use = shift;

$self->multi_data_to_each_url($data,$relay_use,{ WithMove => 1 });

}
#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub multi_data_to_each_url_with_response_history{

my $self = shift;
my $data = shift;
my $relay_use = shift;

$self->multi_data_to_each_url($data,$relay_use,{ History => 1 });

}

#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub print_html{

my $self = shift;
my $html_body = shift;
my $use = shift;
my $init = $self->init();
my $template = new Mebius::Template;
my $html = new Mebius::HTML;
my($print,%overwrite_use);

my $adjusted_use = $template->adjust_header_use($use,$init);

	if($use->{'h1'}){
		$print .= $html->tag("h1",$use->{'h1'},{ Debug => 0 });
	}

$print .= $html_body;

my %final_use = (%{$adjusted_use},%overwrite_use);

Mebius::Template::gzip_and_print_all(\%final_use,$print);

exit;

}




#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub query_to_control_and_redirect{

my $self = shift;
my $page_back = new Mebius::PageBack;

$self->query_to_control();

$page_back->redirect() || $self->print_html("実行しました。");

exit;

}

#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub top_page_link{

my $self = shift;
my $init = $self->init();
my $html = new Mebius::HTML;

my $url = $init->{'base_url'} || return();
my $title = $init->{'short_title'} || $init->{'title'} || $init->{'site_title'} || return();

my $link = $html->href($url,$title);

$link;


}


#-----------------------------------------------------------
# 
#-----------------------------------------------------------
#sub multi_data_to_each_link{

#my $self = shift;
#my $data = shift;
#my $use = shift;
#my $link;
#my $post = $self->post_object();

#my $main_limited_package_name = $self->main_limited_package_name();

#	if($data->{'content_typeA'} ne $main_limited_package_name){
#		return();
#	}

#	if( $link = $post->multi_data_to_link($data,$use)){

#	} else {
#		0;
#	}

#$link;

#}

1;
