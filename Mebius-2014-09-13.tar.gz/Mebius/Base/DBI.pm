
use strict;
use Mebius::DBI;
package Mebius::Base::DBI;

#-----------------------------------------------------------
# 継承用 - レコードの更新
#-----------------------------------------------------------
sub update_main_table{

my $self = shift;
my $update = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $dbi = new Mebius::DBI;
my($table_name) = $self->main_table_name() || die("Can't decide main table name.");
my($where,$debug_flag);

	#if(Mebius::alocal_judge() && $table_name eq "history"){
	#	$debug_flag = 1;
		#Mebius::Debug::print_hash($update);
	#}

my($columns) = $self->main_table_column();
my($adjusted_set) = $dbi->adjust_set($update,$columns,{ Debug => $debug_flag });

	#if(Mebius::alocal_judge() && $table_name eq "history"){ Mebius::Debug::print_hash($adjusted_set); }

my $primary_key = $self->get_primary_key_from_main_table();

	if($primary_key && $dbi->column_name_format_error($primary_key)){ die(""); }

	if(ref $use->{'WHERE'} eq "HASH"){
		$where = "WHERE " . $dbi->hash_to_where($use->{'WHERE'},$use);
	} elsif($primary_key) {
		$where = qq(WHERE $primary_key=').$dbi->escape($update->{$primary_key}).q(');
	}

	if($use->{'WITH_MEMORY_TABLE'}){
		$dbi->update_with_memory_table(undef,$table_name,$adjusted_set,$where,$use);
	} else {
		$dbi->update(undef,$table_name,$adjusted_set,$where,$use);
	}

}

#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub delete_record_from_main_table{

my $self = shift;
my $where = shift;
my $use = shift;
my $dbi = new Mebius::DBI;
my $table_name = $self->main_table_name() || die;

$dbi->delete_record(undef,$table_name,$where,$use);

}



#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub delete_old_records_from_main_table{

my $self = shift;
my $border_time = shift;
my $dbi = new Mebius::DBI;

my $table_name = $self->main_table_name();
$dbi->delete_old_records(undef,$table_name,$border_time);

}

#-----------------------------------------------------------
# 継承用 - メモリテーブル名の取得
#-----------------------------------------------------------
sub main_memory_table_name{

my $self = shift;
my $dbi = new Mebius::DBI;

my($table_name) = $self->main_table_name() || die("Can't decide main table name.");
my($memory_table_name) = $dbi->table_name_to_memory_table_name($table_name);

$memory_table_name;

}


#-----------------------------------------------------------
# 継承用 - テーブル作成
#-----------------------------------------------------------
sub create_main_table_with_memory{

my $self = shift;
$self->create_main_table({ WITH_MEMORY_TABLE => 1 });

}

#-----------------------------------------------------------
# 継承用  - ファイルテーブルからのレコードの取得
#-----------------------------------------------------------
sub fetchrow_main_table{

my $self = shift;
my $dbi_query = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $dbi = new Mebius::DBI;

my $table_name = $self->main_table_name();
my $main_table_column = $self->main_table_column();
my $relay_use = Mebius::Operate->overwrite_hash($use,{ table_name => $table_name , table_column => $main_table_column , Bind => 1 });

$dbi->fetchrow($dbi_query,$relay_use);

}

#-----------------------------------------------------------
# 継承用  - ファイルテーブルからのレコードの取得
#-----------------------------------------------------------
sub fetchrow_on_hash_main_memory_table{

my $self = shift;
my $dbi_query = shift;
my $unique_key = shift;
my $use = shift;
my $operate = new Mebius::Operate;
my $dbi = new Mebius::DBI;

my $hand_use = $operate->overwrite_hash($use,{ MEMORY_TABLE => 1 });
$dbi->fetchrow_on_hash_main_table($dbi_query,$unique_key,$hand_use);

}



#-----------------------------------------------------------
# 継承用  - ファイルテーブルからのレコードの取得
#-----------------------------------------------------------
sub fetchrow_on_hash_main_table{

my $self = shift;
my $dbi_query = shift;
my $unique_key = shift;
my $use = shift;
my $dbi = new Mebius::DBI;
my($table_name);

	# テーブル名を定義
	if($use->{'MEMORY_TABLE'}){
		$table_name = $self->main_memory_table_name() || die("Can't decide main table name.");
	} else {
		$table_name = $self->main_table_name() || die("Can't decide main table name.");
	}

	if($dbi->table_name_format_error($table_name)){ die; }

	# ユニークキーが指定されていない場合は、プライマリーキーをキーに ( 主にこちらの処理をメインに使っているはず )
	if($unique_key eq ""){
		$unique_key = $self->get_primary_key_from_main_table();
	}


my %adjusted_use = (%{$use},( table_name => $table_name , Bind => 1 ) );
$dbi->fetchrow_on_hash($dbi_query,$unique_key,\%adjusted_use);

}

#-----------------------------------------------------------
# 継承用 - テーブル作成
#-----------------------------------------------------------
sub create_main_table{

my $self = shift;
my $use = shift || {};
my $dbi = new Mebius::DBI;

my($table_name) = $self->main_table_name() || die("Can't decide main table name.");

# データ定義
my($set) = $self->main_table_column();
my $main_table_init = $self->main_table_init();
my $table_use = Mebius::Operate->overwrite_hash($use,$main_table_init);

	if($use->{'WITH_MEMORY_TABLE'}){
		$dbi->create_table_with_memory(undef,$table_name,$set);
	} else {
		$dbi->create_table($table_use,undef,$table_name,$set);
	}

}

#-----------------------------------------------------------
# 継承用 - レコードの更新
#-----------------------------------------------------------
sub update_or_insert_main_table_with_memory{
my $self = shift;
my $update = shift;
$self->update_or_insert_main_table($update,{ WITH_MEMORY_TABLE => 1 });
}

#-----------------------------------------------------------
# 継承用 - レコードの挿入または更新 
#-----------------------------------------------------------
sub update_or_insert_main_table{

my $self = shift;
my $update = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $dbi = new Mebius::DBI;
my($table_name) = $self->main_table_name() || die("Can't decide main table name.");
my(%hand_use,%insert_only);

my($columns) = $self->main_table_column();
my($adjusted_set) = $dbi->adjust_set($update,$columns);

my %insert_only = %{$dbi->adjust_set({ create_time => time } , $columns)};

	if( my $add_hash = $use->{'insert_only'} ){
		%insert_only = (%insert_only,%{$add_hash});
	}

$hand_use{'insert_only'} = \%insert_only;

my $primary_key = $self->get_primary_key_from_main_table();

	if($dbi->column_name_format_error($primary_key)){ die(""); }

	if($use->{'WITH_MEMORY_TABLE'}){
		$dbi->update_or_insert_with_memory_table(undef,$table_name,$adjusted_set,$primary_key);
	} else {


		$dbi->update_or_insert(undef,$table_name,$adjusted_set,$primary_key,\%hand_use);
	}

$adjusted_set;

}

#-----------------------------------------------------------
# 継承用 - レコードの更新
#-----------------------------------------------------------
sub insert_main_table{

my $self = shift;
my $insert = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $dbi = new Mebius::DBI;
my($table_name) = $self->main_table_name() || die("Can't decide main table name.");
my($adjusted_set);

my($columns) = $self->main_table_column();

	if(ref $insert eq "HASH"){
		$insert->{'create_time'} = time;
		($adjusted_set) = $dbi->adjust_set($insert,$columns);
	} else {
		$adjusted_set = $insert;
	}

	if($use->{'WITH_MEMORY_TABLE'}){
		$dbi->insert_with_memory_table(undef,$table_name,$adjusted_set,$use);
	} else {
		$dbi->insert(undef,$table_name,$adjusted_set,$use);
	}

$adjusted_set;

}



#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub refresh_main_table{
my $self = shift;
$self->refresh_all_column_from_main_table(@_);
}


#-----------------------------------------------------------
# テーブルのすべての設定を更新する
#-----------------------------------------------------------
sub refresh_all_column_from_main_table{

my $self = shift;
my $dbi = new Mebius::DBI;
my $column = $self->main_table_column();
my($dbh) = $dbi->connect();
my $main_table_name = $self->main_table_name();

	foreach my $column_name ( keys %{$column} ){

		my $setting = $column->{$column_name};

		my $column_setting_query =  $dbi->column_setting_to_query($column_name,$setting);

		# カラムの追加
		my $add_query = "ALTER TABLE `$main_table_name` ADD ($column_setting_query)";
		$dbh->do($add_query);

		# カラム設定の変更
		my $modify_query = "ALTER TABLE `$main_table_name` MODIFY $column_setting_query";
		$dbh->do($modify_query);

		# インデックスを貼る
		if($setting->{'INDEX'}){
			my $index_name = $dbi->column_name_to_index_name($column_name);
			my $index_query = "ALTER TABLE `$main_table_name` ADD INDEX $index_name($column_name)";
			$dbh->do($index_query);
		}

	}

}
#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub get_relation_key_from_main_table{

my $self = shift;
my $dbi = new Mebius::DBI;

my $main_table_column = $self->main_table_column();

my $primary_key = $dbi->get_some_key_from_column_setting($main_table_column,"Relation");

$primary_key;

}


#-----------------------------------------------------------
# 
#-----------------------------------------------------------
sub get_primary_key_from_main_table{

my $self = shift;
my $dbi = new Mebius::DBI;

my $main_table_column = $self->main_table_column();

my $primary_key = $dbi->get_some_key_from_column_setting($main_table_column,"PRIMARY");

$primary_key;

}

#-----------------------------------------------------------
# 継承用
#-----------------------------------------------------------
sub main_table_init{ {}; }

1;
