
use strict;
package Mebius::Saying::Admin;
use base qw(Mebius::Base::DBI);


1;
