
use strict;
package Mebius::Saying::Reaction;
use base qw(Mebius::Base::DBI);


1;
