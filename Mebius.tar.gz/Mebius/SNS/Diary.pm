
use strict;
package Mebius::SNS::Diary;
use Mebius::Export;

#-----------------------------------------------------------
# クエリからSNS日記を操作
#-----------------------------------------------------------
sub query_to_control{

my(%control);
my($param) = Mebius::query_single_param();

	foreach my $key ( keys %$param ){

			# レスの操作
			if($key =~ /^sns_diary_res_([0-9a-z]+)_(\d+)_(\d)$/){
					$control{$1}{$2}{'res'}{$3} = $param->{$key};

			} elsif ($key =~ /^sns_diary_([0-9a-z]+)_(\d+)$/){
					$control{$1}{$2}{'thread'} = $param->{$key};
			}

	}

my($controled) = control(\%control);

# 違反報告ファイルを更新
Mebius::Report::bbs_report_file({ file_type => "sns_diary" , Control => 1 , Renew => 1 , line_control => \%control });

$controled;

}


#-----------------------------------------------------------
# SNS 日記を操作
#-----------------------------------------------------------
sub control{

my($control) = @_;
my($indexline,$pastline,$flag,$top1,$yearfile,$monthfile,$newkey);
my(@control_reses,%self);
my($my_account) = Mebius::my_account();
my($basic_init) = Mebius::basic_init();

	# ● 全てのアカウントを展開
	foreach my $account ( keys %$control ){ 

		my(%controled_thread,%controled_thread_year_month);

		# 汚染チェック１
		if(Mebius::Auth::account_name_error($account)){ next(); }

		# 権限チェック
		if(!$my_account->{'admin_flag'} && $my_account->{'id'} ne $account){ next; }

		# プロフィールを開く
		Mebius::Auth::File("Option Get-hash",$account);

		# ロック開始
		Mebius::lock("auth$account");

		# 最後に操作したアカウントを覚えておく
		push @{$self{'controled_account'}} , $account;

			# ▼全ての日記を展開
			foreach my $diary_number ( keys %{$control->{$account}} ){ 

				my(@renew_line,$new_key,$diary_handler);

				# 使いやすいようにするための代入
				my $res_control = $control->{$account}->{$diary_number}->{'res'};
				my $thread_control = $control->{$account}->{$diary_number}->{'thread'};

					# 汚染チェック２
					if($diary_number eq "" || $diary_number =~ /[^0-9]/){ next; }

				# ディレクトリ定義
				my($account_directory) = Mebius::Auth::account_directory($account) || next;


				# 日記単体ファイルを開く
				my $open = open($diary_handler,"<","${account_directory}diary/${account}_diary_${diary_number}.cgi") || next;

				flock($diary_handler,1);

				# トップデータを分解
				chomp($top1 = <$diary_handler>);
				my($key,$num,$sub,$res,$dates,$newtime,$restime,$control_data,@top_other_data) = split(/<>/,$top1);
				my($year,$month,$day,$hour,$min) = split(/,/,$dates);

					# ●スレッドの操作
					# 削除済みの場合は、管理者でなければ操作できないように
					if( ($key eq "4" || $key eq "2") && !$my_account->{'admin_flag'}){
						0;

					# ▼ロックする場合
					} elsif($thread_control eq "lock"){
						$new_key = $key = "0";
						$flag = 1;
						$self{'thread_delete_flag'} = 1;

					# ▼ロック解除する場合
					} elsif($thread_control eq "unlock" && $key eq "0"){
						$new_key = $key = "1";
						$flag = 1;
						$self{'thread_delete_flag'} = 1;

					# ▼削除する場合
					}	elsif($thread_control eq "delete" || $thread_control eq "penalty"){

						#$type .= qq( Delete-diary);
							if($my_account->{'admin_flag'}){ $new_key = $key = "4"; } else { $new_key = $key = "2"; }
						$flag = 1;

						# マイメビの新着一覧から削除
						Mebius::Auth::FriendIndex("Delete-diary",$account,$diary_number);

						# 全メンバーの新着日記から削除
						Mebius::Auth::all_members_diary("Delete-diary New-file Renew",$account,$diary_number);
						Mebius::Auth::all_members_diary("Delete-diary Alert-file Renew",$account,$diary_number);

							# ペナルティをつける
							if($thread_control eq "penalty"){
								Mebius::Authpenalty("Penalty",$account,"","SNSの日記 - $sub","$basic_init->{'auth_url'}$account/d-$diary_number");
								Mebius::AuthPenaltyOption("Penalty",$account,3*24*60*60);
							}

						$self{'thread_delete_flag'} = 1;

					# ▼復活させる場合
					} elsif($thread_control eq "revive"){
						#$type .= qq( Revive-diary);
						$new_key = $key = "1";
						$flag = 1;

						# 全メンバーの新着日記に復活
						Mebius::Auth::all_members_diary("Revive-diary New-file Renew",$account,$diary_number);
						Mebius::Auth::all_members_diary("Revive-diary Alert-file Renew",$account,$diary_number);

						# ペナルティの解除
						Mebius::Authpenalty("Repair",$account);
						Mebius::AuthPenaltyOption("Penalty",$account,-3*24*60*60);

					}

					# あとでインデックスを一斉更新するための処理
					if($new_key ne ""){
						$controled_thread{$diary_number}{'key'} = $new_key;
						$controled_thread_year_month{$year}{$month}{$diary_number}{'key'} = $new_key;
					}


					# ファイルを展開する
					while(<$diary_handler>){

						# 局所化
						my($res_control_type);

						# 行を分解
						chomp;
						my($key,$num,$account,$name,$trip,$id,$comment,$dates,$restime,$resxip,$controler_file,$control_date,$res_concept2) = split(/<>/,$_);

							# クエリを再展開
							#if($key eq "number0" && $value eq "delete" && !$my_account->{'admin_flag'}){
							#	close($diary_handler);
							#	main::error("０番のレスは直接削除できません。日記全体を削除してください。");

							# ▼レスの操作
							if($num eq "0"){ 0; } # 0番のレスは削除できない
							elsif($res_control->{$num} eq "delete"){ $res_control_type = "delete"; }
							elsif($res_control->{$num} eq "penalty" && $my_account->{'admin_flag'}){ $res_control_type = "penalty"; }
							elsif($res_control->{$num} eq "revive" && $my_account->{'admin_flag'}){ $res_control_type = "revive"; }

							# 削除行がヒットした場合
							if($res_control_type){

								# 操作したレスを記憶
								push(@{$self{'control_reses'}},$num);

								# 発言者のアカウントデータを開く
								my(%account) = Mebius::Auth::File("Not-file-check Option",$account);

									# 管理者投稿は削除できない
									#if($account{'admin'} && !$my_account->{'admin_flag'}){
									#	close($diary_handler);
									#	&error("管理者投稿は削除できません。");
									#}

									# 削除する
									if($key eq "1" && ($res_control_type eq "delete" || $res_control_type eq "penalty")){
										$controler_file = $my_account->{'id'};
										($control_date) = Mebius::now_date();
											if($account eq $my_account->{'id'}){ $key = 3; $flag = 1; }
											elsif($account eq $my_account->{'id'}){ $key = 2; $flag = 1; }
											elsif($my_account->{'admin_flag'}){ $key = 4; $flag = 1; }
									}

									# 復活させる
									elsif($res_control_type eq "revive"){ $key = 1; $flag = 1; }

									# 管理者削除の場合、ペナルティを与える
									if($res_control_type eq "penalty"){
										Mebius::Authpenalty("Penalty",$account,$comment,"SNS - $accountの日記 $sub","$basic_init->{'auth_url'}$account/d-$diary_number#S$num");
										$res_concept2 .= qq( Penalty-done);
										# SNSペナルティ
										Mebius::AuthPenaltyOption("Penalty",$account,6*60*60);
									}
						
									# 管理者復活の場合、ペナルティを差し引く
									if($res_control_type eq "revive" && $res_concept2 =~ /Penalty-done/){
										Mebius::Authpenalty("Repair",$account);
										$res_concept2 =~ s/(\s?)Penalty-done//g;
										# SNSペナルティ
										Mebius::AuthPenaltyOption("Penalty",$account,-6*60*60);
									}


							}

						# 更新行を追加
						push @renew_line , qq($key<>$num<>$account<>$name<>$trip<>$id<>$comment<>$dates<>$restime<>$resxip<>$controler_file<>$control_date<>$res_concept2<>\n);

					}

				close($diary_handler);

				# 行を追加
				unshift @renew_line , Mebius::add_line_for_file([$key,$num,$sub,$res,$dates,$newtime,$restime,$control_data,@top_other_data]);

					# 日記単体ファイルを書き出し
					if($flag){
						Mebius::Fileout("","${account_directory}diary/${account}_diary_${diary_number}.cgi",@renew_line);
					}
			}

			# 自分の日記インデックスを更新
			if(%controled_thread){
				Mebius::SNS::Diary::index_per_account_file({ Renew => 1 , renew_per_line => \%controled_thread },$account);
			}

			foreach my $year ( keys %controled_thread_year_month ){
					foreach my $month ( keys %{$controled_thread_year_month{$year}} ){
						Mebius::SNS::Diary::month_index_file_per_account({ Renew => 1 , renew_res_data => $controled_thread_year_month{$year}{$month} },$account,$year,$month);
					}
			}

		# ロック解除
		Mebius::unlock("auth$account");

	}

\%self;

}

#-----------------------------------------------------------
# 日記単体ファイルの呼び出し ( State )
#-----------------------------------------------------------
sub thread_state{

my($account,$diary_number) = @_;

# Near State （呼び出し） 2.30
my $HereName1 = "thread_state";
my $StateKey1 = "$account-$diary_number";
my($state) = Mebius::State::Call(__PACKAGE__,$HereName1,$StateKey1);
	if(defined $state){ return($state); }

my($self) = Mebius::Auth::diary(undef,$account,$diary_number);

	# Near State （保存） 2.30
	if($HereName1){ Mebius::State::Save(__PACKAGE__,$HereName1,$StateKey1,$self); }

$self;

}

#-----------------------------------------------------------
# 日記単体ファイル
#-----------------------------------------------------------
sub thread_file{
my($self) = Mebius::Auth::diary(undef,@_);
}

#-----------------------------------------------------------
# アカウント毎の、日記の現行インデックス
#-----------------------------------------------------------
sub index_per_account_file{

my $use = shift if(ref $_[0] eq "HASH");
my($account) = @_;
my($account_directory) = Mebius::Auth::account_directory($account) || die;
my($my_account) = Mebius::my_account();
my($basic_init) = Mebius::basic_init();
my($FILE1,%self,@renew_line);

my $file1 = "${account_directory}diary/${account}_diary_index.cgi";

# 現行インデックスを読み込み
open($FILE1,"<",$file1);

	# ファイルロック
	if($use->{'Renew'}){ flock($FILE1,1); }

# トップデータ
chomp(my $top = <$FILE1>);
($self{'newest_diary_number'}) = split(/<>/,$top);

	# ●展開
	while(<$FILE1>){

		chomp;
		my($key,$num,$sub,$res,$dates,$newtime,@other_data) = split(/<>/,$_);
		my($year,$month,$day,$hour,$min) = split(/,/,$dates);
		my($link,$mark,$line);
		my($sub_utf6) = utf8_return($sub);

		$link = qq($main::adir${account}/d-$num);

				if($key eq "0"){ $mark .= qq(<span class="lock"> - ロック中</span> ); }

				# 普通に表示する
				if($key eq "0" || $key eq "1"){
					if(time < $newtime + 3*24*60*60){ $mark .= qq(<span class="red"> - new!</span> ); }
					$self{'diary_index'} .= qq(<li><a href="$link">$sub_utf6</a> ($res) - $month月$day日$mark</li>);
				}

				# 削除済みの場合
				else{
					my($text);
						if($key eq "2"){ $text = qq( アカウント主により削除); }
						elsif($key eq "4"){ $text = qq( 管理者により削除); }
						if($my_account->{'admin_flag'}){ $text .= qq( <a href="$link" class="red">$sub_utf6</a>); }
					$self{'diary_index'} .= qq(<li>$text - $month月$day日</li>);
				}

				# ▼ファイル更新用
				if($use->{'Renew'}){

						# キーの変更
						if($use->{'renew_per_line'}->{$num}->{'key'} =~ /^([0-9]+)$/){
							$key = $use->{'renew_per_line'}->{$num}->{'key'};
						# レス数の変更
						}	elsif($use->{'renew_per_line'}->{$num}->{'res'} =~ /^([0-9]+)$/){
							$res = $use->{'renew_per_line'}->{$num}->{'res'};
						}

					# 更新行を定義
					push @renew_line , Mebius::add_line_for_file([$key,$num,$sub,$res,$dates,$newtime,@other_data]);

				}

		}
close($FILE1);

	# ●ファイル更新
	if($use->{'Renew'} && @renew_line >= 1){

		unshift @renew_line , Mebius::add_line_for_file([$self{'newest_diary_number'}]);

		# 現行インデックスを書き出し
		Mebius::Fileout("",$file1,@renew_line);
	}


\%self;

}

#-----------------------------------------------------------
# アカウント毎の、日記の月別インデックス
#-----------------------------------------------------------
sub month_index_file_per_account{

my $use = shift if(ref $_[0] eq "HASH");
my($account,$year,$month) = @_;
my(@renew_line,$FILE1);

	# 汚染チェック
	if($year eq "" || $year =~ /[^0-9]/){ return(); }
	if($month eq "" || $month =~ /[^0-9]/){ return(); }
	if(Mebius::Auth::account_name_error($account)){ return(); }

# ファイル・ディレクトリ定義
my($account_directory) = Mebius::Auth::account_directory($account) || return();
my $file1 = "${account_directory}diary/${account}_diary_${year}_${month}.cgi";

# 月別インデックスを開く
open($FILE1,"<",$file1);
flock($FILE1,1);

	while(<$FILE1>){

		my %data;

		chomp $_;
		($data{'key'},$data{'diary_number'},$data{'subject'},$data{'last_res_number'},$data{'dates'}) = split(/<>/,$_);

			# ファイル更新用
			if($use->{'Renew'}){
				my($renew) = Mebius::Hash::control(\%data,$use->{'renew_res_data'}->{$data{'diary_number'}});
				push @renew_line , Mebius::add_line_for_file([$renew->{'key'},$renew->{'diary_number'},$renew->{'subject'},$renew->{'last_res_number'},$renew->{'dates'}]);
			}

	}
close($FILE1);

	# ヒットした場合のみ、月別インデックスを書き出し
	if($use->{'Renew'} && @renew_line >= 1){
		Mebius::Fileout("",$file1,@renew_line);
	}

}

#-----------------------------------------------------------
# 0番投稿エリアの表示内容を定義
#-----------------------------------------------------------
sub view_zero_res{

my $use = shift if(ref $_[0] eq "HASH");
my($account,$diary) = @_;
my($my_account) = Mebius::my_account();
my($my_use_device) = Mebius::my_use_device();
my($basic_init) = Mebius::basic_init();
my($view_line);

	# 日記本体の削除フォーム
	if(!Mebius::Report::report_mode_judge()){
		($view_line) .= Mebius::SNS::Diary::thread_control_form($account,$diary);
	}


$view_line .= qq(<h2>本文</h2>);

my($zero_res_line) = Mebius::SNS::Diary::view_res_core({ } , $account,$diary->{'number'},$diary->{'res_data'}->[0]);
$view_line .= $zero_res_line;

	if($use->{'crap_line'}){

			$view_line .= qq(<div class="under_main_diary">);
			$view_line .= qq(<div class="crap_line">$use->{'crap_line'}</div>);
			$view_line .= qq(<div class="right spacing">);
				if($my_account->{'login_flag'}){
					$view_line .= qq(<a href=").e($my_account->{'profile_url'}).qq(feed">→フィードへ</a>);
				}
			$view_line .= qq( <a href=").e($basic_init->{'auth_url'}).qq(aview-alldiary.html#S$account-$diary->{'number'}">→全メンバーの新着日記へ</a>);
			$view_line .= qq(</div>);
			$view_line .= qq(</div>);
	}




$view_line;

}



#-----------------------------------------------------------
# 日記のレス毎に、表示を定義
#-----------------------------------------------------------
sub view_res_core{

my $use = shift if(ref $_[0] eq "HASH");
my($account,$diary_number,$data_shift_jis) = @_;
my($parts) = Mebius::Parts::HTML();
my($my_use_device) = Mebius::my_use_device();
my($my_account) = Mebius::my_account();
my($basic_init) = Mebius::basic_init();
my $data = Mebius::Encoding::hash_to_utf8($data_shift_jis);
my($key,$res_number,$account2,$name,$id,$trip,$comment,$dates,$color,$xip,$controler_file,$control_date) = ($data->{'key'},$data->{'res_number'},$data->{'account'},$data->{'name'},$data->{'id'},$data->{'trip'},$data->{'comment'},$data->{'dates'},$data->{'color'},$data->{'xip'},$data->{'controler_file'},$data->{'control_date'});
my($view_line,$deleted,$rescontrol_box,$control_flag,$divclass,$adsflag1,$adsflag2,$class);

# 時刻整形
my($year,$month,$day,$hour,$min,$sec) = split(/,/,$dates);
my($viewdate) = sprintf("%04d/%02d/%02d %02d:%02d", $year,$month,$day,$hour,$min);

			# 行頭の改行を削除
			if($my_use_device->{'smart_flag'} || $my_use_device->{'mobile_flag'}){
				($comment) = Mebius::Text::DeleteHeadSpace(undef,$comment);	
			}

		# オートリンク
		($comment) = Mebius::auto_link($comment);

			# 文字色の整形
			my $style = qq( style="color:#$color;") if(length($color) == 3);

	# 削除済みの場合
	if($key eq "3"){ $deleted = qq(投稿者-$account2-により削除);  }
	elsif($key eq "2"){ $deleted = qq(アカウント主により削除); }
	elsif($key eq "4"){ $deleted = qq(管理者-$controler_file-により削除); }

	# 削除時間を整形
	if($control_date){ $control_date = qq(( $control_date )); }

	# レスが削除済みの場合、表示を整形する
	if($deleted){
			if($my_account->{'admin_flag'}){
				$comment = qq(<span class="cdeleted">【$deleted】 $control_date - 管理者にだけ本文が見えます<br$main::xclose><br$main::xclose>$comment</span>);
			}
			else{
				$deleted = qq(<span class="cdeleted">【$deleted】 $control_date</span>);
				$comment = qq($deleted);
				$rescontrol_box = undef;
			}
	}


	# 0レス以外では報告ボックス、または削除操作部分を表示する
	if($res_number ne "0"){

			# ▼報告ボックス
			if(Mebius::Report::report_mode_judge()){

			# ▼コメントの操作ボックス
			} else {

					my $input_name = "sns_diary_res_${account}_${diary_number}_${res_number}";

					# 削除チェックボックス(一般用)
					if($key eq "1" && $res_number ne "0" && ($account eq $my_account->{'id'} || $data->{'account'} eq $my_account->{'id'}) && control_mode_judge() && !$my_account->{'admin_flag'}){
						$rescontrol_box .= qq(<input type="checkbox" name=").e($input_name).qq(" value="delete"> <span class="alert">このレスを削除</span>);
					}

					# レス操作ラジオボックスの整形 （管理者用）
					if($my_account->{'admin_flag'}){
						$rescontrol_box .= qq(<label>);
						$rescontrol_box .= qq( <input type="radio" name=").e($input_name).qq(" value="" checked>);
						$rescontrol_box .= qq(<span>);
						$rescontrol_box .= qq(未選択);
						$rescontrol_box .= qq(</span>);
						$rescontrol_box .= qq(</label>);
					}

					# レス操作ラジオボックスの整形 （管理者用）
					if($my_account->{'admin_flag'}){
						$rescontrol_box .= qq(<label>);
						$rescontrol_box .= qq( <input type="radio" name=").e($input_name).qq(" value="no-reaction">);
						$rescontrol_box .= qq(<span>);
						$rescontrol_box .= qq(対応しない);
						$rescontrol_box .= qq(</span>);
						$rescontrol_box .= qq(</label>);
					}


					# 罰削除ラジオボックス（管理者用）
					if($my_account->{'admin_flag'} && !$deleted){
						my($disabled_buf) = $parts->{'disabled'} if($deleted);
						$rescontrol_box .= qq(<label>);
						$rescontrol_box .= qq(<input type="radio" name=").e($input_name).qq(" value="penalty"$disabled_buf>);
						$rescontrol_box .= qq(<span class="red select">罰削除</span>);
						$rescontrol_box .= qq(</label>);
					}

					# 削除ラジオボックス（管理者用）
					if($my_account->{'admin_flag'} && !$deleted){
						my($disabled_buf) = $parts->{'disabled'} if($deleted);
						$rescontrol_box .= qq(<label>);
						$rescontrol_box .= qq(<input type="radio" name=").e($input_name).qq(" value="delete"$disabled_buf>);
						$rescontrol_box .= qq(<span class="select">削除</span>);
						$rescontrol_box .= qq(</label>);
					}

					
					# 復活ラジオボックス（管理者用）
					if($my_account->{'admin_flag'} && $deleted){
						my($disabled_buf) = $parts->{'disabled'} if(!$deleted);
						$rescontrol_box .= qq(<label>);
						$rescontrol_box .= qq(<input type="radio" name=").e($input_name).qq(" value="revive"$disabled_buf>);
						$rescontrol_box .= qq(<span class="select blue">復活</span>);
						$rescontrol_box .= qq(</label>);
					}

					# レス操作ラジオボックスの整形 （共通）
					if($rescontrol_box){
						$rescontrol_box = qq(<div class="res_control">$rescontrol_box</div>);
						$control_flag = 1;
					}

			}
	}


	# スタイルを定義
	if($key ne "1" && $my_account->{'admin_flag'}){ $divclass = qq( class="admin_deleted"); }

	# 表示内容
	{

			# 投稿者が自分の場合、筆名の色を変える
			if($data->{'account'} eq $account){ $class = qq( class="me"); }

		$view_line .= qq(<div$divclass>);
		$view_line .= qq(<p id="S$res_number" class="s"$style><a href="$basic_init->{'auth_url'}$data->{'account'}/"$class>$name - $data->{'account'}</a><br$main::xclose><br$main::xclose>$comment</p>);


		$view_line .= q(<div class="date">);
		$view_line .= e($viewdate).q( - );

			# 各レス番へのリンク
			if($my_account->{'login_flag'} && $use->{'select_res_number'} ne $res_number){
				$view_line .= q(<a href="./d-).e($diary_number).q(-).e($res_number).q(#S).e($res_number).q(">No.).e($res_number).q(</a>);
			} else {
				$view_line .= q(No.).e($res_number);
			}
		$view_line .= q(</div>); # $delete
			if($my_account->{'master_flag'}){ $view_line .= qq( $xip); }
		$view_line .= qq($rescontrol_box);
		$view_line .= qq(</div>);

		# ▼削除依頼のチェックボックス
		#my($handle_utf8) = utf8_return($nam);
		#my($report_check_box) = shift_jis(Mebius::Report::report_check_box_per_res({ handle => $handle_utf8 , handle_deleted_flag => $res_concept{'Deleted-handle'} , comment_deleted_flag => $comment_deleted_flag },$res_number));
		my($report_check_box) = Mebius::Report::report_check_box_per_res({  },$res_number) if($data->{'key'} eq "1");
		$view_line .= $report_check_box;
	}

	# 関連記事の表示
	#if($key eq "1" && $res_number eq "0"){ $view_line .= qq($account{'kr_oneline'}); }

return($view_line,$control_flag);

}

#-----------------------------------------------------------
# スレッドの操作フォーム
#-----------------------------------------------------------
sub thread_control_form{

my($account,$diary) = @_;
my($my_account) = Mebius::my_account();
my($diary_control_form);

	if(Mebius::Admin::admin_mode_judge() || $my_account->{'admin_flag'} || $account eq $my_account->{'id'}){

			my $input_name = "sns_diary_${account}_$diary->{'number'}";

			$diary_control_form .= q(<h2>操作</h2>);
			$diary_control_form .= q(日記本体： );
			$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="" checked><span>未選択</span></label>);

				if($my_account->{'admin_flag'} || Mebius::Admin::admin_mode_judge()){
					$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="no-reaction"><span>対応しない</span></label>);
				}

			$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="delete"><span>削除</span></label>);

				if($diary->{'key'} eq "0"){
					$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="unlock"><span>ロック解除</span></label>);
				} elsif($diary->{'key'} eq "1") {
					$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="lock"><span>ロック</span></label>);
				}

				if($my_account->{'admin_flag'} || Mebius::Admin::admin_mode_judge()){
					$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="penalty"><span class="red">罰削除</span></label>);
					$diary_control_form .= q(<label><input type="radio" name=").e($input_name).q(" value="revive"><span class="blue">復活</span></label>);
				}

		$diary_control_form .= qq( <input type="submit" value="実行する">);
	}

$diary_control_form;

}


#-----------------------------------------------------------
# いいね！エリア
#-----------------------------------------------------------
sub crap_line{

# 宣言
my($diary_number,$diary,$account) = @_;
my($crap_line);
my($my_account) = Mebius::my_account();

my %account = %$account;
my %diary = %$diary;

# いいね！情報を取得
my(%crap_shift_jis) = Mebius::Auth::Crap("Get-topics Diary-file",$account{'file'},$diary_number);
my($crap) = Mebius::Encoding::hash_to_utf8(\%crap_shift_jis);

# 整形
$crap_line .= qq(<div class="word-spacing line-height">);
$crap_line .= qq(<img src="/pct/light1.png" alt="いいね！" style="width:20px;height:20px;"$main::xclose>いいね！($crap->{'count'})\n);

	# いいね！したアカウント一覧
	if($crap->{'topics_line'}){
		$crap_line .= qq( - $crap->{'topics_line'});
	}

	# いいね！ボタン（リンク形式）
	if($my_account->{'login_flag'}){

			# アカウント設定によるいいね！禁止
			if(!$account{'allow_crap_diary_flag'}){
				$crap_line .= qq( -&gt; このメンバーは日記へのいいね！を許可していません。);
			}
			# 日記設定によるいいね！禁止
			elsif($diary->{'not_crap_flag'}){
				$crap_line .= qq( -&gt; この日記はいいね！を禁止しています。);
			}

			# ストップモード
			if($main::stop_mode =~ /SNS/){
				$crap_line .= qq( -&gt; 現在、SNSは更新停止中です。);
			}
			# いいね！を許可している場合
			elsif((!$crap->{'craped_flag'} && $account{'file'} ne $main::myaccount{'file'}) || Mebius::AlocalJudge()){
				$crap_line .= qq( -&gt; <a href="./?mode=crap&amp;mode=crap&amp;action=new_crap&amp;target=diary&amp;diary_number=$diary_number&amp;account_char=$main::myaccount{'char'}" style="color:#080;">この日記にいいね！する</a>);

					# ランキング拒否している場合
					if($diary->{'not_crap_ranking_flag'} || $account{'osdiary'} eq "2"){
						$crap_line .= qq( \( ランキングには登録されません \) );
					}
			}
	}

# 整形
$crap_line .= qq(</div>);

$crap_line;

}


#-----------------------------------------------------------
# 操作モードかどうかを判定
#-----------------------------------------------------------
sub control_mode_judge{

my($submode) = Mebius::Mode::submode();

	if($submode->{'3'} eq "all"){ 1; }

}


#-----------------------------------------------------------
# ファーストビューの広告
#-----------------------------------------------------------
sub ads_first_view{
my($ads) = decide_ads();
$ads->{'first_view'};
}

#-----------------------------------------------------------
# 0番下の広告
#-----------------------------------------------------------
sub ads_up{
my($ads) = decide_ads();
$ads->{'up'};
}

#-----------------------------------------------------------
# 0番下の広告
#-----------------------------------------------------------
sub ads_right{
my($ads) = decide_ads();
$ads->{'right'};
}

#-----------------------------------------------------------
# 0番下の広告
#-----------------------------------------------------------
sub ads_bottom{
my($ads) = decide_ads();
$ads->{'bottom'};
}


#-----------------------------------------------------------
# 広告を決定
#-----------------------------------------------------------
sub decide_ads{

my($ads1,$ads2,$ads_right,$ads_first_view);
my($my_use_device) = Mebius::my_use_device();

	# ローカルの場合
	if(Mebius::AlocalJudge() && 1){ 
		0;

	# 管理モードの場合
	} elsif(Mebius::Admin::admin_mode_judge()){
		0;

	# 携帯からの場合
	} elsif(Mebius::Device::use_device_mobile_judge()){
		($ads1) = main::kadsense();
			if($ads1){ $ads1 = qq(<hr>$ads1<hr>); }
	}

	# スマフォ用
	elsif($my_use_device->{'smart_flag'}){

		$ads1 = '
		<div class="diary_ads">
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* mobile tangle */
		google_ad_slot = "3446606142";
		google_ad_width = 300;
		google_ad_height = 250;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</div>
		';

		$ads2 = '
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* mobile bunner */
		google_ad_slot = "4674925464";
		google_ad_width = 320;
		google_ad_height = 50;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		';

		$ads_first_view = '
		<div class="ads_first_view">
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* スマフォバナー */
		google_ad_slot = "1226476247";
		google_ad_width = 320;
		google_ad_height = 50;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</div>
		';

	# PC用
	} else {

		$ads1 = '
		<div class="diary_ads">
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* SNS(レクタングル中) */
		google_ad_slot = "0450176853";
		google_ad_width = 300;
		google_ad_height = 250;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</div>
		';

		$ads2 = '
		<div>
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* SNSビッグバナー */
		google_ad_slot = "4432696952";
		google_ad_width = 728;
		google_ad_height = 90;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		</div>
		';

		$ads_right = '
		<script type="text/javascript"><!--
		google_ad_client = "ca-pub-7808967024392082";
		/* SNS 日記 右 */
		google_ad_slot = "7887959321";
		google_ad_width = 160;
		google_ad_height = 600;
		//-->
		</script>
		<script type="text/javascript"
		src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
		</script>
		';
	}

		$ads1 =~ s/\t//g;
		$ads2 =~ s/\t//g;
		$ads_right =~ s/\t//g;
		$ads_first_view =~ s/\t//g;

{ up => $ads1 , bottom => $ads2 , right => $ads_right , first_view => $ads_first_view };


}

1;