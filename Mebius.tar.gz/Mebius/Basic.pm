

# �錾
#use Apache::DBI;
use Mebius::Utility;
use Mebius::Auth;
use Mebius::Admin;
use Mebius::Parts;
use Mebius::Gaget;
use Mebius::Reason;
use Mebius::Report;
use Mebius::Encoding;
use Mebius::RegistCheck;
use Mebius::RegistCheckUTF8;
use Mebius::IventDay;
use Mebius::UsersTag;
use Mebius::Linux;
use Mebius::DBI;
#use Mebius::Flag;
use Mebius::Hostbyaddr;
use Mebius::DosDBI;
use Mebius::DBI;
use Mebius::Follow;
use Mebius::Javascript;
use Mebius::Server;
use Encode::Guess;
use Encode qw();
package main;
use Mebius::Export;
use DBI;


	# umask �̔���
	#if($ENV{'MOD_PERL'}){
	#	my $umask = umask();
	#		if($ENV{'MOD_PERL'}){
	#			warn("Perl Check! umask is $umask");
	#		}
			# umask 0070 ����� umask() �œ�����l�� 18 (�\�i��)
	#		if($umask != 18){
	#			umask(0070);
	#			warn("Perl Check! umask setting $umask is wrong.");
	#			#Mebius::maintenance();
	#		}
	#}



#-----------------------------------------------------------
# �f�R�[�h�����E��{�������� - strict
#-----------------------------------------------------------
sub decode{


# �S�Ă̕ϐ��������� ( �d�v )
reset 'a-z';

# umask��ݒ�
umask(0070);

# ���W���[���̑S�ϐ��������� ( �d�v )
Mebius::State::AllReset();
Mebius::Roop::all_reset();

	# �f�o�b�O�p�� %ENV ��ύX ( ���[�J�� )
	if(Mebius::AlocalJudge()){
			Mebius::Debug::OverWriteENV();
	}

	# ���[�J���őS�e�[�u�����쐬
	if(Mebius::AlocalJudge()){
		Mebius::DBI::create_all_tables();
	}

	#
	#if($ENV{'SCRIPT_NAME'} =~ m!/(bbs).cgi$!){
	#if(!Mebius::AlocalJudge() && $ENV{'HTTP_HOST'} eq "aurasoul.mb2.jp"){
		#Mebius::maintenance(1354673854 + 24*60*60);
		
	#}
	#}

# �錾
my($type,undef,$init,$init2,undef,$base_server_domain2) = @_;
my($init_start,$start);
our($alocal_mode,$secret_mode,$mobile_test_mode,$getaccess_mode,$lockkey);
our($moto,$category,$myadmin_flag,$pmfile,$kflag,$thisyear,%in);
our($mode,$submode1,$submode2,$submode3,$submode4,$submode5) = undef;
our($age,$agent,$realagent,$cookie,$addr,$referer,$requri,$scriptname,$device_type) = undef;
our($k_access,$kaccess_one,$bot_access,$bot_access2) = undef;
our($chandle,$cmtrip,$base_server_domain) = undef;
our($topics_line_reshistory,$one_line_reshistory,$follow_line) = undef;
if($init){ $init_start = "init_start_${init}"; $start = "start_$init"; }
if($init2){ $init_start = "${init2}::init_start_${init}"; $start = "${init}::start_$init"; }

	# �h���C����`
	our($server_domain) = Mebius::server_domain();
	$base_server_domain = $base_server_domain2;

# �����e�Ȃ�
$mobile_test_mode = 0;

	# ��ݒ�f�B���N�g�����`
	our($int_dir) = Mebius::BaseInitDirectory("$type",$server_domain2);

	# �����^�C�v���`
	if(Mebius::AlocalJudge()){ $alocal_mode = 1; }

# �S�Ă̋��ʐݒ����荞�� ( �O���[�o���ϐ� )
init_defult($type);

# �� EVN �`�F�N
Mebius::ENV::WrongCheck();

# �������擾
my($date_multi) = Mebius::now_date_multi();
our $time = time;
our $thismonth = $date_multi->{'month'};
our $today = $date_multi->{'day'};
our $thishour = $date_multi->{'hour'};
our $thismin = $date_multi->{'minute'};
our $thissec = $date_multi->{'second'};
#our $thiswday = $date_multi->{'weekday'};
our $thismonthf = $date_multi->{'monthf'};
our $todayf = $date_multi->{'dayf'};
our $thishourf = $date_multi->{'hourf'};
our $thisminf = $date_multi->{'minutef'};
our $thissecf = $date_multi->{'secondf'};
our $date = $date_multi->{'date_till_minute'};
our $thisyear = $date_multi->{'year'};
our $thisyearf = $date_multi->{'yearf'};

# ���ϐ��Ȃǂ��擾
our($moto,$realmoto,$addr,$agent,$cookie,$realcookie,$referer,$requri,$scriptname,$scriptdir,$selfurl,$selfurl_enc,%env) = get_env_decode(undef,$type);
$realagent = $age = $agent;

# �N�b�L�[�Q�b�g�i�S�́j
my($main_cookie) = Mebius::my_cookie_main_logined();
our($cnam,$cposted,$cpwd,$ccolor,$cup,$ccount,$cnew_time,$cres_time,$cgold,$csoumoji,$csoutoukou,$cfontsize,$cfollow,$cview,$cnumber,$crireki,$ccut,$cmemo_time,$caccount,$cpass,$cdelres,$cnews,$cage,$cemail,$csecret,$cres_waitsecond,$caccount_link,$cimage_link,$cfillter_id,$cfillter_account,undef,undef,undef) = Mebius::Cookie::hash_to_array_main(%$main_cookie);

# �A�N�Z�X�^�C�v����
my($access) = Mebius::my_access();
our $agent = $access->{'multi_user_agent'};
our $k_access = $access->{'mobile_id'};
our $kaccess_one = $access->{'mobile_uid'};

# �f�o�C�X�^�C�v���擾
my($use_device) = Mebius::my_use_device();
our %device = %$use_device;
our $device_type = $use_device->{'browse_type'};

# ���A���f�o�C�X�����擾
my($real_device) = Mebius::my_real_device();
our %real_device = %$real_device;
our $bot_access = $real_device->{'bot_flag'};
our $sikibetu = $real_device->{'utn'};

# HTML�p�[�c���擾
our($parts) = Mebius::Parts::HTML(undef);
our(%parts) = %$parts;
our($checked,$selected,$disabled) = undef;
our $checked = $parts{'checked'};
our $selected = $parts{'selected'};
our $disabled = $parts{'disabled'};

	# �g�єł̃p�[�c���擾
	if($use_device->{'type'} eq "Mobile"){
		&kget_items();
	}

# XIP���擾 ( ���ϐ��擾�̂��� )
our($xip,$xip_enc,$no_xip_action) = &get_xip($addr,$agent,$k_access);

	# �f�R�[�h����
	if($type !~ /Not-indecode/){ &indecode(undef,$type); }

# �e��f�[�^���擾
my($myaccount) = Mebius::my_account();
	if($myaccount->{'login_flag'}){ our %myaccount  = %$myaccount; }

	# �N�b�L�[�̒��� ( �A�J�E���g�f�[�^�擾�̂��� )
	($chandle,$cmtrip) = split(/#/,$cnam);
	if($csecret eq "1" || $csecret eq "2"){ $csecret = undef; }
	$cnumber =~ s/\W//g;
	if(length($crireki) >= 5){ $crireki = undef; }
	if($crireki eq "2"){ $crireki = "off"; }
	if($k_access && !$cookie){ $chowold = 18; }
	elsif($cage){ $chowold = $thisyear - $cage; }

	# �߂��URL���擾
	if($referer || $in{'backurl'}){
		require "${int_dir}part_backurl.pl";
		get_backurl("",$in{'backurl'});
	}

	#if($myadmin_flag >= 5 && $device_type eq "desktop" && !$mobile_test_mode){ $device_type = "both"; }
	if($device_type eq "mobile"){ $main::kflag = 1; }

	# �v���O�����^�C�v���Ƃ̊�{�ݒ����荞��
	if($type !~ /Not-init-start/){
		if($init){ &$init_start(); } elsif(defined(&init_start)) { &init_start(); }
	}


# ���[�h��`
$mode = $in{'mode'};
($submode1,$submode2,$submode3,$submode4,$submode5) = split(/-/,$mode);

	# ���[�h��W�J
	foreach(split(/-/,$mode,-1)){
		$main::submode_num++;
	}

	# DOS�U�����`�F�b�N ( ���̂��̈ʒu�Ŏ��s�H ���O�̏����̂ق����A�m���Ɏ��s�����͂� )
	# => ���ݎ����ȂǁA�e�폈�������L�V�J���ɏ����悤�ɂ���΁A�ǂ̈ʒu�ł������ł���悤�ɂȂ�͂�
	#if(!Mebius::Switch::light()){
	#	Mebius::Dos::AccessFile("New-access Renew",$addr);
	#}

	{
		Mebius::Dos::access();
	}

	# ����IP
	if($ENV{'REMOTE_ADDR'} =~ /^(50\.63\.138\.34)$/){
		Mebius::AccessLog(undef,"Bad-IP-and-Access-Block");
		die("Perl Die! $ENV{'REMOTE_ADDR'} is Bad IP.");
	}

	# �X���b�V���Q�ȏ��URL�͐��K��
	if($ENV{'REQUEST_URI'} =~ /\/\// && $ENV{'REQUEST_METHOD'} ne "POST"){
		# �h���C�����擾
		my($server_domain) = Mebius::server_domain();
		(my $redirect_url = $ENV{'REQUEST_URI'}) =~ s!/{2,}!/!g;
			if($main::bot_access){ Mebius::AccessLog(undef,"Slash-url-bot"); }
			else{ Mebius::AccessLog(undef,"Slash-url"); }
		Mebius::Redirect("301","http://$server_domain$redirect_url");
	}

	# ����O���T�C�g����̖K��
	if($ENV{'HTTP_REFERER'} =~ /^http:\/\/(www\.)?(ime\.nu|ime\.st)\//){
		require "${int_dir}part_enemysite.pl";
		from_enemysite(undef,$referer);
	}


	# �ςȊ��ϐ�
	if($ENV{'REQUEST_METHOD'} ne "POST" && $ENV{'REQUEST_METHOD'} ne "GET" && $ENV{'REQUEST_METHOD'} ne "HEAD"){
		Mebius::AccessLog(undef,"Strange-request-method","\$ENV{'REQUEST_METHOD'} �F $ENV{'REQUEST_METHOD'}");
	}

	# �X�^�[�g�O�̏��� 
	if(defined(&before_start)){ &before_start(); }

	# �����X�^�[�g
	if($init){ &$start(); } elsif(defined(&start)) { &start(); }

}

use strict;

#-----------------------------------------------------------
# ���ʂ̏����ݒ�
#-----------------------------------------------------------
sub init_defult{

# �錾
my($basic_init) = Mebius::basic_init();
my($type) = @_;
my(%basic);
our($otherserver_link);
our($backurl,$no_headerset);
our($error_done,$headflag);
our($moto,$lock_dir,$k_access,$kaccess_one,$mente_mode,$alocal_mode,$int_dir);
our($script,%backup_directory);

# �T�[�o�[�h���C�����擾
my($server_domain) = Mebius::server_domain();

# �o�b�N�A�b�v
our @backup_directory_number = ("1","15");
	foreach(@backup_directory_number){
			$backup_directory{$_} = "/var/www-backup$_/web_data/";
	}

# �����e / �e�X�g���[�h
$mente_mode = 0;
if($mente_mode){ require "${int_dir}part_mente.pl"; &all_mente(); } 
our $getaccess_mode = 0;

# ���e�X�g�b�v���[�h
#our $stop_mode = "BBS";
our $stop_mode = "";

# �O���Ȃ������ݒ�
our $dirpms = 0707;
our $logpms = 0606;

	# �Ǘ����[�h��SSL�؂�ւ� => CCC �ǂ��ɂ�����
	#if($type =~ /Admin-mode/ || $ENV{'REQUEST_URI'} =~ m!^/jak/!){
			#if($server_domain eq ""){ $server_domain = "$ENV{'SERVER_NAME'}"; }
	#		if($ENV{'SERVER_PORT'} eq "80"){ $basic{'admin_http'} = "http"; }
	#		else{ $basic{'admin_http'} = "https"; }
	#}
	#else{
			#if($server_domain eq ""){ our $server_domain = "aurasoul.mb2.jp"; }
	#		if(Mebius::AlocalJudge()){ $basic{'admin_http'} = "http"; }
	#		else{ $basic{'admin_http'} = "https"; }
	#}

our @server_addrs = ("112.78.200.216","112.78.200.218");

#our $lock_dir = "${int_dir}_lock/";
our $jak_dir = "/var/www/$server_domain/public_html/jak/";

our $pct_dir = "/pct/";


if($script eq ""){ $script = "./"; }
our $lockkey = 1;

#$base_domain = "mb2.jp";	# 2012/1/24 (��) �V�����ɓ���

our $home = "http://aurasoul.mb2.jp/";
#our $mailform = $basic_init->{'mailform_link'};
our $auth_url = $basic_init->{'auth_url'};
our $paint_url = "/paint/";
our $paint_dir = "/var/www/$server_domain/public_html/paint/";

our $gold_url = "/_gold/";

our @domains = ("aurasoul.mb2.jp","mb2.jp");
my($all_domains) = Mebius::Init::AllDomains();
our(@all_domains) = (@$all_domains);
our $goraku_url = 'http://mb2.jp/';

	# ��h���C���Ē�`
	if($main::base_server_domain eq ""){
		$main::base_server_domain = $server_domain;
	}

	# ���C��URL�̕⑫
	if($server_domain eq $main::base_server_domain){
		$main::main_url = "http://$main::base_server_domain/_main/";
	}
	else{
		$main::main_url = "http://$main::base_server_domain/_main/";
	}

our $jak_url = $basic_init->{'admin_url'};
our $jak_paint_url = "${jak_url}paint/";

our $door_url = "http://mb2.jp/_main/";
our $base_url = 'http://aurasoul.mb2.jp/';
our $home = $base_url;
our $guide_url = $basic_init->{'guide_url'};
our $hometitle = "���r�E�X�����O�f����";

our $qst_url = "http://aurasoul.mb2.jp/_qst/";
our $delete_url = $basic_init->{'report_bbs_url'};

# �Ǘ���(�}�X�^�[)��IP/�z�X�g��
#our $master_addr = "119.239.40.136";
our $master_addr = $basic_init->{'master_addr'};
	#if($master_addr eq $ENV{'REMOTE_ADDR'}){ $basic{'master_addr_flag'} = 1; }
our(@master_hosts);
push(@master_hosts,".osk.mesh.ad.jp");
push(@master_hosts,".tky.mesh.ad.jp");
push(@master_hosts,".rev.home.ne.jp");

	# ���[�J���ݒ�
	if(Mebius::AlocalJudge()){
		$paint_dir = "${int_dir}../htdocs/paint/";
		$lock_dir = "${int_dir}_lock/";
		#$jak_url = "/cgi-bin/patio/admin/";
		$jak_dir = "${int_dir}admin/";
		$jak_paint_url = "/paint/";

		$jak_url = "$basic_init->{'admin_http'}://$server_domain/jak/";
		push(@domains,"localhost");
		$master_addr = "127.0.0.1";
		push(@master_hosts,"localhost",".localhost.jp","YUMA-PC");
			foreach(@backup_directory_number){
				$backup_directory{$_} = "${int_dir}bkup$_/";
			}

	}

# �T�[�o�[�̑S�̐� (����)
#$basic{'number_of_servers'} = 2;
#$basic{'number_of_domains'} = 3;

#return(\%basic);


}

#-----------------------------------------------------------
# ���ϐ��̃`�F�b�N - strict
#-----------------------------------------------------------
sub get_env_decode{

# �錾
my($type,$basic_type) = @_;
my($moto,$realmoto,$addr,$agent,$cookie,$realcookie,$referer,$requri,$scriptname,$scriptdir,$selfurl,$selfurl_enc);
our($k_access,$mobile_test_mode,$host,$server_domain);

# ���ϐ����擾
$agent = $ENV{'HTTP_USER_AGENT'};
$cookie = $realcookie = $ENV{'HTTP_COOKIE'};
$addr = $ENV{'REMOTE_ADDR'};
$requri = $ENV{'REQUEST_URI'};
$referer = $ENV{'HTTP_REFERER'};
$scriptname = $scriptdir = $ENV{'SCRIPT_NAME'};

# ���ϐ��𐮌`
$scriptname =~ s/(.+?)([a-zA-Z0-9_]+)\.([a-zA-Z]{2,3})$/$2\.$3/g;
$scriptname =~ s/(\.\.|\/)//g;
if($moto eq ""){ $moto = $scriptname; $moto =~ s/(_|\.)([a-zA-Z0-9]+)//g; $realmoto = $moto; $moto =~ s/^sub//; }

if($referer){ ($referer) = ($referer); }
if($agent){ ($agent) = Mebius::Escape("",$agent); }
($addr) = Mebius::Escape("",$addr);
if($requri){ ($requri) = Mebius::Escape("NOTAND",$requri); }

my(%env) = Mebius::Env("Get-proxy-only");

	# �s���Ȃt�q�k���֎~
	if($requri =~ /(actbbs)/ && $basic_type !~ /Allow-natural-url/){ Mebius::AccessLog(undef,"Actbbs-access"); &error("���̃y�[�W�͑��݂��܂���B"); }

	# ���T�[�o�[����̃A�N�Z�X���L�^
	foreach(@main::server_addrs){
		if($addr eq $_){ Mebius::AccessLog(undef,"Server-self"); }
	}


	# ���݂̂t�q�k���`
	if($server_domain && $requri){
		$selfurl = "http://$server_domain$requri";
		$selfurl_enc = Mebius::Encode("",$selfurl);
	}

# ���^�[��
return($moto,$realmoto,$addr,$agent,$cookie,$realcookie,$referer,$requri,$scriptname,$scriptdir,$selfurl,$selfurl_enc,%env);

}


#-----------------------------------------------------------
# �f�R�[�h���� - strict
#-----------------------------------------------------------
sub indecode{

# �錾
my($type,$relay_type) = @_;
my($buf,@query_key,@query_value,%query,$multi_part_flag);
my($convert_from);
my($q) = Mebius::query_state();
our($postbuf,$postbuf_query,$no_headerset);
our($postflag,$postbuf_query_esc,$upload_flag) = undef; #������
our($query_string,$content_length) = undef;



# �ϐ���������
undef(our %in);
undef(our %ch);
undef(our %query_not_escaped);

# CGI.pm ��ϋɓI�Ɏg�����ǂ���
my $UseEncoding = 1;

	# �A�b�v���[�h�y���̏ꍇ
	if($ENV{'CONTENT_TYPE'} =~ /^multipart\/form-data;/){
		$multi_part_flag = 1;
	}


	# �f�[�^�󂯎��
	{
		require "${main::int_dir}part_upload.pl";
		$query_string = $q->query_string();
	}

	# �f�[�^�󂯎��
	if($ENV{'REQUEST_METHOD'} eq "POST") {
		$postflag = 1;
	}

	# CGI.pm ���g���ꍇ
	foreach($q->param()){
		$query{$_} = $q->param($_);
			if($UseEncoding){ push(@query_value,$query{$_}); }
		push(@query_key,$_);
	}

	# �����R�[�h����
	if($UseEncoding){
		($convert_from) = Mebius::Encoding::all_queries_guess();
	}

	# �N�G���W�J
	foreach(@query_key){

		# �Ǐ���
		my $key = $_;
		my $val = $query{$_};

			# �A�b�v���[�h�t�@�C��������ꍇ
			if($multi_part_flag){
				if($key eq "upfile" && $val){ $upload_flag = 1; next; }
			}

			# �R�[�h�ϊ� ( �^�O���u�ŕϊ�����ϐ����w�肵�Ă��� )
			if($UseEncoding){
					if($val && $convert_from){
						Mebius::Encoding::from_to($convert_from,"shift_jis",$val);
					}
			}


		# �G�X�P�[�v�O�̃N�G�����L������
		$query_not_escaped{$key} = $val;

		# �G�X�P�[�v
		my($value_escaped) = Mebius::Escape("",$val);

		# �l���`
		$in{$key} = $value_escaped;
		$ch{$key} = 1;

			if($postbuf){ $postbuf .= "&$key=" . (Mebius::Encode("",$value_escaped)); }
			else{ $postbuf = "$key=" . (Mebius::Encode("",$value_escaped)); }

	}

	# �N�G���S�̂̃G�X�P�[�v�l���` 
	($postbuf_query_esc) = Mebius::Escape("",$postbuf);


}

#-------------------------------------------------
#  HTML�w�b�_ - strict
#-------------------------------------------------
sub header{

# �錾
my($type,$use) = @_;
if(ref $type eq "HASH"){ $use = $type; }
my(%type); foreach(split(/\s/,$type)){ $type{$_} = 1; } # �����^�C�v��W�J
my($cssfile,$css_fontsize,$now_url_box,$length,$meta_jump,$help_area,$google_header_form,$linkprof,%js_count,%css_count);
my($google_selected1,$bbs_google_find,$head_message1,$head_message2,$javascript_files,$css_files);
my($google_search_submit_title,$sorcial_line,$meta_tag_free,$head_page_title,$head_link6,$head_javascript_line,$topics_area,%use_history,$ivent_html);
our($backurl,$thisis_bbstop,$agent,$scriptname,$home_title);
our($kflag,$headflag,$server_domain,$postflag,$google_oe,$thisis_toppage,%in);
our($title,$mode,$time,$cookie,$cfollow,$ccount,$cfontsize,$csecret,$follow_line,$alocal_mode);
our($nosearch_mode,$no_headerset,$referer,$sub_title,$pmfile,$myadmin_flag);
our($otherserver_link,$canonical,$head_javascript,$meta_robots,$noindex_flag,$divide_url);
our($head_link0_25,$head_link0_5,$head_link1,$head_link1_25,$head_link1_5,$head_link2,$head_link2_5,$head_link3,$head_link4,$head_link5);
our($k_access,$postbuf,$device_type,$style);
our($thismonth,$thishour,$today,$meta_nocache,$main_mode,$moto,$requri,$concept,$auth_url,$bot_aceess);
our($guide_url,$door_url,$hometitle,$home,$topics_line_reshistory,$one_line_reshistory,$bot_access,@javascript_files,@css_files,$cnumber);
my $css_text = our $css_text;
my($param) = Mebius::query_single_param();
my($init_directory) = Mebius::BaseInitDirectory();
my($my_real_device) = Mebius::my_real_device();
my($my_use_device) = Mebius::my_use_device();
my($my_account) = Mebius::my_account();
my($init_directory) = Mebius::BaseInitDirectory();

	# �g�у��[�h�̏ꍇ
	if($kflag || $device_type eq "mobile"){ &kheader(@_); return; }

# �e��f�[�^���擾
my($myaccount) = Mebius::my_account();

	# �X�}�t�H�U�蕪��
	if($my_real_device->{'smart_flag'}){
		$google_search_submit_title = qq(����);
	}
	else{
		$google_search_submit_title = qq(Google ����);
	}

	# �^�C�g����`
	if(defined $use->{'Title'}){
		$head_page_title = $use->{'Title'};
			if($use->{'source'} eq "utf8"){ shift_jis($head_page_title); }
	}
	else{ $head_page_title = $sub_title; }

	# �w�b�_�̏d���������֎~
	if($headflag){ return; }
$headflag = 1;

	# ���u�ŋ߂̃��X�v���擾
	if(!Mebius::Admin::admin_mode_judge() && Mebius::Server::bbs_server_judge() && !Mebius::Switch::light()){
		require "${init_directory}part_history.pl";
			if($use->{'ReadThread'}){
				$use_history{'ReadThread'} = 1;
				$use_history{'read_thread_res_number'} = $use->{'read_thread_res_number'};
			}
		($topics_line_reshistory,$one_line_reshistory) = get_reshistory("TOPICS ONELINE My-file Not-host Allow-renew-status",undef,\%use_history,undef,undef,10);
	}

	# �t�H���[���擾
	if(!Mebius::Admin::admin_mode_judge() && Mebius::Server::bbs_server_judge() && !Mebius::Switch::light()){

			if($ENV{'HTTP_COOKIE'} && ($cfollow || $ccount >= 2) ){
				require "${init_directory}part_follow.pl";
				($follow_line) = get_follow("HEADER");
			}
	}

	# �T�[�o�[�؂�ւ������N
	#if($server_domain eq "mb2.jp"){ $otherserver_link = qq(<a href="http://aurasoul.mb2.jp/">�ʏ��</a>); }
	#else{ $otherserver_link = qq(<a href="http://mb2.jp/">��y��</a>); }

	#$otherserver_link = qq(<a href="http://mb2.jp/">�f����</a>);

	# �X�e�[�^�X�R�[�h���o��
	if($type{'Status404'}){ print "Status: 404 NotFound\n"; }

	# �N�b�L�[�������ꍇ��A����ꍇ�����m���ŁA�{�������ŃN�b�L�[���Z�b�g
	if((!$cookie || rand(5) < 1 || Mebius::AlocalJudge()) && !$no_headerset && $ENV{'REQUEST_METHOD'} eq "GET" && !$my_account->{'login_flag'}) {
		Mebius::Cookie::set_main();
	}

	# ��HTTP �w�b�_
	{
		print "Content-type: text/html; charset=shift_jis\n";
		print "Vary: User-Agent\n";
			if(!$ENV{'REQUEST_METHOD'} ne "POST"){
				print "Pragma: no-cache\n";
				print "Cache-Control: no-cache\n";
			}
		print "\n";
	}

	# Canonical����
	if($canonical){
		$canonical = qq(<link rel="canonical" href="$canonical">\n);
	}
	# Https �y�[�W�� Http �ւ� canonical ��ݒ�
	else{
		($canonical) = Mebius::AutoCanonical({ TypeHttpsToHttp => 1 });
	}



	# META ���{�b�g�^�O
	if($meta_robots eq ""){
			if($noindex_flag || $use->{'RobotsNoIndex'}){ $meta_robots = qq(<meta name="robots" content="noindex,nofollow,noarchive">\n); }
			elsif($use->{'RobotsNoIndexFollow'}){ $meta_robots = qq(<meta name="robots" content="noindex,follow,noarchive">\n); }
			else{ $meta_robots = qq(<meta name="robots" content="noarchive">\n); }
	}

	# �C�ӂ̃��^�^�O
	if($main::meta_tag_free){
		$meta_tag_free = $main::meta_tag_free;
	}

	# �X�}�t�H�U�蕪��
	if($my_use_device->{'smart_phone_flag'}){
		$meta_tag_free .= qq(<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=0">\n);
		#$meta_tag_free .= qq(<meta name="viewport" content="width=device-width,initial-scale=1.0"$main::xclose>\n);
		$meta_tag_free .= qq(<meta name="format-detection" content="telephone=no"$main::xclose>\n);
	}
	elsif($my_use_device->{'id'} eq "DSi"){
		$meta_tag_free .= qq(<meta name="viewport" content="width=device-width">\n);
	}
	# �^�u���b�gPC����
	elsif($my_real_device->{'type'} eq "Tablet-pc"){
		$meta_tag_free .= qq(<meta name="viewport" content="width=device-width"$main::xclose>\n);
	}

	# ���W�����v ( meta refresh ) �̐ݒ�
	{
		my($jump_url);
		if(defined $use->{'RefreshURL'}){ $jump_url = $use->{'RefreshURL'}; }
		elsif(defined $main::jump_url){ $jump_url = $main::jump_url; }
			if($jump_url){
				my($jump_second);
					if(defined $use->{'RefreshSecond'}){ $jump_second = $use->{'RefreshSecond'}; }
					elsif(defined $main::jump_sec) { $jump_second = $main::jump_sec; }
				$meta_jump = qq(<meta http-equiv="refresh" content="${jump_second};url=${jump_url}">\n);
			}
	}

	# ��CSS�̒�`
	{
		# ��{�X�^�C��
		unshift(@css_files,"bas");

			# ��CSS���`
			if($style){
				$style =~ s!(\.\.)?/style/!!g;
				my($file,$tail) = split(/\./,$style);
				push(@css_files,$file);
			}

			# �Ǘ��p
			if(Mebius::Admin::admin_mode_judge()){
				push(@css_files,"admin");
			}

		# �X�}�t�H�����X�^�C��
		if($my_use_device->{'smart_css_flag'}){ push(@css_files,"smart_phone"); }
		elsif($my_use_device->{'type'} =~ /^(Tablet-pc|Portable-game-player)$/){ push(@css_files,"tablet"); }

		# �O��CSS�t�@�C����W�J
		my $css_count;
		@css_files = grep( !$css_count{$_}++, @css_files );
			my($main_server_domain) = Mebius::main_server_domain();
			my($procotol) = Mebius::procotol_type();
			foreach(@css_files){
				$css_files .= qq(<link rel="stylesheet" href=").e($procotol).qq(://).e($main_server_domain).qq(/style/$_.css" type="text/css">\n);
			}

	}

	# �d������O��Javascript�t�@�C�����폜
	@javascript_files = grep( !$js_count{$_}++, @javascript_files ) ;
	# �O��Javascript�t�@�C����W�J
	foreach(@javascript_files){
		$javascript_files .= qq(<script type="text/javascript" src="/skin/$_.js"></script>\n);
	}


	# Head �^�O���� Javascript
	if($use->{'HeadTagJavascript'}){ $head_javascript_line = $use->{'HeadTagJavascript'}; }
	elsif($head_javascript){ $head_javascript_line = $head_javascript; }

print qq(<!DOCTYPE html>\n);
print qq(<html lang="ja">\n);

print qq(<head>
<meta http-equiv="content-type" content="text/html; charset=shift_jis">
<title>$head_page_title</title>
$meta_robots$canonical$meta_jump$meta_nocache$meta_tag_free
$css_files
);


	# COOKIE ����}�C�ݒ���擾
	if($cfontsize){ $css_fontsize = qq(body{font-size:$cfontsize%;}\n); }

	# IE8 �Ή�
	if($agent =~ /MSIE 8/){
		$css_text .= qq(textarea.wide{width:750px;}\n);
		$css_text .= qq(.table1{margin-left:auto;margin-right:auto;}\n);
	}

	# Firefox CSS�Ή�
	if($agent =~ /Firefox/){
		$css_text .= qq(.body1{overflow:visible;});
	}


	# �C�ӂ̂b�r�r
	if($css_text || $cfontsize){
		$css_text =~ s/(\n{2,})/\n/g;
		$css_text =~ s/\t//g;
		print qq(<style type="text/css">\n);
		print qq(<!--\n);
		print qq($css_fontsize$css_text\n);
		print $use->{'inline_css'};
		print qq(-->\n);
		print qq(</style>\n);
	}


	# �C�ӂ�Javascript
	if($main::javascript_text){
		print qq(<script type="text/javascript">\n);
		print qq(<!--\n);
		print qq($main::javascript_text\n);
		print qq(-->\n);
		print qq(</script>\n);
	}

	# Body �^�O�� Javascript
	my $body_javascript;
	if($use->{'BodyTagJavascript'}){ $body_javascript = $use->{'BodyTagJavascript'} ; }
	elsif($main::body_javascript){ $body_javascript = $main::body_javascript; }

	if($main::real_device{'id'} eq "iPhone" || $main::real_device{'id'} eq "iPod"){ $body_javascript = ""; }


#print "$javascript_files";
print "$head_javascript_line";

my($google_analytics) = Mebius::Gaget::google_analytics();
print "$google_analytics\n";

# BODY �����J�n
print qq(</head><body$body_javascript id="body_top">);

	# �Ǘ��҂ւ̕\�����e
	if(Mebius::AlocalJudge() || ($main::bbs{'concept'} =~ /Local-mode/ && $myadmin_flag >= 5)){
		print qq(<div style="line-height:1.4em;word-spacing:0.2em;">Time�F $time | Scriptname�F $scriptname);
		print qq(<br>Backurl�F $backurl | Referer�F $referer</div>);
	}

	# ���_�C���N�g��
	if($divide_url && $myadmin_flag >= 5){
		my $url = $divide_url;
		$url =~ s/&/&amp;/g;
		print qq(<div>Divide-Mobile�F <a href="$url">$url</a></div>);
	}


	# �f�����̌����Z���N�g�����A�����`�F�b�N������
	if($thisis_toppage || $nosearch_mode || $type =~ /Not-search-me/){ $google_selected1 = " selected"; }
	else{
		my($domain,$search_title);
			if($my_real_device->{'smart_flag'}){ $search_title = "�R���e���c"; }
			else{ $search_title = $main::title; }
			if($server_domain eq "aurasoul.mb2.jp"){ $domain = "aurasoul.mb2.jp";}
			else{ $domain = "mb2.jp";}
			if($moto eq "auth"){	$bbs_google_find = qq(<option value="sns.mb2.jp" selected>$search_title</option>); }
			else{	$bbs_google_find = qq(<option value="$domain/_$moto" selected>$search_title</option>); }
	}

	# ������ւ̃����N
	if($csecret =~ /[a-z0-9]/){
		my($i);
			foreach(split(/ /,$csecret)){
					if($_ !~ /^([a-z0-9]{2,})$/){ next }
				$i++;
				my $title = qq($_);
					if($i < 2){ $title = qq(����� ( $_ )); } 
				$linkprof .= qq(<a href="http://aurasoul.mb2.jp/_sc$_/">$title</a> - );
			}
	}

	# �L�^
	if($csecret){
		Mebius::AccessLog(undef,"CSECRET","�閧��Cookie �F $main::csecret");
	}

	# �}�C�y�[�W�ւ̃����N
	if($ENV{'HTTP_COOKIE'}){
			if($mode eq "my"){ $linkprof .= qq(�}�C�y�[�W); }
			else{ $linkprof .= qq(<a href="http://mb2.jp/_main/?mode=my">�}�C�y�[�W</a>); }
			if($my_use_device->{'wide_flag'}){
					if($mode eq "my"){ $linkprof .= qq( ( �ݒ� ) ); }
					else{ $linkprof .= qq( ( <a href="${main::main_url}?mode=settings#EDIT">�ݒ�</a> )); }
			}
		$linkprof .= qq( - );
	}

	# �}�C�A�J�E���g�ւ̃����N
	if($ENV{'HTTP_COOKIE'}){

			if($myaccount->{'login_flag'}){
				$linkprof .= qq(<a href="${auth_url}${pmfile}/feed">\@).e($my_account->{'id'}).qq(</a> - );
			} else {
				my($request_url) = Mebius::request_url();
				my($request_url_encoded) = Mebius::Encode(undef,$request_url);
				$linkprof .= qq(<a href="${auth_url}?backurl=$request_url_encoded">���O�C��</a> - );
			}
	}

	# �V�`���b�g��ւ̃����N
	if($myaccount->{'login_flag'} && time > $my_account->{'firsttime'} + 60*24*60*60 && $my_use_device->{'wide_flag'}){
		$linkprof .= qq(<a href="http://aurasoul.mb2.jp/chat/tmb3/mebichat.cgi">�`���b�g</a> - ); 
	}

# ��y�ŁA�ʏ�ł̐؂�ւ�
#$linkprof .=  qq($otherserver_link - );

	# �Ǘ����[�h�ւ̃����N
	if($myadmin_flag >= 1){
		my($buf);
			if($postbuf && !$postflag){ $buf = "?$postbuf"; $buf =~ s/(&)?moto=([a-z0-9]+)//g; $buf =~ s/\?(&)/?/g; $buf =~ s/\?$//g; $buf =~ s/&/&amp;/g;  }
		$linkprof .= qq(<a href="$main::jak_url$moto.cgi$buf" class="red">�Ǘ�</a> - );
	}

# �ŏI�����N
$help_area = qq($linkprof<a href="$guide_url">�K�C�h</a>);

# Google������
$google_oe = qq(<input type="hidden" name="oe" value="Shift_JIS">);
	if($agent =~ /Firefox/){ $google_oe = undef; }



$google_header_form .= qq(
<form method="get" action="https://www.google.co.jp/search" class="nomargin">
<div class="google_bar">
<a href="https://www.google.co.jp/" rel="nofollow">
<img src="http://www.google.co.jp/logos/Logo_25wht.gif" class="google_img" alt="Google"></a>
<span class="vmiddle">
<select name="sitesearch" class="site_select">);

	# �X�}�t�H�U�蕪��
	if($my_real_device->{'smart_flag'}){
		$google_header_form .= qq(<option value="mb2.jp"${google_selected1}>�T�C�g�S��</option>\n);
	}
	else{
		$google_header_form .= qq(<option value="mb2.jp"${google_selected1}>���r�E�X�����O</option>\n);
	}

$google_header_form .= qq(
$bbs_google_find
<option value="">�E�F�u�S��</option>
</select>
<input type="$main::parts{'input_type_search'}" name="q" size="31" maxlength="255" value="" class="ginp">
<input type="submit" name="btnG" value="$google_search_submit_title">
<input type="hidden" name="ie" value="Shift_JIS">
$google_oe
<input type="hidden" name="hl" value="ja">
<input type="hidden" name="domains" value="mb2.jp">
</span></div>
<div class="help_block">$help_area</div>
</form>
);


	# �w�b�_�����N���`
	if(!Mebius::Admin::admin_mode_judge()){

			#if($backurl){ $head_link0_25 = qq(<a href="$backurl">�߂�</a> &gt; ); }

			# �����N�O
			#if(!$head_link0_5){ $head_link0_5 = qq(<a href="$door_url">��</a>); }

			#
			if($use->{'BBS_TOP_PAGE'}){
				$head_link0_5 .= qq(TOP);
			} else {
				$head_link0_5 .= qq(<a href="http://mb2.jp/">TOP</a>);
			}

			# �����N�P
			#if($head_link1 eq "0"){ $head_link1 = ""; }
			#elsif($head_link1 eq ""){
			#		if($my_use_device->{'wide_flag'}){
			#			$head_link1 = qq(&gt; <a href="$home">$hometitle</a>);
			#		}	else {
			#			$head_link1 = qq(&gt; <a href="$home">TOP</a>);
			#		}

			#}

			# �����N�Q
			if($head_link2 eq "0"){ $head_link2 = ""; }
				elsif($head_link2 eq ""){
					my $bcl;
						if( our $head_title){ $bcl = our $head_title; } else { $bcl = our $title; }
					if($thisis_bbstop){ $head_link2 = "&gt; $bcl"; }
					else{ $head_link2 = qq(&gt; <a href="http://$server_domain/_$moto/">$bcl</a>); }
			}

			# �t�q�k�\�����`
			if($ENV{'REQUEST_URI'} && $ENV{'REQUEST_METHOD'} eq "GET"){

				my($url);
					if(length($ENV{'REQUEST_URI'}) <= 40){

						$url = "http://${server_domain}$ENV{'REQUEST_URI'}";
					}
				$length = int(length($url)/2);
					if($length > 50){ $length = 50; }

				# ���`
				$now_url_box .= qq(<input size="50" style="width:${length}em;" type="text" value=") . Mebius::Escape(undef,$url) . qq(" onclick="javascript:select();" class="nowurl" id="now_url_box">�@);

			}
			else{ $now_url_box = qq(&nbsp;); }

			# ���e��������g�s�b�N�X��\��
			if($topics_line_reshistory && $type !~ /Simple-source/){
				$topics_area .= qq(<div class="topics_line">$topics_line_reshistory</div>);
			}
			else{
				$topics_area .= qq(<div class="topics_line_empty"></div>);
			}

			# �����̑��N������
			if($cookie || $k_access){
					if($thishour >= 5 && $thishour  <= 8){
				$head_message2 .= qq(<div style="text-align:center;width:85%;margin:0.5em auto 1.0em auto;font-size:90%;"><a href="http://aurasoul.mb2.jp/_early/">�`$thismonth��$today���A���N���ł����H�`</a></div>);
					}
			}

		if($ENV{'HTTP_COOKIE'} && time < 1333217960 + (15)*60*60){
		$head_message2 .= qq(<div style="text-align:center;width:85%;margin:0.5em auto 1.0em auto;clear:both;"><a href="http://aurasoul.mb2.jp/wiki/guid/%A5%E1%A5%D3%A5%DE%A5%CD%A1%BC" class="blank" target="_blank">�`���܂ɉ��傷��`</a> <span class="red">New!</span></div>);
	}

			# �\�[�V�����{�^��
			if($ENV{'REQUEST_METHOD'} eq "GET" && !$main::secret_mode && $type !~ /Not-sorcial-button/){

				my $gaget = new Mebius::Gaget;

				# ���r����SNS�̓��L�{�^��
				#	if($my_account->{'login_flag'} && !$use->{'NotMebiusDiaryButton'}){
				#		my($request_url) = Mebius::request_url();
				#		my($diary_button) = $gaget->mebius_diary_button("$head_page_title\n$request_url");
				#		Mebius::Encoding::utf8_to_sjis($diary_button);
				#		$sorcial_line .= $diary_button;
				#		$sorcial_line .= qq(�@);
				#	}

				# Twitter
				if(!$param->{'not_twitter'}){
					($sorcial_line) .= $gaget->tweet_button();
				}

				# LINE �ő���
				if($my_use_device->{'smart_flag'} || $my_use_device->{'tablet_flag'}){
					$sorcial_line .= qq( - );
					($sorcial_line) .= $gaget->line_button();
				}

					# Google +1 �{�^��
					if($my_real_device->{'wide_flag'}){	$sorcial_line .= "�@" . Mebius::Gaget::google_plusone_button(); }


			}

	# �p���������X�g�̒ǉ�
	if($use->{'BCL'}){
			foreach my $bcl (@{$use->{'BCL'}}){
					if($use->{'source'} eq "utf8"){ shift_jis($bcl); }
				$head_link6 .= qq( &gt; $bcl);
			}
	}

# BCL
my $bcl_line = qq($head_link0_5 $head_link1 $head_link1_25 $head_link1_5 $head_link2 $head_link2_5 $head_link3 $head_link4 $head_link5 $head_link6);


			# ���C�x���g
			my $tell_area;
			{
				($ivent_html) = shift_jis(Mebius::ivent_html());
				#$tell_area .= qq(<div class="red center">�������e�i���X�ɂ��A�f���ւ̓��e���~���ł��B�ĊJ\�\\��c12/6 <strike>12:00</strike> 16:00 (�����̏ꍇ������܂�)</div>);
					if(time < 1354779076 + 3*24*60*60){
						$tell_area .= qq(<div class="guide green center">�����m�点�c�f�����ЂƂ̃T�[�o�[�ɂ܂Ƃ܂�܂����B<a href="http://aurasoul.mb2.jp/wiki/guid/2012.12.06+%C4%CC%BE%EF%C8%C7%A4%C8%B8%E4%B3%DA%C8%C7%A4%F2%C5%FD%B9%E7%A4%B7%A4%DE%A4%B7%A4%BF">���ڍ�</a></div>);
					}
			}


		# �E�F�u�y�[�W�w�b�_�̈�̏o��
		print qq(<div class="bar">);
			# �X�}�t�H��
			if($my_use_device->{'smart_flag'}){
				#$bcl_line =~ s/(\s+)?(&gt;)(\s+)?/$2/g;
				print qq(<div class="help_block">$help_area - $sorcial_line</div>);
				print $ivent_html;
				print qq(<div class="head_bar">);
				print qq(<div class="link_box"><nav class="inline">$bcl_line</nav></div>);
				#print qq(<div class="url_box"></div>);
				print qq(</div>);

			}
			# �f�X�N�g�b�v��
			else{
				print qq($google_header_form$follow_line);
				print $ivent_html;
				print qq(<div class="head_bar">);
				print qq(<div class="link_box"><nav>$bcl_line</nav></div>);

				print qq(<div class="url_box">$now_url_box $sorcial_line</div>);
				print qq(</div>);
			}

		print qq($head_message1);
		print qq(</div>);
		print $tell_area;
		print $topics_area;
		print qq($head_message2);

	}

	# �Ǘ����[�h�̃i�r�Q�[�V���������N
	if(Mebius::Admin::admin_mode_judge()){
		print Mebius::Admin::html_header_navigation();
	}

	# ���`�p��DIV�^�O�������o��
	if($use->{'BodyPrint'} || $type =~ /Body-print/ || Mebius::Admin::admin_mode_judge()){ print qq(<div class="body1">); }

}

#-------------------------------------------------
#  HTML�t�b�^ - strict
#-------------------------------------------------
sub footer{

# �錾
my($basic_init) = Mebius::basic_init();
my($type,$use) = @_;
if(ref $type eq "HASH"){ $use = $type; }
my($line,$allsearch_form,$google_search_box);
my($my_real_device) = Mebius::my_real_device();
my($my_use_device) = Mebius::my_use_device();
my($my_account) = Mebius::my_account();

our($original_maker,$footer_plus,$secret_mode,$kflag,$cgold,$csilver,$one_line_reshistory,$device_type);
our($myadmin_flag,$postbuf,$cookie,$alocal_mode);

	# �g�єł̏ꍇ
	if($kflag || $device_type eq "mobile"){ &kfooter(@_); return; }

	# ���`�p��DIV�^�O�������o��
	if($use->{'BodyPrint'} || $type =~ /Body-print/ || Mebius::Admin::admin_mode_judge()){ print qq(</div>); }

$line .= qq(<footer>);
$line .= qq(<div class="footerlink clear">);

	# �ʏ탂�[�h
	if(!Mebius::Admin::admin_mode_judge()){
			# �X�}�t�H��
			if($my_use_device->{'smart_flag'}){
				$line .= qq(<a href="http://aurasoul.mb2.jp/wiki/guid/%A5%D7%A5%E9%A5%A4%A5%D0%A5%B7%A1%BC%A5%DD%A5%EA%A5%B7%A1%BC">�v���C�o�V�[</a>��);
			}
			# �f�X�N�g�b�v��
			else{
					# �X�N���v�g�̔z�z��
					if($original_maker){ $line .= qq($original_maker��); }
				# �X�N���v�g�̉�����
				$line .= qq(<a href="http://aurasoul.mb2.jp/wiki/guid/%A5%D7%A5%E9%A5%A4%A5%D0%A5%B7%A1%BC%A5%DD%A5%EA%A5%B7%A1%BC">�v���C�o�V�[�|���V�[</a>��);
					if(!$main::sns{'flag'}){ $line .= qq(<a href="${main::main_url}past.html">�ߋ����O</a>��); }
			}

			#if(!$secret_mode){ $line .= qq(<a href="http://aurasoul.mb2.jp/_delete/">�폜�˗�</a>��); }
		$line .= qq(<a href="http://$main::base_server_domain/etc/amail.html">���₢���킹</a>);

			# ���݂̕\��
			if($cgold ne ""){
				$line .= qq(��<img src="/pct/icon/gold1.gif" alt="����" title="����" class="noborder">);
					if($cgold >= 0){ $line .= qq( $cgold); }
					else{ $line .= qq( <span class="blue">$cgold</span>); }
				$line .= qq( \( $main::server_domain \) );
			}
	# �Ǘ����[�h
	}	else{
		$line .= qq(<a href="https://mb2.jp/jak/fjs.cgi?mode=url">�t�q�k�ϊ�</a>��<a href="$basic_init->{'guide_url'}%A5%E1%A5%D3%A5%A6%A5%B9%A5%EA%A5%F3%A5%B0%B6%D8%C2%A7">�֑�</a>��<a href="$basic_init->{'guide_url'}wiki/guid/?action=LIST">�K�C�h�ꗗ</a>��<a href="$basic_init->{'admin_report_bbs_url'}">�폜�˗���</a>��<a href="index.cgi?mode=vlogined">���O�C������</a>��<a href="$basic_init->{'main_admin_url'}?mode=cdl">�Ǘ��ԍ�</a>��$main::adroom_link);
	}

$line .= qq(\n</div>);

# �ǉ����郉�C��
if($footer_plus){ $line .= qq(<div class="footerlink clear">$footer_plus</div>); }

# �S�����{�b�N�X���擾
#require "${main::int_dir}part_newlist.pl";
#($allsearch_form) = Mebius::Newlist::allsearch_form("FOTTER",$main::in{'word'},"","","FOOTER");
#$line .= qq(<div class="allsearch_form_footer allwidth">$allsearch_form</div>);

	if($my_use_device->{'smart_flag'}){
		$google_search_box = qq(
		<div class="right margin">
		<form action="http://www.google.co.jp/cse" id="cse-search-box">
		  <div>
		    <input type="hidden" name="cx" value="partner-pub-7808967024392082:3089660928">
		    <input type="hidden" name="ie" value="Shift_JIS">
		    <input type="text" name="q" size="30">
		    <input type="submit" name="sa" value="����">
		  </div>
		</form>

		<script type="text/javascript" src="http://www.google.co.jp/coop/cse/brand?form=cse-search-box&amp;lang=ja"></script>
		</div>
		);

	} else {
		$google_search_box = qq(
		<div class="right margin">
		<form action="http://www.google.co.jp/cse" id="cse-search-box">
		  <div>
		    <input type="hidden" name="cx" value="partner-pub-7808967024392082:1612927722" />
		    <input type="hidden" name="ie" value="Shift_JIS" />
		    <input type="text" name="q" size="55" />
		    <input type="submit" name="sa" value="����" />
		  </div>
		</form>

		<script type="text/javascript" src="http://www.google.co.jp/coop/cse/brand?form=cse-search-box&amp;lang=ja"></script>
		</div>
		);
	}

$google_search_box =~ s/\t//g;
$line .= $google_search_box;

	# ���e������\��
	if($one_line_reshistory){
		$line .= qq(
		<div class="footer_res_history">$one_line_reshistory</div>
		);
	}


		# �[���؂�ւ��t�H�[��
	if($ENV{'REQUEST_METHOD'} eq "GET"){
		my($init_directory) = Mebius::BaseInitDirectory();
		require "${init_directory}main_mypage.pl";
		($line) .= Mebius::Mypage::SelectDeviceForm();
	} else {
		$line .= qq(<div></div>);
	}

	# �X�}�t�H�p
	if($my_use_device->{'smart_flag'}){
		$line .= qq(<div class="right padding"><a href="#body_top" class="move">���y�[�W�ŏ㕔��</a></div>);
	}

	# ���Ǘ��҂݂̂̕\��
	if($myadmin_flag >= 5 || Mebius::AlocalJudge()){
		$line .= qq(<div class="line-height-large">);

		# State �� �J�E���g��
		#my($state_count) = Mebius::State::GetElseCount();
		#$line .= qq(State Else Count : $state_count / );

		# State �� �J�E���g���e
		#if(Mebius::AlocalJudge()){
		#	my($state_count_line);
		#	my($state_count) = Mebius::State::GetElseCountMulti();
		#		foreach my $key1 ( sort keys %$state_count ){
		#				foreach my $key2 ( sort keys %{ $state_count->{$key1} } ){
		#						foreach my $key3 ( sort keys %{ $state_count->{$key1}{$key2} } ){
		#							$state_count_line .= qq(<li><strong>$key1 : $key2 : $key3</strong> : $state_count->{$key1}{$key2}{$key3} </li>);
		#						}
		#				}
		#		}
		#	$line .= qq(<ol>$state_count_line</ol>);
		#}

		$line .= qq(Postbuf: ) . Mebius::Escape("",$postbuf);
		$line .= qq(<br><br>);

			# Cookie��\��
			if(Mebius::AlocalJudge() || $my_account->{'master_flag'}){
				$line .= qq(<div class="line-height">Cookie:<br$main::xclose>);
					foreach(split(/;/,$cookie)){
						my($escaped_line) = Mebius::Escape(undef,$_);
						my($cookie_name,$cookie_body) = split(/=/,$escaped_line);
						$line .= qq(<span class="red">$cookie_name</span>=<span class="green">$cookie_body</span>;<br$main::xclose>);
					}
				$line .= qq(</div>);
			}

			# ���t�@����\��
			if($main::referer){
				my $referer_escaped = Mebius::Escape(undef,$main::referer);
				$line .= qq(<div style="margin-top:1em;color:purple;">Referer: <a href="$referer_escaped">$referer_escaped</a></div>);
			}

			# mod_perl
			if($ENV{'MOD_PERL'}){
				$line .= qq(<div> MOD_PERL : $ENV{'MOD_PERL'}</div>)
			}

		$line .= qq(</div>);

	}



# HTML �̏I��
my($google_plusone_script) = Mebius::Gaget::google_plusone_script() if($my_real_device->{'wide_flag'} && $ENV{'REQUEST_METHOD'} eq "GET" && !$main::secret_mode && $type !~ /Not-sorcial-button/);

$line .= qq($google_plusone_script);

$line .= qq(</footer>\n);


	# Javascript�O���t�@�C��
	if($use->{'Jquery'} || $use->{'BeforeUnload'}){
		$line .= qq(<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>\n);
	}


	# ��{ JS �t�@�C��
	{
		my $year_month_day = "2013-03-13";
		if($my_real_device->{'id'} eq "DSi"){
			push( our @javascript_files,"basic_not_analyze-$year_month_day");
		}
		else{
			push( our @javascript_files,"basic-$year_month_day");
		}
	}

	if(Mebius::Admin::admin_mode_judge()){
		push( our @javascript_files,"admin");
	
	}

	# �d������O��Javascript�t�@�C�����폜
	{
		my %js_count;
		our @javascript_files = grep( !$js_count{$_}++, our @javascript_files ) ;
	}

	# �O��Javascript�t�@�C����W�J
	foreach( our @javascript_files){
		my($main_server_domain) = Mebius::main_server_domain();
		my($procotol) = Mebius::procotol_type();
		$line.= qq(<script type="text/javascript" src=").e($procotol).qq(://).e($main_server_domain).qq(/skin/$_.js"></script>\n);
	}

	# �C�ӂ�Javascript�t�@�C��
	if(ref $use->{'javascript_files'} eq "ARRAY"){
			foreach(@{$use->{'javascript_files'}}){
				my $js_file;
					if($_ =~ /\.js$/){
						$js_file = $_;
					} else {
						$js_file = qq(/skin/$_.js);
					}
				$line .= qq(<script type="text/javascript" src="$js_file"></script>\n);
			}
	}


	# Twitter
	if(!Mebius::Admin::admin_mode_judge()){
		$line .= qq(
		<script>
		<!--
		!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
		//-->
		</script>
		);
	}

	if($use->{'BeforeUnload'}){
		my($before_unload_javascript) = shift_jis(Mebius::Javascript::before_unload_use_form());
		($line) .= $before_unload_javascript;
	}

$line .= qq(</body></html>);

	if($type !~ /GET/){ print qq($line); }

# ���`
$line =~ s/\t//g;

# ���^�[��
return($line);

}

#-----------------------------------------------------------
# XIP ���擾 - strict
#-----------------------------------------------------------
sub get_xip{

# �錾
my($addr,$agent,$k_access) = @_;
my($xip,$xip_enc,$no_xip_action);

# �U�蕪��
if($k_access eq "DOCOMO" || $k_access eq "AU"){ $xip = $agent; }
elsif($k_access){ $no_xip_action = 1; $xip = $agent; }
else{ $xip = $addr; }

# �G���R�[�h
($xip_enc) = Mebius::Encode("",$xip);

# ���^�[��
return($xip,$xip_enc,$no_xip_action);

}

#-----------------------------------------------------------
# �N�b�L�[�擾 - strict
#-----------------------------------------------------------
sub get_cookie{

Mebius::get_cookie(@_);

}

#-----------------------------------------------------------
# ��荞�ݏ��� ( ���̃T�u���[�`�����̏������s���鎞�́A���� $int_dir �̒l�͐ݒ肳��Ă��� )
#-----------------------------------------------------------
our($int_dir);
sub repairform{ require "${int_dir}main_repairurl.pl"; &get_repairform(@_); }
sub error{ require "${int_dir}part_error.pl"; &do_error(@_); }
sub set_cookie_old{ my($init_directory) = Mebius::BaseInitDirectory(); require "${init_directory}part_setcookie_old.pl"; &do_set_cookie_old(@_); }
sub redun{ require "${int_dir}part_redun.pl"; &do_redun(@_); }
sub divide{ require "${int_dir}part_divide.pl"; &do_divide(@_); }
sub get_status{ require "${int_dir}part_getstatus.pl"; &do_get_status(@_); }
sub kget_items{ require "${int_dir}k_header.pl"; &do_kget_items(@_); }
sub access_log{ require "${int_dir}part_accesslog.pl"; &do_access_log(@_); }
sub access_log2{ require "${int_dir}part_accesslog2.cgi"; &do_access_log2(@_); }
sub kerror { require "${int_dir}k_error.pl"; &do_kerror(@_); }
sub kheader{ require "${int_dir}k_header.pl"; &do_kheader(@_); }
sub kfooter{ require "${int_dir}k_header.pl"; &do_kfooter(@_); }
sub http404{ require "${int_dir}part_404.pl"; &do_404(@_); }
sub axscheck{ require "${int_dir}part_axscheck.pl"; &do_axscheck(@_); }
sub id{ Mebius::my_id(@_); }
sub trip{ require "${int_dir}part_axscheck.pl"; &get_trip(@_); }
sub lock{ Mebius::lock(@_); }
sub unlock{ Mebius::unlock(@_); }
sub backurl{ require "${int_dir}part_backurl.pl"; &get_backurl(@_); }
sub mail{ require "${int_dir}part_email.cgi"; &email(@_); }
sub oldremove{ require "${int_dir}part_files.pl"; &do_oldremove(@_); }
sub minsec{ require "${int_dir}part_timer.pl"; &do_minsec(@_); }
sub check{ print qq(Content-type:text/html\n\n); print $_[1]; exit; }



1;
