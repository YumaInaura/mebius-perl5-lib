
use strict;
package Mebius::Javascript;

#-----------------------------------------------------------
# 投稿フォームに入力があったまま移動しようとすると、ダイアログを表示する
#-----------------------------------------------------------
sub before_unload_use_form{

#			return '投稿が完了していません。このまま移動しますか？';

my $return = q(
<script>
$(function(){

	$("form textarea").change(function() {
		$(window).on('beforeunload', function() {
			return '送信が済んでいません。';
		});
	});

	$("input[type=submit]").click(function() {
		$(window).off('beforeunload');
	});
});
</script>
);


}

1;
