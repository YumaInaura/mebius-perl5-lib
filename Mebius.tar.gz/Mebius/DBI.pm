
use strict;
use DBI;
use Mebius::Dos;
use Mebius::UserData;
package Mebius::DBI;

#-----------------------------------------------------------
# 設定
#-----------------------------------------------------------
sub default_engine{
"MyISAM";
}

#-----------------------------------------------------------
# データベースに接続
#-----------------------------------------------------------
sub connect{

my($self);
my($database_name)  = @_;

# Near State （呼び出し） 2.30
#my $HereName1 = "connect";
#my $StateKey1 = "normal";
#my($state) = Mebius::State::call_parmanent(__PACKAGE__,$HereName1,$StateKey1);
#	if(defined $state){ return($state); }

my $password = "Zettaini-subarasii-7";

	# メインデータベース
	if($database_name eq ""){
		$self = DBI->connect('DBI:mysql:mebius', 'admin', $password);
	}

	# Near State （保存） 2.30
#	if($HereName1){ Mebius::State::save_parmanent(__PACKAGE__,$HereName1,$StateKey1,$self); }

}

#-----------------------------------------------------------
# テーブル ( 中のレコード ) が存在するかどうかをチェックする
#-----------------------------------------------------------
sub table_records_exists{

my($database_name,$table_name) = @_;
my($dbh) = Mebius::DBI::connect($database_name);
my($exists,$not_exists);

	# テーブル名の汚染チェック
	if(table_name_format_error($table_name)){
		die;
	}	

#my($exists) = $dbh->tables('', '', $table_name) || ($not_exists = 1);

my(undef,$result) = fetchrow_hashref_on_arrayref("SELECT * FROM `$table_name` LIMIT 0,1;");

$result;

}

#-----------------------------------------------------------
# SELECT から ハッシュリファレンスの配列を返す
#-----------------------------------------------------------
sub fetchrow_hashref_on_arrayref{

my($dbi_query) = @_;
my($dbh) = Mebius::DBI::connect();
my ($sth,$result) = query($dbh,$dbi_query);
my(@self);

	while ( my $hash_ref = $sth->fetchrow_hashref ){
		push(@self,$hash_ref);
	}

\@self,$result;

}


#-----------------------------------------------------------
# SELECT から ハッシュリファレンスの配列を返す
#-----------------------------------------------------------
sub fetchrow_hashref_on_arrayref_head{

my($data,$result) = fetchrow_hashref_on_arrayref(@_);

$data->[0],$result;

}



#-----------------------------------------------------------
# SQL文を用意して実行する
#-----------------------------------------------------------
sub query{

my $dbh = shift;
my $sql_query = shift;

my $sth = $dbh->prepare($sql_query);
my $result = $sth->execute();

	if($result eq "0E0"){ $result = -1; }

#my $arr_ref = $sth->fetchrow_arrayref;

$sth,$result;

}


#-----------------------------------------------------------
# SQL 文のエスケープ
#-----------------------------------------------------------
sub escape_sql{

my($dbh) = Mebius::DBI::connect();

	foreach(@_){
		$dbh->quote($_);
		#s/[\0\n\r\z]//g;
		#s/'/''/g;
		#s/\\/\\\\/g;
	}
}

#-----------------------------------------------------------
# SQL 文のエスケープ
#-----------------------------------------------------------
sub escape_sql_return{

my(@texts) = @_;

escape(@_);

@texts;


}

#-----------------------------------------------------------
# 古いレコードを削除
#-----------------------------------------------------------
sub delete_old_records{

my($dbh,$table_name,$border_time) = @_;

	# テーブル名の汚染チェック
	if(table_name_format_error($table_name)){
		die;
	}

	# 汚染チェック
	if($border_time =~ /\D/){
		return();
	}

	# 一定確率で削除するため、抽選に当たらなければリターン
	if(rand(3*24*60*60)*10 > 1){
		return();
	}

# エスケープ
escape($table_name,$border_time);

$dbh->do("DELETE FROM `$table_name` WHERE last_update_time < $border_time;");

}

#-----------------------------------------------------------
# 一定確率でバックアップを取る
#-----------------------------------------------------------
sub backup_table_with_random{

my $use = shift if(ref $_[0] eq "HASH");
my($database_name,$table_name) = @_;
my($dbh) = Mebius::DBI::connect($database_name);

# 何回に一回程度、バックアップを取るかを確率で定義 ( 1 / $odds )
my $odds = $use->{'odds'} || 5000;

	# テーブル名の汚染チェック
	if(table_name_format_error($table_name)){
		die;
	}

	# ローカル環境の設定
	#if(Mebius::AlocalJudge()){ $odds = 1; }

	# 一定確率でバックアップを取るため、ランダムにリターン
	#if(rand($odds) > 1){
	#	return();
	#}

# テーブルをコピー
memory_table_to_file_table($database_name,$table_name,$table_name."_backup");

}

#-----------------------------------------------------------
# メモリテーブルをバックアップテーブルに
#-----------------------------------------------------------
sub memory_table_to_file_table{

my($database_name,$table_name) = @_;
my($default_engine) = default_engine() || die;
my($dbh) = Mebius::DBI::connect($database_name);

	# テーブル名の汚染チェック
	if(table_name_format_error($table_name)){
		die;
	}

my $backup_table_name = $table_name."_backup";

# ファイルテーブルを作成、カラムをコピー	
$dbh->do("CREATE TABLE IF NOT EXISTS $backup_table_name LIKE $table_name;");

# メモリテーブルをファイルテーブルに変更
$dbh->do("ALTER TABLE $backup_table_name ENGINE $default_engine;");

# 全レコードをコピー
$dbh->do("REPLACE INTO $backup_table_name SELECT * FROM $table_name;");

}


#-----------------------------------------------------------
# テーブルをコピーする ( テーブルが既に存在する場合に、全レコードをコピー )
#-----------------------------------------------------------
sub copy_table_insert_only{

my($database_name,$copy_from_table_name,$copy_to_table_name) = @_;
my($dbh) = Mebius::DBI::connect($database_name);

	# テーブル名の汚染チェック
	if(table_name_format_error($copy_from_table_name) || table_name_format_error($copy_to_table_name)){
		die;
	}

$dbh->do("
REPLACE INTO $copy_to_table_name SELECT * FROM $copy_from_table_name;
");

}


#-----------------------------------------------------------
# メモリーテーブルとバックアップテーブルを同時に作る
#-----------------------------------------------------------
sub create_memory_table_and_backup{

my($database_name,$table_name,$set) = @_;

	# テーブル名の汚染チェック
	if(table_name_format_error($table_name)){
		die;
	}

# バックアップ用のテーブル名を定義
my $backup_table_name = $table_name . "_backup";

# テーブルレコードの存在有無を確かめる
my($memory_table_exists) = Mebius::DBI::table_records_exists($database_name,$table_name);
my($backup_table_exists) = Mebius::DBI::table_records_exists($database_name,$backup_table_name);

	# ●メモリテーブルにレコードが存在しない場合、バックアップから復元
	if(!$memory_table_exists && $backup_table_exists) {

		# メモリーテーブルを作成
		create_memory_table($database_name,$table_name,$set);

		# バックアップテーブルからメモリテーブルに復元
		copy_table_insert_only($database_name,$backup_table_name,$table_name);

	# ●それ以外の場合、バックアップ用とメモリテーブルの両方を作成する
	} else {

		# メモリーテーブルを作成
		create_memory_table($database_name,$table_name,$set);

		# バックアップ用テーブルを作成
		create_table($database_name,$backup_table_name,$set);

	}

}

#-----------------------------------------------------------
# バックアップ用のテーブルを作る
#-----------------------------------------------------------
#sub create_backup_table{

# 宣言
#my($database_name,$table_name,$create) = @_;

	# 名前チェック
#	if(table_name_format_error($table_name)){
#		die;
#	}

# メモリテーブルを作成
#create_table($database_name,$table_name."_backup",$create);


#}

#-----------------------------------------------------------
# メモリテーブルを作る
#-----------------------------------------------------------
sub create_memory_table{

# 宣言
my($database_name,$table_name,$create) = @_;

	# 名前チェック
	if(table_name_format_error($table_name)){
		die;
	}

# メモリテーブルを作成
create_table({ ON_MEMORY => 1 },$database_name,$table_name,$create);


}


#-----------------------------------------------------------
# テーブルの作成
#-----------------------------------------------------------
sub create_table{

my $use = shift if(ref $_[0] eq "HASH");
my($database_name,$table_name,$create) = @_;
my($dbh) = Mebius::DBI::connect($database_name);
my($ENGINE,@create,@alter,$primary_flag);

	# エラーチェック
	if(table_name_format_error($table_name)){
		die;
	}

	# 使用するデータエンジン
	if($use->{'ON_MEMORY'} || $use->{'MEMORY'}){
		$ENGINE = "ENGINE=MEMORY"
	}

	# 展開
	foreach ( keys %$create ){

		my $dbi_command;

			# カラム名を定義
			if(column_name_format_error($_)){
				die("column name $_ is strange.");
			} else {
				$dbi_command .= "`$_`";
			}

			# レコードのデータ型定義
			if($create->{$_}->{'int'} || $create->{$_}->{'INT'}){
				$dbi_command .= " int";
			}elsif($create->{$_}->{'data_type'} =~ /^[\w\(\)]+$/){
				$dbi_command .= $create->{$_}->{'data_type'};
			} else {
				$dbi_command .= " char(255)";
			}

			# レコードの初期値を設定
			if(exists $create->{$_}->{'default'}){
				$dbi_command .= " default $create->{$_}->{'default'}";
			} elsif($create->{$_}->{'NOT_NULL'} || $create->{$_}->{'PRIMARY'} || $create->{$_}->{'PRIMARY_KEY'}){
				$dbi_command .= " NOT NULL";
			} else {
				$dbi_command .= " default NULL";
			}

			# プライマリーキーにする場合
			if($create->{$_}->{'PRIMARY'} || $create->{$_}->{'PRIMARY_KEY'}){
					if($primary_flag){ die("Plese use one only PRIMARY KEY . not over two."); }
				$dbi_command .= " PRIMARY KEY";
				$primary_flag = 1;
			}

		push(@create,$dbi_command);
			if($create->{$_}->{'ADD'}){
				push(@alter,"ADD COLUMN $dbi_command");
			}
	}

# 命令文をカンマで区切る
my($create) = Mebius::join_array_with_mark(",",@create);
my $do = "CREATE TABLE IF NOT EXISTS `$table_name` ($create) $ENGINE;";

# テーブル作成を実行
$dbh->do($do);

	# 変更
	if(Mebius::AlocalJudge()){
		my($alter_add) = Mebius::join_array_with_mark(",",@alter);
		$dbh->do("ALTER TABLE `$table_name` $alter_add;");
	}

	#if($table_name eq "dos"){
		#if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($do)); }
	#}



}



#-----------------------------------------------------------
# 汎用的な INSERT
#-----------------------------------------------------------
sub insert{

my($database_name,$table_name,$insert) = @_;
my($sql,@names,@values,$names,$values);

	# 不正チェック
	if(ref $insert ne "HASH"){ die; }
	if(table_name_format_error($table_name)){ die; }

# データベースに接続
my($dbh) = Mebius::DBI::connect($database_name);

	# SQL文を調整 ( 順序が大事なため、ハッシュからの配列化は必須 )
	foreach (keys %$insert ){

			# カラム名の不正チェック
			if(column_name_format_error($_)){ next; }

		# 配列に追加
		push(@names,$_);
		push(@values,$insert->{$_});

	}

# カラム数分の ? を用意する
my($question_marks) = Mebius::DBI::question_mark_for_bind($insert);

# カラム名を , で区切る
my($column_names) = Mebius::join_array_with_mark(",",@names);

#	if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($column_names / $question_marks)); }

# SQL文を用意する ( バインド )
my $sth = $dbh->prepare(
	"INSERT INTO `$table_name`
	($column_names)
	VALUES ($question_marks)"
);

# SQL を実行する
$sth->execute(@values);


}

#-----------------------------------------------------------
# 汎用的な更新
#-----------------------------------------------------------
sub update{

my($database_name,$table_name,$set,$sql) = @_;
my(@set_for_bind);

	# 不正チェック
	if(table_name_format_error($table_name)){ die; }
	if(ref $set ne "HASH"){ die; }

# データベースに接続
my($dbh) = Mebius::DBI::connect($database_name);

# 配列をSET文に
my($set_sql,$set_value_for_bind) = Mebius::DBI::join_hash_to_set_scalar($set);

	# 更新を実行
	if($set_sql){

		# SQL 文を用意
		my $sth = $dbh->prepare("
			UPDATE `$table_name`
			SET $set_sql
			$sql
		");

		# バインドで実行
		$sth->execute(@$set_value_for_bind);

	}

#	if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($set_sql)); }



}

#-----------------------------------------------------------
# レコードがある場合は UPDATE 、ない場合は INSERt
#-----------------------------------------------------------
sub update_or_insert{

my($database_name,$table_name,$insert,$unique_key_name) = @_;

	# 不正チェック
	if(table_name_format_error($table_name)){ die; }
	if(column_name_format_error($unique_key_name)){ die; }
	if(ref $insert ne "HASH"){ die; }

# データを取得
my($data,$result) = Mebius::DBI::fetchrow_hashref_on_arrayref_head("SELECT $unique_key_name from `$table_name` WHERE $unique_key_name='$insert->{$unique_key_name}'");

	# ▼更新
	if($result >= 1){
		Mebius::DBI::update(undef,$table_name,$insert," WHERE $unique_key_name='$insert->{$unique_key_name}'");
	# ▼追加
	} else {
		Mebius::DBI::insert(undef,$table_name,$insert);
	}

}

#-----------------------------------------------------------
# HASH を結合して JOIN文にする
#-----------------------------------------------------------
sub join_hash_to_set_scalar{

my($hash) = @_;
my($self,@set_column_name);
my($dbh) = Mebius::DBI::connect();
my(@set_value_for_bind);

	foreach	my $column_name (keys %$hash ){

		my $value = $hash->{$column_name};

		# カラム名の汚染チェック
		if(column_name_format_error($column_name)){ next; }

			# ▼式の場合
			if($value =~ /^
					([\+\-\*\/]) # 四則演算記号
					(\d+) # 数字 ( 整数)
					(\.\d+)? # 小数点
				$/x){

				# 例えば access=access+? のような文にする ( $1 は 四則演算記号 )
				push(@set_column_name,"$column_name=$column_name$1?");

				# 数値のみを VALUES として渡す ( $2$3 は数字部分 )
				push(@set_value_for_bind,"$2$3");

			# ▼それ以外の場合、そのまま SQL 文を作る
			} else {
				push(@set_column_name,"$column_name=?");
				push(@set_value_for_bind,$hash->{$column_name});
			}

	}


# SET 文を , で区切る
($self) = Mebius::join_array_with_mark(",",@set_column_name);

$self,\@set_value_for_bind;

}

#-----------------------------------------------------------
# バインドで使う ?,?,? のような部分を作成
#-----------------------------------------------------------
sub question_mark_for_bind{

my($value) = @_;
my(@question_marks,$self);

	# ハッシュリファレンスの場合
	if(ref $value eq "HASH"){
			foreach(keys %$value ){
				push(@question_marks,"?");
			}
	# 配列のリファレンスの場合
	} elsif(ref $value eq "ARRAY"){
			foreach(@$value){
				push(@question_marks,"?");
			}
	# スカラ、配列直接渡しの場合
	} else {
			foreach(@_){
				push(@question_marks,"?");
			}
	}

my($self) = Mebius::join_array_with_mark(",",@question_marks);

}

#-----------------------------------------------------------
# テーブル名の不正チェック
#-----------------------------------------------------------
sub table_name_format_error{

my($table_name) = @_;
my($self);

	if($table_name =~ /^[a-zA-Z0-9_\-]+$/){
		0;
	} else {
		die("SQL : Table name '$table_name' is invalid.");
		$self = 1;
	}

$self;

}

#-----------------------------------------------------------
# カラム名の不正チェック
#-----------------------------------------------------------
sub column_name_format_error{

my($column_name) = @_;

	if($column_name =~ /^[a-zA-Z0-9_\-]+$/){
		0;
	} else {
		die("SQL : Column name '$column_name' is invalid.");
		return 1;
	}


}

#-----------------------------------------------------------
# 全てのテーブルを作成する
#-----------------------------------------------------------
sub create_all_tables{

Mebius::Dos::create_main_table();

	#if(Mebius::Server::bbs_server_judge()){
		Mebius::BBS::ThreadNewStatus::create_main_table();
	#}

	#if(Mebius::Server::bbs_server_judge()){
		Mebius::Follow::create_main_table();
	#	print "made follow table.\n";
	#}

Mebius::UserData::create_main_table();

Mebius::Host::create_main_table();

Mebius::SNS::DiaryStatus::create_main_table();


}



1;
