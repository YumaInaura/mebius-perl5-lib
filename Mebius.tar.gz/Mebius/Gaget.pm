
# 宣言
use strict;
package Mebius::Gaget;
use Mebius::Export;

#-----------------------------------------------------------
# Bless
#-----------------------------------------------------------
sub new{
my $class = shift;
bless {} , $class;
}

#-----------------------------------------------------------
# メビリンSNSの日記ボタン
#-----------------------------------------------------------
sub mebius_diary_button{

# 宣言
my $class = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $comment = shift;
my $subject = shift;
my $comment_encoded = Mebius::Encode(undef,$comment);
my $subject_encoded = Mebius::Encode(undef,$subject);
my($basic_init) = Mebius::basic_init();
my($my_account) = Mebius::my_account();
#my($request_url_encoded) = Mebius::request_url_encoded();
my $self;

$self = qq(<a href=").e($basic_init->{'auth_url'}).qq(?mode=fdiary&amp;subject=).e($subject_encoded).qq(&amp;comment=).e($comment_encoded).qq(&amp;account=).e($my_account->{'id'}).qq(">日記</a>);

$self;


}

#-----------------------------------------------------------
# ツイートボタン
#-----------------------------------------------------------
sub tweet_button{

# 宣言
my $class = shift;
my $use = shift;
my($botton,$data_size,$data_count,$data_url,$data_text);

	# ボタンのサイズ
	if($use->{'Large'}){
		$data_size = qq( data-size="large");
	}

	# ツイート数を表示するかどうか
	if(!$use->{'DataCount'}){
		$data_count = qq( data-count="none");
	}

	# URL指定
	if($use->{'url'}){
		$data_url = qq( data-url=").e($use->{'url'}).qq(");
	}

	# URL指定
	if($use->{'text'}){
		$data_text = qq( data-text=").e($use->{'text'}).qq(");
	}

my $link = qq(<a href="#" class="twitter-share-button" data-lang="ja" data-via="mb2jp" data-related="mb2jp"${data_size}${data_count}${data_url}${data_text}></a>);
$botton .= qq(<script>document.write('$link');</script>);

#$botton = qq(
#<script>
#<!--
#document.write('$link');
#!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");
#//-->
#</script>
#);

#if(Mebius::AlocalJudge()){ 
#Mebius::SimpleHTML('<a href="http://twitter.com/share" class="twitter-share-button" data-count="none" data-via="gigazine" data-lang="ja">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script></p>');
# }

return($botton);

}


#-----------------------------------------------------------
# LINE で送る
#-----------------------------------------------------------
sub line_button{

my($my_use_device) = Mebius::my_use_device();

my $self = qq(
<script type="text/javascript" src="http://media.line.naver.jp/js/line-button.js" ></script>
<script type="text/javascript">
new jp.naver.line.media.LineButton({"pc":false,"lang":"ja","type":"b"});
</script>
);

}

#-----------------------------------------------------------
# Google +1 ボタン
#-----------------------------------------------------------
sub google_plusone_button{

return();

# 宣言
my($type) = @_;
my($botton);

	if($ENV{'HTTP_USER_AGENT'} =~ /MSIE (5|6|7|8)/){ return(); }

$botton = qq( <g:plusone size="medium" annotation="none"></g:plusone>);

return($botton);

}

#-----------------------------------------------------------
# Google +1 ボタン
#-----------------------------------------------------------
sub google_plusone_script{

return();


	if($ENV{'HTTP_USER_AGENT'} =~ /MSIE (5|6|7|8)/){ return(); }

my $script = qq(
<script type="text/javascript">
  window.___gcfg = {lang: 'ja'};
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>
);


$script;

}


#-----------------------------------------------------------
# Google +1 ボタン 補完コード？
#-----------------------------------------------------------
sub google_plusone_fotter_code{

return();


my $line;

	if($ENV{'HTTP_USER_AGENT'} =~ /MSIE (5|6|7|8)/){ return(); }

	# ソーシャルボタン用
	# Google +1 ボタン用 (非同期コード)

$line .= qq(\n<script type="text/javascript">\n);
$line .= qq(<!--\n);
$line .= qq(gapi.plusone.go();\n);
$line .= qq(// -->\n);
$line .= qq(</script>\n);


}

#-----------------------------------------------------------
# Google Analytics
#-----------------------------------------------------------

sub google_analytics{

return();

my $code = q(
<script type="text/javascript" src="/skin/google_analytics.js"></script>
);

$code;

}



1;
