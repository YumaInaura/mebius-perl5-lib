
use strict;
package Mebius::BBS::ThreadNewStatus;

#-----------------------------------------------------------
# テーブル名
#-----------------------------------------------------------
sub main_table_name{
"bbs_thread_new_status";
}

#-----------------------------------------------------------
# レコードの追加 / 更新
#-----------------------------------------------------------
sub update{

my($use) = @_;
my $update = $use->{'update'} || die;
my($dbh) = Mebius::DBI::connect();
my($table_name) = main_table_name() || die("Can't decide main table name.");
my $time = time;

	# 汚染チェック
	if($update->{'bbs_kind'} =~ /\W/){ return(); }
	if($update->{'thread_number'} =~ /\D/){ return(); }
	if($update->{'res_number'} =~ /\D/){ return(); }

# 定義
my $unique_target = "$update->{'bbs_kind'}-$update->{'thread_number'}";
my $unique_target_quoted = $dbh->quote("$update->{'bbs_kind'}-$update->{'thread_number'}");

# データを取得
my($data,$result) = Mebius::DBI::fetchrow_hashref_on_arrayref_head("SELECT unique_target from `$table_name` WHERE unique_target=$unique_target_quoted");

	#if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq()); }

	# ●更新
	{	
		my $update = {
			unique_target => $unique_target ,
			bbs_kind => $update->{'bbs_kind'} ,
			thread_number => $update->{'thread_number'} ,
			res_number => $update->{'res_number'} ,
			regist_time => $update->{'regist_time'} ,
			last_update_time => $time , 
			handle => $update->{'handle'} , 
			subject => $update->{'subject'}
		};
 
			# ▼更新
			if($result >= 1){
				Mebius::DBI::update(undef,$table_name,$update,"WHERE unique_target=$unique_target_quoted");
			# ▼追加
			} else {
				Mebius::DBI::insert(undef,$table_name,$update);
			}
	}

	# 一定確率でバックアップを作成
	if(rand(5000) < 1 || Mebius::AlocalJudge()){
		Mebius::DBI::backup_table_with_random(undef,$table_name);
	}

}


#-----------------------------------------------------------
# テーブル作成
#-----------------------------------------------------------
sub create_main_table{

my($dbh) = Mebius::DBI::connect();
my($table_name) = main_table_name() || die("Can't decide main table name.");

# データ定義
my $set = {
unique_target => { PRIMARY => 1 , NOT_NULL => 1 } , 
bbs_kind => {  } , 
thread_number => { INT => 1 } , 
res_number => { INT => 1 } ,
regist_time => { INT => 1 } ,
last_update_time => { INT => 1 } ,
handle => { INT => 1 } ,
last_update_time => { INT => 1 } ,
handle => { } ,
subject => { } ,
};

Mebius::DBI::create_memory_table_and_backup(undef,$table_name,$set);

}



1;
