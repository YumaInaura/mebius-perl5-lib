
use strict;
package Mebius::BBS;

#-----------------------------------------------------------
# �L�����擾
#-----------------------------------------------------------
sub thread_state{

my $use = shift if(ref $_[0] eq "HASH");
my $thread_number = shift;
my $target_bbs = shift; # ���̏��Ԃŗǂ�

	if(@_ >= 1){ die("Perl Die! Too many value relayed. @_ "); }

	# �����p��
	if(defined $use->{'relay_thread'}){
		$thread_number = $use->{'relay_thread'}->{'thread_number'};
		$target_bbs = $use->{'relay_thread'}->{'realmoto'};
	}

	if($use->{'Auto'}){
		my($query) = Mebius::query_state();
		$target_bbs = $query->param('moto');
		#$thread_number = $query->param('no');
	}

	if($use->{'thread_number_query'}){
		my($query) = Mebius::query_state();
		$thread_number = $query->param($use->{'thread_number_query'});
	}

	if($use->{'SubThread'} && $target_bbs && $target_bbs !~ /^sub/){
		$target_bbs = "sub$target_bbs";
	}

	elsif($use->{'MainThread'} && $target_bbs && $target_bbs =~ /^sub/){
		$target_bbs =~ s/^sub//g;
	}

	if($thread_number =~ /\D/ || $thread_number eq ""){ warn("Perl warn! thread_number '$thread_number' is invalid "); return(); }
	if($target_bbs =~ /\W/ || $target_bbs eq ""){ warn("Perl warn! target_bbs '$target_bbs' is invalid "); return(); }

my $HereName1 = "thread_state";
my $HereKey1 = "$target_bbs-$thread_number";

my($state) = Mebius::State::Call(__PACKAGE__,$HereName1,$HereKey1);
	if(defined $state){ return($state); }
	else{ Mebius::State::ElseCount(__PACKAGE__,$HereName1,$HereKey1); }

# ���[�v�\�h
my($roop) = Mebius::Roop::block(__PACKAGE__,$HereName1,$HereKey1);
	if($roop){ die($roop); } else { Mebius::Roop::set(__PACKAGE__,$HereName1,$HereKey1); }

my($thread) = Mebius::BBS::thread({ ReturnRef => 1 , GetAllLine => 1 , Flock => 1 }, $target_bbs , $thread_number);

	# ���[�v������\�h ( ��� ) 1.1
	if($HereName1){ Mebius::Roop::relese(__PACKAGE__,$HereName1,$HereKey1); }

	if($HereName1){ Mebius::State::Save(__PACKAGE__,$HereName1,$HereKey1,$thread); }

$thread;

}

#-----------------------------------------------------------
# �f���̋L���f�[�^���擾
#-----------------------------------------------------------
sub thread{

# �錾
my($use,$realmoto,$thread_number) = @_;
my(%self,$file,$FILE1,@renew_line,%data_format,$renew);
my($server_url) = Mebius::server_url();
my($my_account) = Mebius::my_account();
my($basic_init) = Mebius::basic_init();

	# �����p��
	if(defined $use->{'relay_thread'}){
			$thread_number = $use->{'relay_thread'}->{'thread_number'};
			$realmoto = $use->{'relay_thread'}->{'realmoto'};
	}

	# �����`�F�b�N
	if($realmoto eq "" || $realmoto =~ /[^0-9a-zA-Z]/){ return(); }
	if($thread_number eq "" || $thread_number =~ /\D/){ return(); }

# �t�@�C����`
my($thread_directory) = Mebius::BBS::thread_directory_path($realmoto);
	if(!$thread_directory){ warn("Perl warn! Can't decide thread directory path . \@_ is @_"); return(); }
	($self{'file'}) = Mebius::BBS::thread_file_path($realmoto,$thread_number);
	if(!$self{'file'}){ warn("Perl warn! Can't decide thread file path.  \@_ is @_"); return(); }

my %relay_use = %$use;
	if(!$use->{'AllowTouchFile'}){ $relay_use{'DenyTouchFile'} = 1; }
my($FILE1,$read_write) = Mebius::File::read_write(\%relay_use,$self{'file'},[$thread_directory]);
	if($read_write->{'f'}){ %self = (%self,%$read_write); } else { return(\%self); }

# �g�b�v�f�[�^��ǂݍ���
%data_format = thread_top_data_format();
my($split_data) = Mebius::file_handle_to_hash(\%data_format,$FILE1);
%self = (%self,%$split_data);

	if(!@{$self{'all_line'}}){
		die("Perl Die! Thread Line is empty. ");
	}

# �d�v�ȑ��
my $top2 = <$FILE1>;
	if($top2){
		push(@{$self{'all_line'}},$top2); 
		chomp $top2;
		(undef,undef,$self{'zero_handle'},undef,$self{'zero_comment'},$self{'zero_date'},undef,undef,$self{'zero_color'},undef,undef,undef,$self{'zero_account'}) = split(/<>/,$top2);
	}

# ���n�b�V���̒���
$self{'subject'} = $self{'sub'};
$self{'date'} = $self{'zero_date'};
$self{'lasttime'} = $self{'lastrestime'};
$self{'postnumber'} = $thread_number;
$self{'number'} = $self{'thread_number'} = $thread_number;
$self{'posthandle'} = $self{'zero_handle'};
$self{'realmoto'} = $self{'target_bbs'} = $self{'bbs_kind'} = $realmoto;


	# URL
	($self{'url'}) = Mebius::BBS::thread_url($thread_number,$realmoto);
	($self{'admin_url'}) = Mebius::BBS::thread_url_admin($thread_number,$realmoto);
	($self{'bbs_url_admin'}) = Mebius::BBS::bbs_url_admin($realmoto);

	# �����̏ꍇ
	if($self{'zero_account'} && $self{'zero_account'} eq $my_account->{'id'}){ $self{'mythread_flag'} = 1; }

	# ���X������̏ꍇ
	if(!$self{'res'}){ $self{'res'} = 0; }

	# ���e�O���j�b�W�W�����������ꍇ�A�[���L���̓��t���犷�Z
	if($self{'posttime'} eq "" && $self{'zero_date'}){
		my(%date) = Mebius::SplitMebiDate(undef,$self{'zero_date'});
		$self{'posttime'} = $date{'time'};
	}

# �폜���
(undef,undef,$self{'control_lasttime'},$self{'control_reason'}) = split(/=/,$self{'delete_data'});

	# �x���t���O
	if($self{'concept'} =~ /Alert-violation/ && time < $self{'control_lasttime'} + (7*24*60*60)){ $self{'alert_flag'} = 1; }


	# ���L�[���x������ (A-1)
	if($self{'key'} eq "1" || $self{'key'} eq "5" || $self{'key'} eq "2"){ $self{'keylevel'} = 1; }
	elsif($self{'key'} eq "3"){ $self{'keylevel'} = 0.5; }
	elsif($self{'key'} eq "0"){
			if(!$self{'lock_end_time'} || $self{'lock_end_time'} > time){
				$self{'keylevel'} = 0;
				$self{'lock_flag'} = 1;
			}
			else{
				$self{'keylevel'} = 1;
			}
	}
	elsif($self{'key'} eq "4" || $self{'key'} eq "6" || $self{'key'} eq "7"){
		$self{'keylevel'} = -1;
		$self{'deleted_flag'} = 1;
	}
	else{ $self{'keylevel'} = -2; }

	# ���ő僌�X��B�������X���b�h���L�^����ꍇ�̔��� (A-2)
	if($use->{'TypeMaxResRecord'}){
			# �L�^���Ȃ��f����
			if($main::realmoto =~ /^(delete)$/ || $main::secret_mode || $main::bbs{'concept'} =~ /Chat-mode/ || $main::subtopic_mode){
				close($FILE1);
				return();
			}
			# �L�����폜�ς݂Ȃǂ̏ꍇ
			if($self{'keylevel'} < 0){
				close($FILE1);
				return();
			}
			# ���ɋL�^�ς݂̏ꍇ
			if($self{'concept'} =~ /Maxres-recorded2/){
				close($FILE1);
				return();
			}
		# �R���Z�v�g�L�[�̕ύX�A��`
		$self{'concept'} =~ s/ Maxres-recorded([0-9]+)?//g;
		$self{'concept'} .= qq( Maxres-recorded2);
		Mebius::AccessLog(undef,"Maxres-recorded");
	}

	# ���S�s��W�J
	if($use->{'GetAllLine'} || $use->{'Renew'}){

			while(<$FILE1>){
				push(@{$self{'all_line'}},$_);
			}

			# �{�f�B�[����������W�J�������̂ŁA�g�b�v�f�[�^�� shift ����
			my @body_line = @{$self{'all_line'}};
			shift @body_line;

			foreach(@body_line){

				my(%res);
				chomp;

# �f�[�^����
($res{'res_number'},$res{'cookie_char'},$res{'handle'},$res{'trip'},$res{'comment'},$res{'date'},$res{'host'},$res{'id'},$res{'color'},$res{'user_agent'},$res{'user_name'},$res{'deleted'},$res{'account'},$res{'image_data'},$res{'concept'},$res{'regist_time'},$res{'addr'}) = split(/<>/);
			$self{'res_data'}{$res{'res_number'}} = \%res;

				# ���X�V�p
				if($use->{'Renew'}){ 

						# �s��ҏW
						my($res_renew) = Mebius::Hash::control(\%res,$use->{'res_edit'}->{$res{'res_number'}});

					# �X�V�s���`
					my $renew_this_line = "$res_renew->{'res_number'}<>$res_renew->{'cookie_char'}<>$res_renew->{'handle'}<>$res_renew->{'trip'}<>$res_renew->{'comment'}<>$res_renew->{'date'}<>$res_renew->{'host'}<>$res_renew->{'id'}<>$res_renew->{'color'}<>$res_renew->{'user_agent'}<>$res_renew->{'user_name'}<>$res_renew->{'deleted'}<>$res_renew->{'account'}<>$res_renew->{'image_data'}<>$res_renew->{'concept'}<>$res_renew->{'regist_time'}<>$res_renew->{'addr'}<>\n";
						push(@renew_line,$renew_this_line);

					}
			}

	}

	# ���t�@�C���X�V
	if($use->{'Renew'}){

		# �C�ӂ̍X�V�ƃ��t�@�����X��
		($renew) = Mebius::Hash::control(\%self,$use->{'select_renew'});

			if($use->{'new_line'}){ push(@renew_line,$use->{'new_line'}); }

		# �f�[�^�t�H�[�}�b�g����t�@�C���X�V
		Mebius::File::data_format_to_truncate_print(\%data_format,$FILE1,$renew,\@renew_line);

	}

close($FILE1);

	# �p�[�~�b�V�����ύX
	if($use->{'Renew'}){ Mebius::Chmod(undef,$self{'file'}); }

	# ���ڍ׃n�b�V�����`
	if($use->{'GetHashDetail'}){

		# �L���̐V�K���e����������t�𕪉�
		my(%time1) = Mebius::Getdate("Get-hash",$self{'posttime'});
		%self = (%self,%time1);

			# �L���̉ߋ����O�����t�𕪉� ( ��ɊǗ��ҍ폜�p )
			if($self{'bepast_time'}){
				my(%bepast_time) = Mebius::Getdate("Get-hash",$self{'bepast_time'});
					foreach( keys %bepast_time ){
							$self{"bepast_time_$_"} = $bepast_time{$_};
					}
			}

		# �X�^�b�g�f�[�^���擾
		my($stat) = Mebius::file_stat("Get-stat",$self{'file'});

			# �X�^�b�g�f�[�^��{�n�b�V���Ɍ���
			foreach(keys %$stat){
					if(defined($stat->{$_})){ $self{"stat_$_"} = $stat->{$_}; }
			}

	}

	# ���ő僌�X�B���X���b�h���A�e���ɋL�^����
	if($use->{'TypeMaxResRecord'}){
		require "${main::int_dir}part_newlist.pl";
		Mebius::Newlist::Maxres("Renew",%self);
		Mebius::BBS::Maxres("Renew",$realmoto,\%self);
	}

	# �n�b�V����Ԃ�
	if($use->{'ReturnReference'} || $use->{'ReturnRef'}){ return(\%self); } else{ return(%self); }


}

#-----------------------------------------------------------
# �g�b�v�f�[�^�̃t�H�[�}�b�g
#-----------------------------------------------------------
sub thread_top_data_format{

my %self;

$self{'1'} = [('concept','sub','res','key','lasthandle','lastrestime','delete_data','lastmodified','bepast_time','sexvio','poster_xip','delete_reserve_time','memo_editor','memo_body','admin_memo','lock_end_time','lastcomment','posttime','crap_count','sub_thread_res')];

%self;

}



1;

