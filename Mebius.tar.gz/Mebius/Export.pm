
use strict;
package Mebius::Export;

# Exporter���p��
#use base 'Exporter';
use Exporter;

our @ISA = qw(Exporter);
# �G�N�X�|�[�g����֐����L�q
our @EXPORT = qw(say esc e shift_jis shift_jis_return utf8_return utf8 gq_utf8 g_utf8 g_shift_jis if_defined);

sub say{ print $_[0]; print "\n"; }
sub super_chomp{ my($text) = @_; $text =~ s/(\r|\n|\r\n)$//g; $text; }
sub esc{
my($escaped) = Escape::HTML([$_[0]]);
$escaped;
}
sub e{
my($escaped) = Escape::HTML([$_[0]]);
$escaped;
}

sub d{
my(@formated) = Escape::DataFile(@_);
}

sub shift_jis{
Mebius::Encoding::utf8_to_sjis(@_);
@_;
}

sub shift_jis_return{
my(@self) = Mebius::Encoding::utf8_to_shift_jis_return(@_);
@self;
}

sub utf8{
Mebius::Encoding::sjis_to_utf8(@_);
@_;
}

sub utf8_return{
my(@self) = Mebius::Encoding::shift_jis_to_utf8_return(@_);
@self;
}

sub gq_utf8{
Mebius::Encoding::guess_query_and_utf8(@_);
@_;
}

sub g_utf8{
Mebius::Encoding::guess_and_utf8(@_);
@_;
}
sub g_shift_jis{
Mebius::Encoding::guess_and_shift_jis(@_);
@_;
}

sub if_defined{
Mebius::if_defined_set(@_);
}

1;

