

use strict;
package Mebius;

#-----------------------------------------------------------
# シンプルなHTML
#-----------------------------------------------------------
sub SimpleHTML{

# 宣言
my($use) = shift if(ref $_[0] eq "HASH");
my($message) = @_;
my($view_line);

	# 必須項目
	if(exists $use->{'Message'}){ $message = $use->{'Message'}; }

	# 文字コード変換
	if($use->{'FromEncoding'}){ Mebius::Encoding::from_to($use->{'FromEncoding'},"utf8",$message); }

#die('Perl Die! Message is empty'); }

$view_line .= qq(<html lang="ja">\n);
$view_line .= qq(<head>\n);
$view_line .= qq(<meta http-equiv="content-type" content="text/html; charset=utf-8">\n);
$view_line .= qq(<title></title>\n);
$view_line .= qq(<meta name="robots" content="noindex,nofollow,noarchive">\n);
$view_line .= qq(</head>\n);
$view_line .= qq(<body>\n);
$view_line .= qq(\n);
$view_line .= qq(\n);
$view_line .= qq(\n);
$view_line .= qq(\n);
$view_line .= qq(\n);
#$view_line .= &Escape::HTML([$use->{'Message'}]);
$view_line .= qq($message\n);
$view_line .= qq(</body>\n);
$view_line .= qq(</html>\n);


# コンテンツタイプ
print "Content-type:text/html;charset=utf-8;\n\n";
print $view_line;

exit;


}

#-----------------------------------------------------------
# メンテナンス
#-----------------------------------------------------------

sub maintenance{

my($finish_time) = @_;
my($finish_time_text);

	if($finish_time){
		my($how_long) = Mebius::second_to_howlong({ TopUnit => 1 }  , $finish_time - time);
		$finish_time_text = qq(<p>終了予定時刻： ${how_long}以内 <span style="color:#f00;">※状況によっては前後する場合があります。</span></p>);
	}

print "Status: 503 Service Temporarily Unavailable\n";
Mebius::SimpleHTML(qq(<h2><p>503 Service Temporarily Unavailable</h2>  現在メンテナンス中です。再開までお待ちください。</p>$finish_time_text<p><a href="http://mb2.jp/">mb2.jp</a> / <a href="http://sns.mb2.jp/">sns.mb2.jp</a></p>));

}

#-----------------------------------------------------------
# スタイルをスタイルタグに
#-----------------------------------------------------------
sub to_style_element{

my($inline_style) = @_;

	if(!$inline_style){ return(); }

my $self = qq( style="$inline_style");

}


1;