
use strict;
package Mebius;

#-----------------------------------------------------------
# 配列を任意のマークで区切って、スカラとして返す
#-----------------------------------------------------------
sub join_array_with_mark{

my($mark,@array) = @_;
my($self);

	foreach(@array){
			# 配列のリファレンスの場合
			if(ref $_ eq "ARRAY"){
					foreach(@{$_}){
						join_with_mark($mark,$_,$self);
					}
			# 変数の場合
			} elsif(ref $_ eq "") {
				join_with_mark($mark,$_,$self);
			}

	}

$self;

}

#-----------------------------------------------------------
# マークで結合
#-----------------------------------------------------------
sub join_with_mark{

my($mark,$value,undef) = @_;

	if($_[2] eq ""){
		$_[2] = $value;
	} else {
		$_[2] .= $mark . $value;
	}

}


#-----------------------------------------------------------
# definedなら代入する
#-----------------------------------------------------------
sub if_defined_set{

	if(defined $_[1]){
		$_[0] = $_[1];
	}


}

#-----------------------------------------------------------
# スカラ、配列、ハッシュを問わずに、二つの対象から同一の値があるかどうかを判定する
#-----------------------------------------------------------
sub multi_equal{

my($target1,$target2) = @_;
my($self);

my(%hash1) = multi_hash($target1);
my(%hash2) = multi_hash($target2);

	foreach(keys %hash1){
		if($hash2{$_}){ $self = 1; }
	}

$self;

}

#-----------------------------------------------------------
# スカラも配列もハッシュも、値をハッシュ化する
# ( 値をハッシュにするため、元がハッシュの場合は reverse する )
#-----------------------------------------------------------
sub multi_hash{

my($target) = @_;
my(%self);

	if(ref $target eq ""){
		$self{$target} = 1;
	} elsif(ref $target eq "ARRAY"){
		foreach(@$target){
			$self{$_} = 1;
		}
	} elsif(ref $target eq "HASH"){
		%self = reverse %$target;
	}

%self;

}

#-----------------------------------------------------------
# タブ ( \t ) を削除する
#-----------------------------------------------------------
sub delete_tab{

	foreach(@_){
		s/\t//g;
	}

}

#-----------------------------------------------------------
# 順位を決めて代入する
#-----------------------------------------------------------
sub order{

my(@texts) = @_;

	foreach(@texts){
		if($_ ne ""){ return $_; }
	}


}
#-----------------------------------------------------------
# 同じ値かどうかを調べて、スカラを返す
#-----------------------------------------------------------
sub same_values_check_and_foreach_text{

my(@results) = same_values_check(@_);

my($self) = join_array_with_mark("/",@results);

	if(@results >= 1){
		$self .= " の " . @results . "項目";
	}

}

#-----------------------------------------------------------
# 同じ値かどうかを調べる (配列リファレンスの、ハッシュリファレンスとして渡す)
#-----------------------------------------------------------
sub same_values_check{

my($kinds) = @_;
my($self,@hit,$hit);

	# フォーマットチェック
	if(ref $kinds ne "HASH"){ die("'$kinds' is Not HASH Reference."); }

	# ハッシュを展開
	foreach my $name ( keys %$kinds ){

		# フォーマットチェック
		if(ref $kinds->{$name} ne "ARRAY"){
			die("'$kinds->{$name}' is not ARRAY Reference.");
		}

		# 値が空の場合
		if($kinds->{$name}->[0] eq "" || $kinds->{$name}->[1] eq "") {
			next;
		}

		# 一番目の要素と、二番目の要素を比べる
		if($kinds->{$name}->[0] eq $kinds->{$name}->[1]){
			push(@hit,$name);

		} else {

		}

	}


@hit;

}


1;
