
use strict;
use Time::Local qw();
use Time::HiRes qw();
package Mebius;
use Mebius::Export;

#-----------------------------------------------------------
# 現在の時刻を取得
#-----------------------------------------------------------
sub now_date{

# Near State （呼び出し） 2.10
my $StateName1 = "NowDate";
my $StateKey1 = time;
my($state) = Mebius::State::Call(__PACKAGE__,$StateName1,$StateKey1);
	if(defined $state){ return($state); }
	else{ Mebius::State::ElseCount(__PACKAGE__,$StateName1,$StateKey1); }

# 現在の時刻を取得
my($date_multi) = Mebius::now_date_multi();
my $date = $date_multi->{'date_till_minute'};

	# Near State （保存） 2.10
	if($StateName1){ Mebius::State::Save(__PACKAGE__,$StateName1,$StateKey1,$date); }

return($date);

}

#-----------------------------------------------------------
# 現在の時刻を取得
#-----------------------------------------------------------
sub now_date_multi{

# Near State （呼び出し） 2.10
my $StateName1 = "now_date_multi";
my $StateKey1 = time;
my($state) = Mebius::State::Call(__PACKAGE__,$StateName1,$StateKey1);
	if(defined $state){ return($state); }
	else{ Mebius::State::ElseCount(__PACKAGE__,$StateName1,$StateKey1); }

my $time_and_micro_seconds = Time::HiRes::time;
#my($seconds,$microseconds) = Time::HiRes::gettimeofday;

# 現在の時刻を取得
#my($date_multi) = Mebius::get_date($time_and_micro_seconds);
my($date_multi) = Mebius::get_date(time);

	# Near State （保存） 2.10
	if($StateName1){ Mebius::State::Save(__PACKAGE__,$StateName1,$StateKey1,$date_multi); }

return($date_multi);

}



#-----------------------------------------------------------
# 時刻を取得
#-----------------------------------------------------------
sub get_date{

# 宣言
my($time) = @_;
my(%self);

	# 不要値のチェック
	if(defined $_[1]){ die("Perl Die! Time is must set at First value"); }

# タイムゾーンを設定
$ENV{'TZ'} = "JST-9";


	# 自動的に現在のミリ秒を使う場合
	if($time eq "HiRes"){	$time = Time::HiRes::time; }

	# ミリ秒まで指定されている場合
	if($time =~ /^(\d+)\.(\d+)$/){
		$time = $1;
		$self{'micro_seconds'} = $2;
	}

	# リターン
	if($time eq "" || !defined $time || $time !~ /^(\d+)$/){ return(); }

($self{'second'},$self{'minute'},$self{'hour'},$self{'day'},$self{'pre_month'},$self{'pre_year'},$self{'pre_weekday'}) = (localtime($time))[0..6];

my @week = ("日","月","火","水","木","金","土");
shift_jis(@week);
$self{'weekday'} = $week[$self{'pre_weekday'}];

# 数値を補完する
$self{'month'} = $self{'pre_month'} + 1;
$self{'year'} = $self{'pre_year'} + 1900;

	# 日付を定義 ( ミリ秒まで )
	if($self{'micro_seconds'}){
		$self{'micro_second_omited'} = substr($self{'micro_seconds'},0,2);
		$self{'date_till_micro_second'} = sprintf("%04d/%02d/%02d %02d:%02d:%02d.%02d", $self{'year'},$self{'month'},$self{'day'},$self{'hour'},$self{'minute'},$self{'second'},$self{'micro_second_omited'});
	}

# 日付を定義 ( 秒まで )
$self{'date'} = $self{'date_till_second'} = sprintf("%04d/%02d/%02d %02d:%02d:%02d", $self{'year'},$self{'month'},$self{'day'},$self{'hour'},$self{'minute'},$self{'second'});
 
# 日付を定義 ( 分まで )
($self{'date_till_minute'}) = sprintf("%04d/%02d/%02d %02d:%02d", $self{'year'},$self{'month'},$self{'day'},$self{'hour'},$self{'minute'});

# 日付を定義 ( 日まで )
($self{'date_till_day'}) = sprintf("%04d/%02d/%02d", $self{'year'},$self{'month'},$self{'day'});

# 桁を揃える
$self{'yearf'} = $self{'year'};
($self{'monthf'}) = sprintf("%02d",$self{'month'});
($self{'dayf'}) = sprintf("%02d",$self{'day'});
($self{'hourf'}) = sprintf("%02d",$self{'hour'});
($self{'minutef'}) = sprintf("%02d",$self{'minute'});
($self{'secondf'}) = sprintf("%02d",$self{'second'});


# ユース変数
$self{'ymdf'} = "$self{'yearf'}-$self{'monthf'}-$self{'dayf'}";
$self{'yearf_omited'} = $self{'yearf'};
$self{'yearf_omited'} =~ s/^..//;

return(\%self);

}

#-------------------------------------------------
#  時間取得 (旧)
# SSS => 全て新しい処理 Date に置き換えたい
#-------------------------------------------------
sub Getdate{

# 宣言
my($type,$checktime) = @_;
my(@wdays);
my($time,$thissec,$thismin,$thishour,$today,$mon,$year,$wday,$pfcdate,$thismonth,$thisyear,$thiswday);
my($thisyearf,$thismonthf,$todayf,$thishourf,$thisminf,$thissecf,%time);

# タイムゾーンを定義
$ENV{'TZ'} = "JST-9";
$time = time;

	# リターンなど
	if($type =~ /Now-time/ && !$checktime){ $checktime = time; }
	if(!$checktime){ return(); }

($thissec,$thismin,$thishour,$today,$mon,$year,$wday) = (localtime($checktime))[0..6];

@wdays = ("日","月","火","水","木","金","土");
shift_jis(@wdays);

$thiswday = $wdays[$wday];

# グローバル関数化
$thismonth = $mon+1;
$thisyear = $year+1900;

# sprinft
$thisyearf = $thisyear;
($thismonthf) = sprintf("%02d",$thismonth);
($todayf) = sprintf("%02d",$today);
($thishourf) = sprintf("%02d",$thishour);
($thisminf) = sprintf("%02d",$thismin);
($thissecf) = sprintf("%02d",$thissec);

$time{'ymdf'} = "$thisyearf-$thismonthf-$todayf";

	# 日時のフォーマット
	if($type =~ /Get-second/){
		($time{'date'}) = sprintf("%04d/%02d/%02d %02d:%02d:%02d", $thisyear,$thismonth,$today,$thishour,$thismin,$thissec);
	}
	else{
		($time{'date'}) = sprintf("%04d/%02d/%02d %02d:%02d", $thisyear,$thismonth,$today,$thishour,$thismin);
	}

	# ハッシュで返す場合
	if($type =~ /Get-hash/){

		# 基本的なハッシュを定義
		$time{'year'} = $thisyearf;
		$time{'month'} = $thismonth;
		$time{'day'} = $today;
		$time{'hour'} = $thishour;
		$time{'min'} = $thismin;
		$time{'sec'} = $thissec;
		$time{'yearf'} = $thisyear;
		$time{'monthf'} = $thismonthf;
		$time{'dayf'} = $todayf;
		$time{'hourf'} = $thishourf;
		$time{'minf'} = $thisminf;
		$time{'secf'} = $thissecf;
		$time{'wday'} = $thiswday;
		$time{'yearf_omited'} = $time{'yearf'};
		$time{'yearf_omited'} =~ s/^..//;

			# 色々なフォーマットの日付を取得
			if($type =~ /Get-hash/){
				($time{'date_forward_day'}) = sprintf("%04d/%02d/%02d", $thisyear,$thismonth,$today);
			}

		return(%time);
	}

# リターン
return($time{'date'},$time,$thisyear,$thismonth,$today,$thishour,$thismin,$thissec,$thiswday,$thismonthf,$todayf,$thishourf,$thisminf,$thissecf,$time{'ymdf'});

}


#-----------------------------------------------------------
# まだ中間処理として扱っているが、メイン関数にしたい
#-----------------------------------------------------------
sub second_to_howlong{

# 宣言
my($use) = shift if(ref $_[0] eq "HASH");
my $localtime = shift;
my $relay_type;

	# リレータイプを変換
	if($use->{'ColorView'}){ $relay_type .= qq( Color-view); }
	if($use->{'HowBefore'}){ $relay_type .= qq( Plus-text-前); }
	if($use->{'GetLevel'} eq "top" || $use->{'TopUnit'}){ $relay_type .= qq( Get-top-unit); }
	elsif($use->{'GetLevel'}){ $relay_type .= qq( Get-till-$use->{'GetLevel'}); }

$relay_type .= qq(UTF8);
my($self) = Mebius::SplitTime($relay_type,$localtime);

$self;

}

#-----------------------------------------------------------
# 絶対時刻、または相対時刻を取得する
#-----------------------------------------------------------
sub spilit_time_or_get_date{

my $use = shift if(ref $_[0] eq "HASH");

}



#-----------------------------------------------------------
# 秒数を日/時間/分/秒に変換
#-----------------------------------------------------------
sub SplitTime{

# 宣言
my($type,$lefttime) = @_;
my($split_text,$leftyear_text,$leftmonth_text,$leftday_text,$lefthour_text,$leftminute_text,$leftsecond_text);
my($my_use_device) = Mebius::my_use_device();

	# リターン
	if($lefttime eq ""){ return(0); }
	if($lefttime =~ /\D/){ return(0); }
	if($lefttime >= time && $type =~ /Plus-text-前/){ return("-"); }

# 年計算
my $one_year_unit = (365*24*60*60)+(5*60*60)+(48*60)+(1*46);	# うるう年などを含めた時間を定義
my $leftyear = int($lefttime / $one_year_unit);
my $leftyear_second = $leftyear * $one_year_unit;

# 月計算 ( 年時間は除く )
my $one_month_unit = 30.43685*24*60*60;
my $leftmonth = int(($lefttime - $leftyear_second) / $one_month_unit);
my $leftmonth_second = $leftmonth * $one_month_unit;

# 日計算 ( 年月時間は除く )
my $one_day_unit = 24*60*60;
my $leftday = int(($lefttime - $leftyear_second - $leftmonth_second) / $one_day_unit);
my $leftday_second = $leftday * $one_day_unit;

# 時計算 ( 年月日時間は除く )
my $one_hour_unit = 60*60;
my $lefthour = int(($lefttime - $leftyear_second - $leftmonth_second - $leftday_second) / $one_hour_unit);
my $lefthour_second = $lefthour * $one_hour_unit;

# 分計算 ( 年月日時時間は除く )
my $one_minute_unit = 60;
my $leftminute = int(($lefttime - $leftyear_second - $leftmonth_second - $leftday_second - $lefthour_second) / $one_minute_unit);
my $leftminute_second = $leftminute * $one_minute_unit;

# 秒計算 ( 割り切り )
my $leftsecond = int($lefttime % 60);

	# 年の表示
	if($leftyear){
			if($type =~ /Omit-top-time/){ $leftyear += 1; }
		$leftyear_text = qq($leftyear年);
	}

	# 月の表示
	if($leftmonth){
			if($type =~ /Omit-top-time/){ $leftmonth += 1; }
		$leftmonth_text = qq($leftmonthヶ月);
	}

	# 日の表示
	if($type !~ /Not-get-day/){
		if($leftmonth || $leftday){
				if($type =~ /Omit-top-time/){ $leftday += 1; }
			$leftday_text = qq($leftday日);
		}
	}

	# ▼日までだけ取得するのでなければ、時分秒を取得
	if($type !~ /Get-till-day/){

			# 時間の表示
			if($type !~ /Not-get-hour/){
				if($leftmonth || $leftday || $lefthour){
						if($type =~ /Omit-top-time/){ $lefthour += 1; }
					$lefthour_text = qq($lefthour時間);
				}
			}

			# ▼時までだけ取得するのでなければ、分秒を取得
			if($type !~ /Get-till-hour/){

					# 分の表示
					if($type !~ /Not-get-minute/){
							if($leftmonth || $leftday || $lefthour || $leftminute){
									if($type =~ /Omit-top-time/){ $leftminute += 1; }
								$leftminute_text = qq($leftminute分);
							}
					}

					# ▼分までだけ取得するのでなければ、秒を取得
					if($type !~ /Get-till-minute/){
							# 秒の表示
							if($type !~ /Not-get-second/){
									if($type =~ /Omit-top-time/){ $leftsecond += 1; }
								$leftsecond_text = qq($leftsecond秒);
							}
					}

			}

	}

	# 最上位の単位のみを取得する場合
	if($type =~ /Get-top-unit/){
			if($leftyear){ $split_text = $leftyear_text; }
			elsif($leftmonth){ $split_text = $leftmonth_text; }
			elsif($leftday){ $split_text = $leftday_text; }
			elsif($lefthour){ $split_text = $lefthour_text; }
			elsif($leftminute){ $split_text = $leftminute_text; }
			else{ $split_text = $leftsecond_text; }
	}
	else{
		$split_text = qq($leftyear_text$leftmonth_text$leftday_text$lefthour_text$leftminute_text$leftsecond_text);
	}

	# ちょっとした空白表示
	if($type =~ /Blank-view/){
		$split_text =~ s/(日|時間|分|秒)/ $1/g;
	}

	# テキスト整形
	if($type =~ /Plus-text-([^\s]+)/){
		#my $plus_text = $1;
		#utf8($plus_text);
		$split_text .= qq(前);
	}

	# 色付け
	if($type =~ /Color-view/){
			if($lefttime < 1*60*60){
					if($my_use_device->{'mobile_flag'}){
						$split_text = qq(<span style="color:#f00;">$split_text</span>); 
					} else {
						$split_text = qq(<span class="red">$split_text</span>); 
					}
			}
			elsif($lefttime < 24*60*60){
					if($my_use_device->{'mobile_flag'}){
						$split_text = qq(<span style="color:#080;">$split_text</span>); 
					} else {
						$split_text = qq(<span class="gre">$split_text</span>); 
					}

			}
			elsif($lefttime < 7*24*60*60){
				$split_text = qq(<span class="blk">$split_text</span>); 
			}
			else{
				$split_text = qq(<span style="color:#555;">$split_text</span>); 
			}
	}

	# リターン
	if($type !~ /UTF8/){
		shift_jis($split_text);
	}

$split_text;

}

#-----------------------------------------------------------
# 掲示板の日付を分解
#-----------------------------------------------------------
sub SplitMebiDate{

# 宣言
my($type,$date) = @_;
my(%date);

	# 汚染チェック
	if($date eq ""){ return(); }

# 分解
($date{'year_month_day'},$date{'hour_min_sec'}) = split(/\s/,$date);
($date{'year'},$date{'month'},$date{'day'}) = split(/\//,$date{'year_month_day'});
($date{'hour'},$date{'min'},$date{'sec'}) = split(/:/,$date{'hour_min_sec'});

	# 各種補完
	if($date{'month'} eq ""){ $date{'month'} = 1; }
	if($date{'sec'} eq ""){ $date{'sec'} = 00; }

	# グリニッジ標準時を取得
	if($date{'year'} && $date{'month'} && $date{'day'}){
		($date{'time'}) = Time::Local::timelocal($date{'sec'},$date{'min'},$date{'hour'},$date{'day'},$date{'month'}-1,$date{'year'});
	}

return(%date);

}

#-----------------------------------------------------------
# 時刻
#-----------------------------------------------------------
sub TimeLocal{

my($type,$year,$month,$day,$hour,$minute,$second) = @_;
	if($type =~ /Relay-reverse/){ (undef,$second,$minute,$hour,$day,$month,$year) = @_; }
my($time,$pure_year);

# タイムゾーンを定義
$ENV{'TZ'} = "JST-9";

	# 汚染チェック
	if($year =~ /\D/){ return(undef,"年に半角数字以外が指定されています。"); }
	if($month =~ /\D/){ return(undef,"月に半角数字以外が指定されています。"); }
	if($day =~ /\D/){ return(undef,"日に半角数字以外が指定されています。"); }
	if($hour =~ /\D/){ return(undef,"時間に半角数字以外が指定されています。"); }
	if($minute =~ /\D/){ return(undef,"分に半角数字以外が指定されています。"); }
	if($second =~ /\D/){ return(undef,"秒に半角数字以外が指定されています。"); }

	# 指定がない場合の代入
	if(!$year){ return(undef,"年は必ず指定してください。"); }
	if(!$month){ $month = "01"; }
	if(!$day){ $day = "01"; }

	# 日のチェック
	if($day > 31){ return(undef,"日に指定できるのは３１日までです。"); }

	# ●月のチェック
	if($month){

			# 妙な月指定は除外する
			if($month > 12){ return(undef,"$month月という月はありません。"); }

			# 30日までしかない月のチェック
			if($month =~ /^(4|6|9|11)$/ && $day && $day > 30){
				return(undef,"$month月は30日までしかありません。");
			}

			# ２月のチェック
			if($month =~ /^(2)$/ && $day && $day > 28 && $year && $year % 4 != 0){
				return(undef,"$year年の$month月は28日までしかありません。");
			}

			# ２月のチェック
			if($month =~ /^(2)$/ && $day && $day > 29){
				return(undef,"$year年の$month月は29日までしかありません。");
			}

	}

	# ●1970年以前の場合
	if($year < 1970){
		$pure_year = $year;
		$year = 1970;
	}

# グリニッジ標準時を取得
$time = Time::Local::timelocal($second,$minute,$hour,$day,$month-1,$year);

	# 1970年以前の場合
	if($pure_year){
		$time -= int ( (1970 - $pure_year) * 365.24219*24*60*60 );
	}

return($time);

}

#-----------------------------------------------------------
# 日付からグリニッジ標準時を計算し、さらに日付を計算する (曜日の補完)
#-----------------------------------------------------------
sub TimeLocalDate{

my($type,$year,$month,$day,$hour,$minute,$second) = @_;

my($time_local) = Mebius::TimeLocal(undef,$year,$month,$day,$hour,$minute,$second);

my(%date) = Mebius::Getdate("Get-hash",$time_local);

return(%date);

}
1;

