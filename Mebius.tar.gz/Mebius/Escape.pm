
# パッケージ宣言
package Escape;
use strict;

#-----------------------------------------------------------
# HTMLエスケープ
#-----------------------------------------------------------
sub HTML{

# 宣言
my($html,$use) = @_;
my(@escaped_html,$count_escaped);

	# 要素を展開
	foreach(@$html){

		# 定義
		my $html_foreach = $_;

		# 多重エスケープを予防
		$html_foreach =~ s/&amp;/&/g;

		# 汚染チェック
		$html_foreach =~ s/\0//g;
		#$html_foreach =~ s/\n//g;
		#$html_foreach =~ s/\r//g;

		# タグ変換
		$count_escaped += ($html_foreach =~ s/&/&amp;/g);
		$count_escaped += ($html_foreach =~ s/</&lt;/g);
		$count_escaped += ($html_foreach =~ s/>/&gt;/g);

			# タグ内の属性エスケープ
			if(!$use->{'NotValue'}){
				$count_escaped += ($html_foreach =~ s/"/&quot;/g);
				$count_escaped += ($html_foreach =~ s/'/&#039;/g);
			}

		# 配列に追加
		push(@escaped_html,$html_foreach);

	}

	# リターン
	if(@escaped_html <= 1){
		return($escaped_html[0]);
	}
	else{
		return(@escaped_html);
	}

}

#-----------------------------------------------------------
# Javascript
#-----------------------------------------------------------
sub javascript{

my $text = shift;
my $self = javascript_multi($text);

}

#-----------------------------------------------------------
# Javascript
#-----------------------------------------------------------
sub javascript_high{

my $text = shift;
my $self = javascript_multi({ High => 1 },$text);

}


#-----------------------------------------------------------
# Javascript
#-----------------------------------------------------------
sub javascript_multi{

my $use = shift if(ref $_[0] eq "HASH");
my $text = shift;

	if($use->{'High'}){
		$text =~ s/[\n\r]/\\\\n/g;
		$text =~ s/"/&quot;/g;
		$text =~ s/</&lt;/g;
		$text =~ s/>/&gt;/g;
	} else {
		$text =~ s/[\n\r]/\\\\n/g;
	}

$text =~ s/'/\\'/g;
$text =~ s/"/\\"/g;
$text =~ s!/!\\/!g;

$text =~ s/[\r\n]//g;

$text;

}



#-----------------------------------------------------------
# データファイル
#-----------------------------------------------------------
#sub DataFile{

# 宣言
#my($data,$use) = @_;
#my(@escaped_data);

	# 要素を展開
#	foreach my $data (@$data){
#			($data) = HTML([$data]);
#			$data =~ s/[\n\r]//g;
#	}


	# リターン
#	if(@escaped_data <= 1){
#		return($escaped_data[0]);
#	}
#	else{
#		return(@escaped_data);
#	}


#}




1;