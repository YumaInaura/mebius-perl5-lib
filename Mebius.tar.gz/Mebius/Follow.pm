
use strict;
package Mebius::Follow;

#-----------------------------------------------------------
# テーブル名
#-----------------------------------------------------------
sub main_table_name{
"follow";
}

#-----------------------------------------------------------
# テーブルの全てのレコードを取得
#-----------------------------------------------------------
sub all_records{

my($table_name) = main_table_name() || die("Can't decide main table name.");

my($data) = Mebius::DBI::fetchrow_hashref_on_arrayref("SELECT * FROM `$table_name`");

}


#-----------------------------------------------------------
# 掲示板への投稿
#-----------------------------------------------------------
sub new_regist_bbs{

my($update) = @_;
my($table_name) = main_table_name() || die("Can't decide main table name.");

Mebius::DBI::update_or_insert(undef,$table_name,$update,"bbs_kind");

	# 一定確率でバックアップを作成
	if(rand(5000) < 1 || Mebius::AlocalJudge()){
		Mebius::DBI::backup_table_with_random(undef,$table_name);
	}

}


#-----------------------------------------------------------
# テーブル作成
#-----------------------------------------------------------
sub create_main_table{

my($dbh) = Mebius::DBI::connect();
my($table_name) = main_table_name() || die("Can't decide main table name.");

#	my($bbs_kind2,$bbs_title2,$thread_number2,$thread_subject2,$res_number2,$res_handle2,$res_cnumber2,$res_account2,$lasttime2) = split(/<>/);

#print "table name is $table_name.\n";

my $set = {
bbs_kind => { NOT_NULL => 1 , PRIMARY => 1 },
real_bbs_kind => { NOT_NULL => 1 } , 
server_domain => { NOT_NULL => 1 } , 
thread_number => { INT => 1 , NOT_NULL => 1 } ,
bbs_title => { NOT_NULL => 1 } , 
res_number => { INT => 1 , NOT_NULL => 1 } ,
last_handle => { NOT_NULL => 1 } , 
subject => { NOT_NULL => 1 } , 
cnumber => { NOT_NULL => 1 } , 
account => { NOT_NULL => 1 } , 
regist_time => { INT => 1 , NOT_NULL => 1 } ,
last_update_time => { INT => 1 , NOT_NULL => 1 } , 
};

# メモリテーブルを作成
Mebius::DBI::create_memory_table_and_backup(undef,$table_name,$set);

}


1;
