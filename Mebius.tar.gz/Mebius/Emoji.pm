use strict;
package Mebius;

#-----------------------------------------------------------
# �[�����ƂɊG������U�蕪��
#-----------------------------------------------------------

sub Emoji{

# �錾
my($type,$device_id) = @_;
my(%emoji);

	# Docomo
	if($device_id eq "DOCOMO"){

		# ����o�C�i���f�[�^
		$emoji{'write'} = '�R';
		$emoji{'exclamation'} = '��';
		$emoji{'new'} = '��';
		$emoji{'up'} = '��';
		$emoji{'mail'} = '�w';
		$emoji{'heart1'} = '��';
		$emoji{'heart2'} = '��';
		$emoji{'heart3'} = '��';
		$emoji{'home'} = '��';
		$emoji{'smile'} = '��';
		$emoji{'sad'} = '��';
		$emoji{'search'} = '��';
		$emoji{'alert'} = '��';
		$emoji{'night'} = '�W';
		$emoji{'sun'} = '��';
		$emoji{'panic'} = '��';
		$emoji{'wrench'} = '��';
		$emoji{'mobile'} = '��';
		$emoji{'hat'} = '��';
		$emoji{'number1'} = '��';
		$emoji{'number2'} = '��';
		$emoji{'number3'} = '��';
		$emoji{'number4'} = '��';
		$emoji{'number5'} = '��';
		$emoji{'number6'} = '��';
		$emoji{'number7'} = '��';
		$emoji{'number8'} = '��';
		$emoji{'number9'} = '��';
		$emoji{'number0'} = '��';
	}

	# AU
	elsif($device_id eq "AU"){

		# Shift-jis�R�[�h
		$emoji{'write'} = "&#xF7DA;";
		$emoji{'exclamation'} = "&#xF65A;";
		$emoji{'new'} = '&#xF7E5;';
		$emoji{'up'} = '&#xF6E8;';
		$emoji{'mail'} = '&#xF6FA;';
		$emoji{'heart1'} = '';
		$emoji{'heart2'} = '';
		$emoji{'heart3'} = '';
		$emoji{'home'} = '&#xF7E0;';
		$emoji{'smile'} = '';
		$emoji{'sad'} = '';
		$emoji{'search'} = '';
		$emoji{'alert'} = '';
		$emoji{'night'} = '';
		$emoji{'sun'} = '';
		$emoji{'panic'} = '';
		$emoji{'hat'} = '&#xF3C9;';
		$emoji{'mobile'} = '&#xF7A5;';
		$emoji{'wrench'} = '&#xF7A4;';
		$emoji{'number1'} = "&#xF6FB;";
		$emoji{'number2'} = "&#xF6FC;";
		$emoji{'number3'} = "&#xF740;";
		$emoji{'number4'} = "&#xF741;";
		$emoji{'number5'} = "&#xF742;";
		$emoji{'number6'} = "&#xF743;";
		$emoji{'number7'} = "&#xF744;";
		$emoji{'number8'} = "&#xF745;";
		$emoji{'number9'} = "&#xF746;";
		$emoji{'number0'} = "&#xF7C9;";

	}

	# Softbank
	elsif($device_id eq "SOFTBANK"){

		# �o�C�i���f�[�^(Web�R�[�h)
		$emoji{'write'} = '$O!';
		$emoji{'exclamation'} = '$GA';
		$emoji{'new'} = '$F2';
		$emoji{'up'} = '$F3';
		$emoji{'mail'} = '$E#';
		$emoji{'mobile'} = '$E$';
		$emoji{'heart1'} = '';
		$emoji{'heart2'} = '';
		$emoji{'heart3'} = '';
		$emoji{'home'} = '$GV';
		$emoji{'smile'} = '';
		$emoji{'sad'} = '';
		$emoji{'search'} = '$E4';
		$emoji{'alert'} = '$Fr';
		$emoji{'night'} = '';
		$emoji{'sun'} = '';
		$emoji{'panic'} = '';
		$emoji{'hat'} = '$Q#';
		$emoji{'wrench'} = '$E6';
		$emoji{'number1'} = '$F<';
		$emoji{'number2'} = '$F=';
		$emoji{'number3'} = '$F>';
		$emoji{'number4'} = '$F?';
		$emoji{'number5'} = '$F@';
		$emoji{'number6'} = '$FA';
		$emoji{'number7'} = '$FB';
		$emoji{'number8'} = '$FC';
		$emoji{'number9'} = '$FD';
		$emoji{'number0'} = '$FE';

	}

	# ���̑�
	else{
		$emoji{'home'} = "Top";
		$emoji{'exclamation'} = "�I";
		$emoji{'alert'} = "!!";
		$emoji{'new'} = "New";
		$emoji{'up'} = "Up";
		$emoji{'wrench'} = "�ݒ�";
		$emoji{'number1'} = "�@";
		$emoji{'number2'} = "�A";
		$emoji{'number3'} = "�B";
		$emoji{'number4'} = "�C";
		$emoji{'number5'} = "�D";
		$emoji{'number6'} = "�E";
		$emoji{'number7'} = "�F";
		$emoji{'number8'} = "�G";
		$emoji{'number9'} = "�H";
		$emoji{'number0'} = "(0)";
	}

return(%emoji);

}

#-----------------------------------------------------------
# �G�����̕ʕ\�� ( �ۑ��p )
#-----------------------------------------------------------
sub Emoji_second{

# �錾
my(%emoji);

		# Docomo -�R�[�h
		$emoji{'write'} = "&#xE6AE;";
		$emoji{'exclamation'} = "&#xE702;";
		$emoji{'number1'} = "&#xE6E2;";
		$emoji{'number2'} = "&#xE6E3;";
		$emoji{'number3'} = "&#xE6E4;";
		$emoji{'number4'} = "&#xE6E5;";
		$emoji{'number5'} = "&#xE6E6;";
		$emoji{'number6'} = "&#xE6E7;";
		$emoji{'number7'} = "&#xE6E8;";
		$emoji{'number8'} = "&#xE6E9;";
		$emoji{'number9'} = "&#xE6Ea;";
		$emoji{'number0'} = "&#xE6Eb;";

		# AU -�^�O
		$emoji{'write'} = qq(<img localsrc="508" />);
		$emoji{'exclamation'} = qq(<img localsrc="2" />);
		$emoji{'number1'} = qq(<img localsrc="180" />);
		$emoji{'number2'} = qq(<img localsrc="181" />);
		$emoji{'number3'} = qq(<img localsrc="182" />);
		$emoji{'number4'} = qq(<img localsrc="183" />);
		$emoji{'number5'} = qq(<img localsrc="184" />);
		$emoji{'number6'} = qq(<img localsrc="185" />);
		$emoji{'number7'} = qq(<img localsrc="186" />);
		$emoji{'number8'} = qq(<img localsrc="187" />);
		$emoji{'number9'} = qq(<img localsrc="188" />);
		$emoji{'number0'} = qq(<img localsrc="325" />);

		# Softbank- Unicode
		$emoji{'write'} = "&#xE301;";
		$emoji{'exclamation'} = "&#xE021";
		$emoji{'number1'} = "&#xE21C;";
		$emoji{'number2'} = "&#xE21D;";
		$emoji{'number3'} = "&#xE21E;";
		$emoji{'number4'} = "&#xE21F;";
		$emoji{'number5'} = "&#xE220;";
		$emoji{'number6'} = "&#xE221;";
		$emoji{'number7'} = "&#xE222;";
		$emoji{'number8'} = "&#xE223;";
		$emoji{'number9'} = "&#xE224;";
		$emoji{'number0'} = "&#xE225;";

}


1;
