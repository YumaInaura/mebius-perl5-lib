
use strict;
use Encode;
use Mebius::Encoding;
package Mebius::Fillter;

#-----------------------------------------------------------
# 本文とタイトルを一斉判定
#-----------------------------------------------------------
sub ads {

# 宣言
my($use,$subject,$comment) = @_;
my($fillter_flag);

	# 題名フィルタ
	if(Mebius::Fillter::SubjectFillter({ FromEncoding => $use->{'FromEncoding'} },$subject)){ $fillter_flag = 1; }

	# コメントフィルタ
	if(Mebius::Fillter::CommentFillter({ FromEncoding => $use->{'FromEncoding'} },$comment)){ $fillter_flag = 1; }

return($fillter_flag);

}

#-----------------------------------------------------------
# 複数のフィルタを一斉に適用
#-----------------------------------------------------------
sub Ads{

my($flag) = ads(@_);

$flag;

}


#-----------------------------------------------------------
# 題名フィルタ
#-----------------------------------------------------------
sub SubjectFillter{

# 宣言
my($use,$subject) = @_;
my($fillter_flag);

	# エンコード調整
	if($use->{'FromEncoding'}){
		Mebius::Encoding::from_to($use->{'FromEncoding'},"utf8",$subject);
	}

	# 題名がない場合
	if($subject eq ""){ return(); }

# 空白を削除
$subject =~ s/(\s|　)//g;

	# 攻撃的
	if($subject =~ /(グロ|性|暴|殺|死|氏ね|タヒ|ギャンブル|馬鹿|虐待|嫌い|反対|アンチ|厨|糞|カス|荒らし|売国|クソ|爆発し)/){ $fillter_flag = 1; }
	if($subject =~ /(う|ウ)((ざ|ザ)(い|イ|っ|ッ|かった|すぎ)|(ぜ|ゼ)(え|ぇ|エ|ェ|ー))/){ $fillter_flag = 1; }
	if($subject =~ /((き|キ)(も|モ)(い|イ)|キモ)/){ $fillter_flag = 1; }
	if($subject =~ /(グチ|愚痴|最悪|恨み|アホ|喧嘩|ケンカ)/){ $fillter_flag = 1; }
	if($subject =~ /(むか|ムカ|イラ|苛)(つく|つい|ツク)|(イライラ|いらいら|苛々|苛苛|憎い)/){ $fillter_flag = 1; }
	if($subject =~ /(ワロタ|ワロス|わろた|(\(|（)(笑|怒))/){ $fillter_flag = 1; }
	if($subject =~ /(マジキチ|キチガイ|低脳|炎上|基地(外|街)|気(狂|違)い|ビッチ)/){ $fillter_flag = 1; }
	if($subject =~ /(リンチ)/){ $fillter_flag = 1; }
	if($subject =~ /(DQN|ＤＱＮ)/){ $fillter_flag = 1; }
	if($subject =~ /(反対)/){ $fillter_flag = 1; }
	if($subject =~ /(ﾌﾟｷﾞｬ|プギャ)/){ $fillter_flag = 1; }


	# 荒れやすい
	if($subject =~ /(不良)/){ $fillter_flag = 1; }

	# 性的
	if($subject =~ /(マスターベーション|自慰|性器|ムラムラ|陰毛)/){ $fillter_flag = 1; }
	if($subject =~ /(処女|童貞)/){ $fillter_flag = 1; }
	if($subject =~ /(セックス|セフレ|フェチ|エロ|エッチ|コンドーム|ポルノ|アナル|クンニ|フェラ|勃起|エクスタシ|えっち|パンツ|性的|風俗|巨乳|貧乳|下ネタ|セクハラ|裸|売春)/){ $fillter_flag = 1; }
	if($subject =~ /(変態|変人|淫乱|欲求不満|卑猥|性欲|奴隷|露出|痴漢|監禁|チカン|乳首)/){ $fillter_flag = 1; }
	if($subject =~ /(幼女|ロリコン|ロリ|ショタ|ホモ|レズ|ペド|SM|ＳＭ|レイプ|犯(さ|し|す|せ|そ))/){ $fillter_flag = 1; }
	if($subject =~ /(20|18|15|２０|１８|１５)(禁|R|Ｒ)/){ $fillter_flag = 1; }
	if($subject =~ /(R|Ｒ)(-)?(20|18|15|２０|１８|１５)/){ $fillter_flag = 1; }

	# 下品
	if($subject =~ /(う|ウ)(ん|ン)(ち|チ|こ|コ)/){ $fillter_flag = 1; }
	if($subject =~ /(ち|チ)(ん|ン)(こ|コ|ぽ|ポ)/){ $fillter_flag = 1; }
	if($subject =~ /(ま|マ)(ん|ン)(こ|コ)/){ $fillter_flag = 1; }
	if($subject =~ /(金玉)/){ $fillter_flag = 1; }

	# 自己警告
	if($subject =~ /((閲覧|観覧)(.*?)(注意|禁止))/){ $fillter_flag = 1; }

	# 犯罪
	if($subject =~ /(犯罪|違法|事件)/){ $fillter_flag = 1; }

	# 病
	if($subject =~ /(リスカ|アムカ|リストカット|自傷)/){ $fillter_flag = 1; }

	# 規約
	if($subject =~ /(広告|アフィ|クリック|くりっく)/){ $fillter_flag = 1; }

	# 問題が起こりやすいスレッド	
	if($subject =~ /(いじめ|宗教|ストレス|批判)/){ $fillter_flag = 1; }

	# その他
	if($subject =~ /(兵器)/){ $fillter_flag = 1; }
	if($subject =~ /(創価)/){ $fillter_flag = 1; }
	if($subject =~ /(差別)/){ $fillter_flag = 1; }
	if($subject =~ /(麻薬|薬物|覚(せい|醒)剤)/){ $fillter_flag = 1; }
	if($subject =~ /(してはいけない)/){ $fillter_flag = 1; }

	# 予備
	if($subject =~ /(ハッキング|クラッキング)/){ $fillter_flag = 1; }



return($fillter_flag);

}


#-----------------------------------------------------------
# 本文フィルタ
#-----------------------------------------------------------
sub CommentFillter{

# 宣言
my($use,$comment) = @_;
my($fillter_flag);

	# エンコード調整
	if($use->{'FromEncoding'}){
		Mebius::Encoding::from_to($use->{'FromEncoding'},"utf8",$comment);
	}

	if(!$comment){ return(); }

	# 本文判定
	if($comment =~ /(性器|精子|セックス|オナ(ニ)?|生理|自慰|ペニス|性的|レイプ|ロリコン|勃起|乳首)/){ $fillter_flag = 1; }
	if($comment =~ /(エッチ)/){ $fillter_flag = 1; }
	if($comment =~ /(幼女)/){ $fillter_flag = 1; }
	if($comment =~ /(マスターベーション)|(コンドーム)|(アームカット)/){ $fillter_flag = 1; }
	if($comment =~ /(リストカット|リスカ|アムカ|カッティング|自殺|事件|殺人|暴行|殺(したい))/){ $fillter_flag = 1; }
	if($comment =~ /(むか|ムカ)(つく|ツク)/){ $fillter_flag = 1; }
	if($comment =~ /(うんこ|大便)/){ $fillter_flag = 1; }

return($fillter_flag);

}



1;