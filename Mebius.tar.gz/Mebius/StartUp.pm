
use strict;

use Encode::Guess;
use Encode qw();

use Time::Local;
use File::Copy;
use Digest::MD5;
use CGI;
use Apache::DBI;

use Mebius::Basic;
use Mebius::BBS;
use Mebius::FsWikiBasic; # server1�̂�
use Mebius::DBI;

Mebius::DBI::create_all_tables();

1;
