
# パッケージ宣言
package Mebius;
use strict;
use utf8;
use Mebius::Export;
#use CGI;

#-----------------------------------------------------------
# $postbuf を展開
# 返す結果は &Escape していないので注意、そのままデータに書き込まないように
#-----------------------------------------------------------
sub ForeachQuery{

# 宣言
my($type,$query,$exclusion_names) = @_;
#my(@exclusion_name) = $@exclusion_names;
my($return_query,$query_foreach,%exclusion);
my($encoded_query,$natural_query,$hit_query,@query,%natural_query,%encoded_query,%query);

	# 除外する引数をハッシュ化
	foreach(split(/,/,$exclusion_names)){
		$exclusion{$_} = 1;
	}

	# クエリを展開
	foreach(keys %main::in){

		my $name = $_;
		my $value = $main::in{$_};

			# 除外する引数
			if($exclusion{$name}){ next; }

		# ヒットカウンタ
		$hit_query++;

		# クエリをエスケープ
		if($type =~ /Escape-query/){
			($value) = Mebius::Escape(undef,$value);
		}

		# ナチュラルクエリを追加
		if($type =~ /Get-natural-query/){
				if($hit_query >=2){
					$natural_query .= "&";
				}
			$natural_query .= qq($name=$value);
			$natural_query{$_} = $value;
		}

		# クエリをエンコード
		my($value_encoded2) = Mebius::Encode(undef,$value);

			# クエリを追加
			if($hit_query >=2){
				$encoded_query .= "&";
			}
		$encoded_query .= qq($name=$value_encoded2);
		$encoded_query{$_} = $value_encoded2;

	}

	# タイプに応じてリターン
	if($type =~ /Get-natural-query/){
		return($natural_query);
	}
	else{
		return($encoded_query);
	}

}

#-----------------------------------------------------------
# クエリを展開して、inout hidden のタグを取得 ( 上の処理と一部重複しているけど、新しい処理を作る )
#-----------------------------------------------------------
sub foreach_query_and_get_input_hidden_tag{

my $use = shift if(ref $_[0] eq "HASH");
my($self);
my($q) = Mebius::query_state();

	# すべてのクエリを展開
	foreach my $name ($q->param()){

		my $value = $q->param($name);

			# 特定のパラメータを除外
			if(ref $use->{'exclusion'} eq "ARRAY"){
				my($exclusion_flag);
					foreach my $exclution (@{$use->{'exclusion'}}){
							if($name eq $exclution){ $exclusion_flag = 1; }
					}
					if($exclusion_flag){ next; }
			}

			# 許可したパラメータだけ展開
			elsif(ref $use->{'limited'} eq "ARRAY"){
				my($limited_flag);
					foreach my $limited (@{$use->{'limited'}}){
							if($name eq $limited){ $limited_flag = 1; }
					}
					if(!$limited_flag){ next; }
			}

		$self .= qq(<input type="hidden" name=").e($name).qq(" value=").e($value).qq(">\n);
	}

$self;

}

#-----------------------------------------------------------
# クエリをハッシュリファレンスとして扱う
#-----------------------------------------------------------
sub query_single_param{

# Near State （呼び出し） 2.30
my $HereName1 = "query_hash_ref";
my $StateKey1 = "normal";
my($state) = Mebius::State::Call(__PACKAGE__,$HereName1,$StateKey1);
	if(defined $state){ return($state); }

my($q) = Mebius::query_state();
my(%self);

	foreach($q->param()){
		$self{$_} = $q->param($_);
	}

	# Near State （保存） 2.30
	if($HereName1){ Mebius::State::Save(__PACKAGE__,$HereName1,$StateKey1,\%self); }


\%self;

}

#-----------------------------------------------------------
# クエリを覚えておく
#-----------------------------------------------------------
sub query_state{

# Near State （呼び出し） 2.30
my $HereName1 = "query_state";
my $StateKey1 = "normal";
my($state) = Mebius::State::Call(__PACKAGE__,$HereName1,$StateKey1);
	if(defined $state){ return($state); }
	#else{ Mebius::State::ElseCount(__PACKAGE__,$HereName1,$StateKey1); }

my $q = new CGI;

	# Near State （保存） 2.30
	if($HereName1){ Mebius::State::Save(__PACKAGE__,$HereName1,$StateKey1,$q); }

$q;

}

#-----------------------------------------------------------
# UTF8のクエリ
#-----------------------------------------------------------
sub query_state_utf8{

my($q) = Mebius::query_state();
my(%self,$debug_line);

	foreach my $name ($q->param()){
		my $query = $q->param($name);
		($self{$_}) = gq_utf8($query);
		#$debug_line .= qq($query=$name / );
	}

	#if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($debug_line)); }

\%self;

}

package Mebius::Query;

#-----------------------------------------------------------
# POST メソッドなら
#-----------------------------------------------------------
sub post_method_judge{

	if($ENV{'REQUEST_METHOD'} eq "POST"){
		1;
	} else {
		0;
	}

}



#-----------------------------------------------------------
# POST メソッドなら
#-----------------------------------------------------------
sub get_method_judge{

	if($ENV{'REQUEST_METHOD'} eq "GET"){
		1;
	} else {
		0;
	}

}


1;
