
package Mebius::Goldcenter;

use Mebius::Goldcenter::GoldcenterMain;
use Mebius::Goldcenter::GoldcenterMonster;

1;
