
use strict;
package Mebius::Server;

#-----------------------------------------------------------
# BBS�p�̃T�[�o�[���ǂ����𔻒�
#-----------------------------------------------------------
sub bbs_server_judge{

my $self;

	if($ENV{'SERVER_ADDR'} eq "112.78.200.216" || $ENV{'SSH_CONNECTION'} =~ /112\.78\.200\.216/ || Mebius::AlocalJudge()){
		$self = 1;
	}


}

1;
