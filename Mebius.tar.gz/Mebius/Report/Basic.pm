
	
# 宣言
use strict;
use Mebius::BBS;
package Mebius::Report;
use Mebius::Export;

#	if(Mebius::AlocalJudge()){ my($domain_links) = Mebius::domain_links(); Mebius::Debug::Error(shift_jis($domain_links)); }

#-----------------------------------------------------------
# (ユーザーによる)報告モードの分岐判定
#-----------------------------------------------------------
sub report_mode_junction{

my $use = shift if(ref $_[0] eq "HASH");

	# ここでエラーも一緒にチェック、エラーがなければ処理続行
	if(send_report_justy_judge()){
		Mebius::Report::send_report();
	}

	# 報告の送信 ( レス )
	# ここでエラーも一緒にチェック、エラーがなければ処理続行
	#if(send_report_justy_judge({ ResMode => 1 })){
	#		if(bbs_thread_judge()){
	#			Mebius::Report::send_report();
	#		} else{
	#			die("Perl Die! Mode is empty.");
	#		}

	#} elsif(send_report_justy_judge({ ThreadMode => 1 })){
	#		if(bbs_thread_judge()){
	#			Mebius::Report::send_report();
	#		} else{
	#			die("Perl Die! Mode is empty.");
	#		}

	#}

}

#-----------------------------------------------------------
# 報告モードに移行するボタン
#-----------------------------------------------------------
sub move_to_report_mode_button{

my $use = shift if(ref $_[0] eq "HASH");
my($self);

	# 報告モードの場合
		my($request_url) = Mebius::request_url();

	if(report_mode_judge_for_thread()){
		$self .= qq( <input type="button" value="スレッドを報告" class="report disabled" disabled>\n);
	} else {
		$self .= qq(<form action="./?report=).e(time).qq(#REPORT_THREAD" method="post" class="inline" >\n);
			my($foreach_hidden_tags) = Mebius::foreach_query_and_get_input_hidden_tag({ exclusion => ["report_mode_for_res","report_mode_for_thread"] });
		gq_utf8($foreach_hidden_tags);
		$self .= qq($foreach_hidden_tags);
		$self .= qq(<input type="submit" name="report_mode_for_thread" value="スレッドを報告" class="report">\n);
		$self .= qq(</form>\n);
	}

	if(report_mode_judge_for_res()){
		$self .= qq(<input type="button" value="レスをまとめて報告" class="report disabled" disabled>\n);
	}	elsif($use->{'ViewResReportButton'}){
			$self .= qq(<form action="./?report=).e(time).qq(#REPORT_RES" method="post" class="inline" >\n);
			my($foreach_hidden_tags) = Mebius::foreach_query_and_get_input_hidden_tag({ exclusion => ["report_mode_for_res","report_mode_for_thread"] });
			gq_utf8($foreach_hidden_tags);
			$self .= qq($foreach_hidden_tags);
			$self .= qq(<input type="submit" name="report_mode_for_res" value="レスをまとめて報告" class="report">\n);
			$self .= qq(</form>\n);
	}

$self;

}


#-----------------------------------------------------------
# 報告用のチェックボックス (レス単位)
#-----------------------------------------------------------
sub report_check_box_per_res{

my $use = shift if(ref $_[0] eq "HASH");
my $res_number = shift;
my($parts) = Mebius::Parts::HTML();
my($q) = Mebius::query_state();
my($use_device) = Mebius::my_use_device();
my($self,$checked,$i,$line);

	# 報告モードでなければリターン
	if(!report_mode_judge_for_res()){ return(); }

	# 最初のレスは別形式での報告になるため、リターンする
	if($res_number <= 0){ return(); }


$self .= qq(<div class="right padding-height">);

	# ●コメントの報告欄
	if(!$use->{'comment_deleted_flag'}){

			# ▼１レスごとに理由を選択する場合
			if(select_reason_per_res_judge()){
				$self .= qq(違反タイプ： );
				$self .= select_box_for_report_res({ select_name => "report_res_$res_number" , res_number => $res_number });

			# ▼1レスごとにチェックだけ入れて、あとで一種類の理由を選ぶ場合
			} else {

				# 初期チェックを入れる場合
				my(@query) = $q->param('report_res');
					foreach(@query){
							if($_ eq $res_number){ $checked = $parts->{'checked'}; }
					}

				$self .= qq(<label class="padding" id="report_res_label_).e($res_number).qq(">);
				$self .= qq(<input type="checkbox" name="report_res" value=").e($res_number).qq(" onclick="bgswitch\('report_res_label_).e($res_number).qq(',this.id,'#ff0','#9f9'\);vblock('report_option_).e($res_number).qq(');" id="report_res_).e($res_number).qq(" $checked>);
				$self .= qq(このレスを報告する);
				$self .= qq(</label>);
			}
	} else {
		$self .= qq(<span class="alert">※コメントは削除済みです。</span>);
	}

	# オプション
	{
		my($checked_report_handle,$name);

			if(select_reason_per_res_judge()){
					if($q->param("report_handle_$res_number")){
						$checked_report_handle = $parts->{'checked'};
					}
			} else {
					foreach($q->param('report_handle')){
							if($_ eq $res_number){ $checked_report_handle = $parts->{'checked'}; }
					}
			}

		$self .= qq(<div class="size80">);
			if(!$checked_report_handle && !$use_device->{'mobile_flag'}){ 
				$self .= qq(<a href="javascript:vinline\('report_option_).e($res_number).qq('\);vnone\('report_option_foreach_).e($res_number).qq('\);" class="fold" id="report_option_foreach_).e($res_number).qq(">▼オプション</a>);
			}
		$self .= qq(<span id="report_option_).e($res_number).qq(" class=");
			# 既に選択されているオプション項目が一つでもある場合は、最初から展開状態にする ( CSS で隠さない )
			if($checked_report_handle){ 
				0;
			} else{
				$self .= " none";
			}
		$self .= qq(">);
		$self .= qq(オプション：);

			# モードによって、input の name の値を決める
			if(!$use->{'handle_deleted_flag'}){
					if(select_reason_per_res_judge()){
						$name = qq(report_handle_).e($res_number);
					} else { 
						$name = qq(report_handle);
					}
				$self .= qq(<label><input type="checkbox" name="$name" value=").e($res_number).qq("$checked_report_handle> 筆名 \( ).e($use->{'handle'}).qq( \) に問題があります。</label>);
			}
		$self .= qq(</span>);
		$self .= qq(</div>);
	}

$self .= qq(</div>);

$self;

}
#-----------------------------------------------------------
# 報告フォーム全体
#-----------------------------------------------------------
sub report_mode_around_form{

my $use = shift if(ref $_[0] eq "HASH");
my $parts = shift;
my($q) = Mebius::query_state();
my($self,$display_none_class);


	# 報告モードでなければリターン
	if(!report_mode_judge()){ return($parts); }


	# 中身のパーツが設定されていない場合
	#if(!defined $parts){ return(); }

	# パーツ定義
	{

			# 帯
			if(report_mode_judge_for_res()){
				$self .= qq(<div style="background:#090;" class="padding-height center margin-bottom" id="REPORT_RES"><strong class="white">レスの報告</strong></div>);
			} elsif (report_mode_judge_for_thread()){
				$self .= qq(<div style="background:#090;" class="padding-height center margin-bottom" id="REPORT_RES"><strong class="white">スレッドの報告</strong></div>);
				$display_none_class = " none"; # スレッドのレス部分だけを隠すための none
			}

		$self .= qq(<form action="./?report=).e(time).qq(#REPORT_FORM" method="post" class="inline" utn="utn">);
		$self .= qq(<input type="hidden" name="send_report" value="1">);
			if($q->param('char') =~ /^(\w+)$/){
				$self .= q(<input type="hidden" name="char" value=").e($q->param('char')).q(">);
			} else {
				my($input_char) = Mebius::Char(undef,20);
				$self .= qq(<input type="hidden" name="char" value=").e($input_char).q(">);
			}

		my($foreach_hidden_tags) = Mebius::foreach_query_and_get_input_hidden_tag({ limited => ["account","mode","moto","no","No","r","word","report_mode_for_res","report_mode_for_thread","single_reason_report_mode"] });
		gq_utf8($foreach_hidden_tags);
		$self .= qq($foreach_hidden_tags);

		# 元パーツを追加
		$self .= qq(<div class="$display_none_class">);
		$self .= qq($parts\n);
		$self .= qq(</div>);

		# フォームを追加
		($self) .= report_form({ ReportRes => 1 });

		$self .= qq(</form>\n);

	}

$self;

}


#-----------------------------------------------------------
# 報告フォーム
#-----------------------------------------------------------
sub report_form{

my $use = shift if(ref $_[0] eq "HASH");
my($q) = Mebius::query_state();
my($param) = Mebius::query_single_param();
my($my_use_device) = Mebius::my_use_device();
my($parts) = Mebius::Parts::HTML();
my($my_cookie) = Mebius::my_cookie_main_logined();
my($self,$error_message);

	# 報告モードでなければリターン
	if(!report_mode_judge()){ return(); }

	# ●タグ始まり
	{
		$self .= qq(<div class="padding" style="border:solid 1px #080;margin-bottom:1em;background:#efe;" id="REPORT_FORM">);

	}

	# ●プレビュー表示
	if($q->param('preview')){
		$self .= qq(<div class="message-blue margin">);
		$self .= qq(<h3>プレビュー：</h3>);
		my($report_detail) = e(gq_utf8($q->param('report_detail')));
		$report_detail = Mebius::auto_link_blank($report_detail);
		$report_detail =~ s/[\r\n]/<br>/g;
		$self .= $report_detail;
		$self .= qq(</div>);
	}

	# ●エラー表示
	if(send_report_judge()){

		my(@error) = send_report_basic_error_check({ BBS => 1 });
			foreach(@error){
				$error_message .= qq(<li>$_</li>);
			}

			if($error_message){
				$self .= qq(<div class="message-red red margin"><h3>エラー：</h3><ul>$error_message</ul></div>);
			}
	}

	# ●警告を表示
	if(send_report_judge()){

		my($alert_message);
		my $checked = $parts->{'checked'} if($param->{'break_alert'});
		my(@alert) = send_report_basic_alert_check({ BBS => 1 });

			foreach(@alert){
				$alert_message .= qq(<li>$_</li>);
			}

			if($alert_message ){
				$self .= qq(<div class="message-red red margin"><h3>確認：</h3><ul>$alert_message</ul><label><input type="checkbox" name="break_alert").e($checked).qq(><span>同意する</span></label></div>);
			}

	}

	# ●テーブル始まり
	{
		$self .= qq(<table class="width100">);
	}

	# ●筆名エリア
	{
		my($inputed_name);

			if($q->param('send_report') && $ENV{'REQUEST_METHOD'} eq "POST"){
				$inputed_name = $q->param('name');
			} else {
				$inputed_name = $my_cookie->{'name'};
			}
			gq_utf8($inputed_name);
		$self .= qq(<tr>);
		$self .= qq(<td style="width:8.0em;">筆名 <span class="alert">※</span></td>);
		$self .= qq(<td>);
		$self .= qq(<input type="text" name="name" value=").e($inputed_name).qq(">);
		$self .= qq(</td>);
		$self .= qq(</tr>);

	}

	# ●メールアドレスエリア
	{
		my($inputed);
			if($q->param('send_report') && $ENV{'REQUEST_METHOD'} eq "POST"){
				$inputed = $q->param('email');
			} else {
				$inputed = $my_cookie->{'email'};
			}
			gq_utf8($inputed);
		$self .= qq(<tr>);
		$self .= qq(<td>メールアドレス</td>);
		$self .= qq(<td>);
		$self .= qq(<input type="email" name="email" value=").e($inputed).qq(" placeholder="例\) example\@ne.jp">);
		$self .= qq(</td>);
		$self .= qq(</tr>);

	}

	# ● 依頼理由エリア	(レス一括)
	{

		# ▼依頼理由のリストを定義
		$self .= qq(<tr>);
		$self .= qq(<td class="valign-top">違反タイプ <span class="alert">※</span></td>);

		$self .= qq(<td>);

		# ▼スレッドへの報告
		if(report_mode_judge_for_thread()){

			($self) .= Mebius::Reason::select_box_for_thread({ input_name => "report_reason" });

		# ▼レスへの報告
		} elsif(report_mode_judge_for_res()){

				# 複数選択モード ( レスへの報告 )
				if(select_reason_per_res_judge()){
						$self .= qq(<span class="alert">各レスごとに選んで下さい。</span>);
				# 単一選択モード ( レスへの報告 )
				} else{ 

					# 理由の単一選択ボックス
					($self) .= select_box_for_report_res({ select_name => "report_reason" });

						# 注意書きエリア (依頼理由下)
						{
							#$self .= qq(<ul class="no-point red size90">);
							#$self .= qq(<li>※違反タイプが複数ある場合は、いちどに送らず、何回かに分けて報告してください。</li>);
							#$self .= qq(</ul>);
						}
				}

		}
		$self .= qq(</td>);

		$self .= qq(</tr>);

	}

	# ●参照URL
	if(report_mode_judge_for_thread()){

		my($inputed);
			if($q->param('send_report') && $ENV{'REQUEST_METHOD'} eq "POST"){
				$inputed = $q->param('referer_url');
			}
			gq_utf8($inputed);

		$self .= qq(<tr>);
		$self .= qq(<td><span class="">参照スレッド</span></td>);
		$self .= qq(<td>);
		$self .= qq(<span class=""><input type="url" name="referer_url" value=").e($inputed).qq(" placeholder="例： http://mb2.jp/_test/123.html"></span>);
		$self .= qq(<span class="guide">※ 重複記事を報告する場合などに、スレッドのURLを入力してください。</span>);
		$self .= qq(</td>);
		$self .= qq(</tr>\n);

	}

	# ●詳細エリア
	{

		$self .= qq(<tr>);
		$self .= qq(<td class="valign-top">詳細 <span class="alert">※</span></td>);

		$self .= qq(<td>);

			# ▼詳細入力エリア
			{
				$self .= qq(<textarea name="report_detail" class="wide" style="background:#fee;" placeholder="違反行為を報告します。スレッドへの書き込みではないためご注意ください。">);	# background:#efe;
					my $inputed_textarea = e($q->param('report_detail'));
					gq_utf8($inputed_textarea);
				$self .= qq($inputed_textarea);
				$self .= qq(</textarea>);

			}

			# ▼注意書きエリア (詳細下)
			{
				$self .= qq(<ul class="no-point red size90">);
				$self .= qq(<li>※報告は全体に公開されます。</li>);
				$self .= qq(</ul>);
			}

		$self .= qq(</td>);

		$self .= qq(</tr>);

	}

	# ●送信ボタン
	{
		$self .= qq(<tr>);
		$self .= qq(<td></td>);
		$self .= qq(<td>);
		$self .= qq(<input type="submit" name="preview" value="プレビュー" class="ipreview report">);
		$self .= qq(　<input type="submit" name="" value="違反報告する" class="isubmit report red" style="color:#f00;">);
		$self .= qq(</td>);
		$self .= qq(</tr>);

	}


	# ●タグ/テーブル終わり
	{
		$self .= qq(</table>);
		$self .= qq(</div>);

	}



	# ● Javascriopt
	if(!$my_use_device->{'mobile_flag'}){
		$self .= qq[
		<script>
		window.onload = function(){
		var i;
				for(i = 0; i <= 10000 ; i++){
					bgswitch('report_res_label_'+i,'report_res_'+i,'#ff0','#9f9');
				}
		}
		</script>
		];
	}


$self;

}


#-----------------------------------------------------------
# レポートのためのセレクトボックス
#-----------------------------------------------------------
sub select_box_for_report{

my($self);
my $use = shift if(ref $_[0] eq "HASH");
my($q) = Mebius::query_state();
my($parts) = Mebius::Parts::HTML();
my($kind_list);

	# 名前が指定されていない場合
	if(!$use->{'select_name'}){
		die("Perl Die! Please decide '\$use->{'select_name'}' ");
	}

$self .= qq(<select name=").e($use->{'select_name'}).qq(">);
$self .= qq(<option value="">未選択\n);

	# 削除理由を展開
	if($use->{'ResMode'}){
		($kind_list) = Mebius::Reason::kind_list_for_res();
	} elsif ($use->{'ThreadMode'}){
		($kind_list) = Mebius::Reason::kind_list_for_thread();
}

	# ●理由を展開
	foreach my $type ( sort keys %$kind_list ){

		my $hash = $kind_list->{$type};

			if($use->{'ResMode'} && !$hash->{'detail'}){ next; }

			# ▼グループが設定されている場合
			if($hash->{'group'}){
				my $i;
				$self .= qq(<optgroup label="$hash->{'title'}">\n);

					foreach my $group (@{$hash->{'group'}}){

						my($class,$selected);

						# 初期セレクト
						if(select_reason_per_res_judge()){
								if($q->param("report_res_$use->{'res_number'}") =~ /^$type-$group->{'type'}$/){
									$selected = $parts->{'selected'};
								}
						} else {
								if($q->param("report_reason") =~ /^$type-$group->{'type'}$/){

									$selected = $parts->{'selected'};
								}
						}

						$self .= qq(<option value=").e($type).qq(-).e($hash->{'group'}->[$i]->{'type'}).qq(").e($selected).qq(>).e($hash->{'group'}->[$i]->{'detail'}).qq(\n);
						$i++;
					}
				$self .= qq(</optgroup>\n);

			}

	}

$self .= qq(</select>);

$self;

}

#-----------------------------------------------------------
# スレッド報告のセレクトボックス
#-----------------------------------------------------------
sub select_box_for_report_thread{

my($use) = @_;

my %relay_hash = %$use;
$relay_hash{'ThreadMode'} = 1;

my($self) = select_box_for_report(\%relay_hash);

$self;

}

#-----------------------------------------------------------
# レス報告のセレクトボックス
#-----------------------------------------------------------
sub select_box_for_report_res{

my($use) = @_;

my %relay_hash = %$use;
$relay_hash{'ResMode'} = 1;

my($self) = select_box_for_report(\%relay_hash);

$self;

}




#-----------------------------------------------------------
# 掲示板用のレポートファイル
#-----------------------------------------------------------
sub bbs_report_file{

# 宣言
my($use) = @_;
my($q) = Mebius::query_state();
my($init_directory) = Mebius::BaseInitDirectory();
my($i,@renew_line,%self,$FILE1,$renew,%data_format,%self_renew,$file1,@all_line,%thread_data,%res_data,%collected_line_per_thread,%control);
require "${init_directory}part_view.pl";

if($use->{'file_type'} eq "sns_diary"){
	#if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($use->{'line_control'}->{'aaaa'}->{'123'}->{'res'}->{'1'})); }
}


#	if(Mebius::AlocalJudge()){ Mebius::Debug::Error(qq($use->{'line_control'}->{"test"}->{"1935"}->{'5'})); }

# ファイル定義
my($web_data_directory) = Mebius::BaseInitDirectory();
my $directory1 = $self{'directory1'} = "${web_data_directory}_report/";
	
	# ファイルの種類を定義
	if($use->{'file_type'} eq "bbs_thread"){
		$file1 = $self{'file1'} = "$self{'directory1'}report_bbs_res.log";
	} elsif($use->{'file_type'} eq "sns_diary") {
		$file1 = $self{'file1'} = "$self{'directory1'}report_sns_diary.log";
	} else {
		die("File type is not decided. '$use->{'file_type'}' is strange.");
	}

# 最大行を定義
my $max_line = 10000;

	# ファイルを開く （必要な場合はファイルロック）
	my($FILE1,$read_write) = Mebius::File::read_write($use,$file1,[$directory1]);
	if($read_write->{'f'}){ %self = (%self,%$read_write); } else { return(\%self); }

# データ構造を定義
$data_format{'1'} = [('key','report_count')];

	# トップデータを読み込み
	my($split_data) = Mebius::file_handle_to_hash(\%data_format,$FILE1);
	%self = (%self,%$split_data);

	# ●全ての行を配列に入れる
	while(<$FILE1>){

		my(%line);

		# ▼行を分解してハッシュに収める
		chomp;
		(
			$line{'key'},
			$line{'server_domain'},
			$line{'report_unique_number'},
			$line{'report_unique_char'},
			$line{'report_category'},
			$line{'report_targetA'},
			$line{'report_targetB'},
			$line{'report_targetC'},
			$line{'report_res_number'},
			$line{'report_type_res_or_thread'},
			$line{'report_reason_for_thread'},
			$line{'report_main_reason'},
			$line{'report_sub_reason'},
			$line{'report_time'},
			$line{'report_detail'},
			$line{'report_referer_url'},
			$line{'report_referer_reses'},
			$line{'report_self_check'},
			$line{'report_handle_check'},
			$line{'reporter_handle'},
			$line{'reporter_trip'},
			$line{'reporter_id'},
			$line{'reporter_cnumber'},
			$line{'reporter_account'},
			$line{'reporter_addr'},
			$line{'reporter_host'},
			$line{'reporter_user_agent'},
			$line{'reporter_mobile_uid'},
			$line{'reporter_email'},
			$line{'answer_type'},
			$line{'answer_penaly_type'},
			$line{'answer_handle'},
			$line{'answer_id'},
			$line{'answer_time'},
			$line{'answer_improper_check'},
			my @other_data
		) = split(/<>/);
		$line{'other_data'} = \@other_data;

			# 必要なデータを取得する場合
			if($use->{'GetData'}){
				$self{'unique_char'}{$line{'report_unique_char'}} = 1;
			}

			# ハッシュの別名を設定 
			if($use->{'file_type'} eq "bbs_thread"){
				$line{'bbs_kind'} = $line{'report_targetA'};
				$line{'thread_number'} = $line{'report_targetB'};
			}	elsif($use->{'file_type'} eq "sns_diary"){
				$line{'account'} = $line{'report_targetA'};
				$line{'diary_number'} = $line{'report_targetB'};
			}

			# 同じ記事をまとめるためのハッシュを定義
			if($use->{'GetIndex'}){
					$collected_line_per_thread{"$line{'report_targetA'}-$line{'report_targetB'}-$line{'report_targetC'}"}{$line{'report_res_number'}}{$line{'report_unique_number'}} = { data => \%line };
					#$thread_data{"$line{'report_targetA'}-$line{'report_targetB'}-$line{'report_targetC'}"} = \%line;
					#$res_data{"$line{'report_targetA'}-$line{'report_targetB'}-$line{'report_targetC'}"}{$line{'report_res_number'}} = \%line;
			}

			# ●ファイル更新用
			if($use->{'Renew'}){

				# ★重要…ハッシュコピー
				my(%renew) = %line;

					# 最大行数に達した場合
					if($i > $max_line){ next; }

					# ▼対応済みにする
					if($use->{'Control'}){

							# ▼掲示板での管理者対応
							if($use->{'file_type'} eq "bbs_thread"){

										#if($line{'report_type_res_or_thread'} eq "Thread"){ 	if(Mebius::AlocalJudge()){ Mebius::Debug::Error($use->{'line_control'}->{"test"}->{"1941"} . " / " . $line{'thread_number'}); } }

									# 該当の依頼がヒットした場合 ( コメント )
									if($use->{'line_control'}->{$line{'bbs_kind'}}->{$line{'thread_number'}}->{$line{'report_res_number'}}->{'comment'}->{'report_control_flag'}
										|| $use->{'line_control'}->{$line{'bbs_kind'}}->{$line{'thread_number'}}->{$line{'report_res_number'}}->{'handle'}->{'report_control_flag'}
										|| ($use->{'line_control'}->{$line{'bbs_kind'}}->{$line{'thread_number'}}->{'report_control_flag'} && $line{'report_type_res_or_thread'} eq "Thread")){

										# この行の書き換え
										$renew{'answer_type'} = $use->{'line_control'}->{$line{'thread_number'}}->{$line{'report_res_number'}}->{'comment'}->{'reason'};
										$renew{'answer_time'} = time;

									}

							# ▼SNS日記での管理者対応
							} elsif($use->{'file_type'} eq "sns_diary"){
									if($use->{'line_control'}->{$line{'account'}}->{$line{'diary_number'}}->{'res'}->{$line{'report_res_number'}} ||
									($use->{'line_control'}->{$line{'account'}}->{$line{'diary_number'}}->{'thread'} && $line{'report_type_res_or_thread'} eq "Thread")){
										$renew{'answer_time'} = time;
									}
							}

					}

				# 行を追加
				push(@renew_line,Mebius::add_line_for_file([
					$renew{'key'},
					$renew{'server_domain'},
					$renew{'report_unique_number'},
					$renew{'report_unique_char'},
					$renew{'report_category'},
					$renew{'report_targetA'},
					$renew{'report_targetB'},
					$renew{'report_targetC'},
					$renew{'report_res_number'},
					$renew{'report_type_res_or_thread'},
					$renew{'report_reason_for_thread'},
					$renew{'report_main_reason'},
					$renew{'report_sub_reason'},
					$renew{'report_time'},
					$renew{'report_detail'},
					$renew{'report_referer_url'},
					$renew{'report_referer_reses'},
					$renew{'report_self_check'},
					$renew{'report_handle_check'},
					$renew{'reporter_handle'},
					$renew{'reporter_trip'},
					$renew{'reporter_id'},
					$renew{'reporter_cnumber'},
					$renew{'reporter_account'},
					$renew{'reporter_addr'},
					$renew{'reporter_host'},
					$renew{'reporter_user_agent'},
					$renew{'reporter_mobile_uid'},
					$renew{'reporter_email'},
					$renew{'answer_type'},
					$renew{'answer_penaly_type'},
					$renew{'answer_handle'},
					$renew{'answer_id'},
					$renew{'answer_time'},
					$renew{'answer_improper_check'}
				]));


			}
		# 基本配列に追加
		push(@all_line,\%line);

	}

	# 配列をソート
	if($use->{'GetIndex'}){
		# 報告時間順
		#@all_line = sort { (split(/<>/,$b))[7-1] <=> (split(/<>/,$a))[7-1] } @all_line;
	}

	# ●ファイル更新
	if($use->{'Renew'}){

			# 新しい行を追加
			if($use->{'NewLine'}){

				# 新しい行の内容を定義
				# 更新行に新しく追加
				my($new_line,$report_num) = add_new_line({ new_unique_number => $self{'report_count'} });
				unshift(@renew_line,@$new_line);

				$self_renew{'report_count'} = $report_num;

			}

		# 任意の更新とリファレンス化
		my($renew) = Mebius::Hash::control(\%self,$use->{'select_renew'},\%self_renew);

		# データフォーマットからファイル更新
		Mebius::File::data_format_to_truncate_print(\%data_format,$FILE1,$renew,\@renew_line);

	}

close($FILE1);

	# パーミッション変更
	if($use->{'Renew'}){ Mebius::Chmod(undef,$file1); }

	# ●インデックス取得用
	if($use->{'GetIndex'}){
		($self{'index_line'}) = report_view_core({ file_type => $use->{'file_type'} },\%collected_line_per_thread);
	}

	# リターン
	if($use->{'Renew'}){
		return($renew);
	}
	else{
		return(\%self);
	}

}



#-----------------------------------------------------------
# モード切り替えリンク
#-----------------------------------------------------------
sub report_view_switch_link{

my($self);
my($q) = Mebius::query_state();

my @link = (
{ type => "" , title => "未確認" } , 
{ type => "still_admin_check" , title => "確認済み" } , 
);

	# 展開
	foreach(@link){

			# 選択状態の場合 ( クエリを判定 )
			if($_->{'type'} eq $q->param('view_type')){
				$self .= e($_->{'title'}).qq(\n);

			# 非選択状態の場合 ( クエリを判定 )
			} else {
				# リンクを定義
				$self .= qq(<a href="?mode=report_view);
					if($_->{'type'}){
						$self .= qq(&amp;view_type=).e($_->{'type'});
					}
				$self .= qq(">).e($_->{'title'}).qq(</a>\n);
			}
	}

$self;


}

#-----------------------------------------------------------
# レポートを処理する
#-----------------------------------------------------------
sub report_control{

my($basic_init) = Mebius::basic_init();

	# 管理モードでないと実行できない
	if(!Mebius::Admin::admin_mode_judge()){
		main::error("You're not admin!");
	}

#my($report) = bbs_report_file({ BBS => 1 , ReportResFile => 1 , Control => 1 , Renew => 1 });

# 掲示板のスレッドを操作
Mebius::Admin::bbs_thread_control_multi_from_query();

# SNSの日記を操作
my($controled_sns_diary) = Mebius::SNS::Diary::query_to_control();

# SSS 後ほど修正 => 何を修正するんだっけ？
Mebius::Redirect("","$basic_init->{'admin_main_url'}?mode=report_view");

#HTMLヘッダ
#main::header({ BodyPrint => 1 });	

#HTMLフッタ
#main::footer({ BodyPrint => 1 });

exit;

}


#-----------------------------------------------------------
# １レス毎に依頼理由を選ぶかどうか
#-----------------------------------------------------------
sub select_reason_per_res_judge{
my($q) = Mebius::query_state();
	if($q->param('single_reason_report_mode')){ return 0; } else { return 1; }
}

#-----------------------------------------------------------
# 不適切な理由の選択ボックス
#-----------------------------------------------------------
sub improper_report_select_box{

my($kind) = improper_report_kind();
my($self);

	foreach(@$kind){

		foreach (@{$_->{'group'}}){
				$self .= qq(<label>);
				$self .= qq(<input type="radio" name="improter_report" value=").e($_->{'type'}).qq(">);
				$self .= qq(<span>);
				$self .= e($_->{'title'});
				$self .= qq(</span>);
				$self .= qq(</label>);

		}

	}

$self;

}
#-----------------------------------------------------------
# 不適切な報告の種類
#-----------------------------------------------------------
sub improper_report_kind{

my @self = (

{
	type => "" , 
	group => [
		{ type => "" , title => "未選択" } 
	]

},

{
	type => "detail" , 
	title => "詳細/依頼理由" , 
	group => [
		{ type => "" , title => "詳細不明" , guide => "詳細や依頼理由は、具体的に、明確に書いてください。" } , 
		{ type => "not_report" , title => "報告でない" , guide => "" } , 
		{ type => "" , title => "存在しないルール" , guide => "" } , 
		{ type => "small_or_big" , title => "程度問題" , guide => "" } , 
		{ type => "invalid_report" , title => "レポート中の違反" , guide => "" } 
	] , 
},

{
	type => "etc" , 
	title => "その他" , 
	group => [
		{ type => "cant_self_check" , title => "本人確認不可" , guide => "本人確認が出来ませんでした。" } , 
		{ type => "too_many_select_target" , title => "大量指定" , guide => "あまりに大量の報告をいちどに送ったり、違反が含まれていないものまで一度に報告しないでください。よく確認の上、違反度の高いものからご報告ください。" } , 
		{ type => "rooping" , title => "繰り返しの報告" , guide => "同じ報告を何度も繰り返さないでください。" } , 
	] , 
},

);

\@self;

}


1;
