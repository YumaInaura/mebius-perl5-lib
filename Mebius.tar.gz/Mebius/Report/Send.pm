
use strict;
use Mebius::BBS;
package Mebius::Report;

#-----------------------------------------------------------
# 報告送信時の、基本エラーチェック
#-----------------------------------------------------------
sub send_report_basic_error_check{

my(@error);
my $use = shift if(ref $_[0] eq "HASH");
my($q) = Mebius::query_state();
my($param) = Mebius::query_single_param();

# アクセス制限
main::axscheck("User-report-send");

	# ● Unique-char の判定
	if($q->param('char') eq "" || $q->param('char') !~ /^([a-zA-Z0-9]{20,})$/){
		push(@error,"送信に必要な情報が足りません。");
	}

	# ● レス報告用の各種チェック
	# ●ひとつも報告対象が選択されていない場合
	if(report_mode_judge_for_res()){
			# 複数選択モード
			if(select_reason_per_res_judge()){
				my($flag);
					foreach($q->param()){
						if($_ =~ /^report_(res|handle)_\d+$/ && $q->param($_) ne ""){
							$flag = 1;
						}
					}
					if(!$flag){
						push(@error,"報告対象がひとつも選ばれていません。");
					}
			# 単一選択モード
			} else {
				my($flag);
				my(@query) = $q->param('report_res');
					foreach($q->param('report_handle')){
						$flag = 1;
					}
					if(@query <= 0 && !$flag){
						push(@error,"報告対象がひとつも選ばれていません。");
					}
			}
	}

	# ● スレッド報告用の各種チェック
	if(report_mode_judge_for_thread()){

		my($kind_list_for_thread) = Mebius::Reason::kind_list_for_thread();

			# ▼ 違反タイプの判定
			if($q->param('report_reason') eq ""){
				push(@error,"違反タイプを選んでください。");
			}elsif($q->param('report_reason') !~ /^\d+$/){
				push(@error,"違反タイプが不正です。");
			}

			# 必須項目がない場合
			if($kind_list_for_thread->{$q->param('report_reason')}->{'MustRefererURL'} && $q->param('referer_url') eq ""){
				push(@error,"参考となるURLを入力してください。");
			}

	}

	# ●筆名のチェック
	{
		my(undef,$handle_error) = Mebius::Regist::name_check($param->{'name'});
			if(ref $handle_error eq "ARRAY"){
				push(@error,@$handle_error);
			}
	}

	# ●メールアドレスの書式チェック
	if($q->param('email')){	
		my($error) = Mebius::email_format_error_check($q->param('email'));
			if($error){
				push(@error,g_utf8($error));
			}
	}

	# ●依頼理由の判定 ( 単独理由の場合 )
	if(!select_reason_per_res_judge()){

			# 依頼理由が選択されていない場合
			if($q->param('report_reason') eq ""){
				push(@error,"依頼理由を選んで下さい。");

			# 依頼理由が不正な場合
			} else {
				my $justy_flag;
				my($kind_list) = Mebius::Reason::kind_list_for_res();
					foreach my $kind ( keys %$kind_list){
							foreach my $group ( @{$kind_list->{$kind}->{'group'}} ){
								if($q->param('report_reason') =~ /^$kind_list->{$kind}->{'type'}-$group->{'type'}$/){ $justy_flag = 1; }
							}
					}
					if(!$justy_flag){
						push(@error,"依頼理由が不正です。");
					}
			}

	}

	# ●詳細の判定
	{

		# 詳細の文字数判定
		{
			my $detail = $param->{'report_detail'};
			g_utf8($detail);
			$detail =~ s/(\s|　|\r|\n)//g;

				if(length($detail) < 5){
					push(@error,"詳細が短すぎます。");
				} elsif(length($detail) >= 10000){
					push(@error,"詳細が長過ぎます。");
				}
		}

	}

	# ●書式チェック
	if($param->{'referer_url'} && !Mebius::url_format_check($param->{'referer_url'})){
		push(@error,"参照スレッドのURLの書式が間違っています。");
	}

	# ●掲示板用のエラーチェック
	if(bbs_thread_judge() || sns_diary_judge()){

		my($thread);
			if(bbs_thread_judge()){
				($thread) = Mebius::BBS::thread_state($param->{'no'},$param->{'moto'});
			} elsif(sns_diary_judge()){
				($thread) = Mebius::SNS::Diary::thread_state($param->{'account'},$param->{'mode'});
			}

			# スレッドが存在するかどうかをチェック
			if(!$thread->{'f'}){ push(@error,"記事が存在しません。"); }

			# スレッドが削除済みの場合は、スレッドに対しては報告できない ( 予約削除中スレッドのレスは報告できるように )
			if(report_mode_judge_for_thread()){
					if($thread->{'deleted_flag'}){ push(@error,"既に削除済みの記事です。"); }
			}

			# 参照元のスレッド
			if($param->{'referer_url'}){

				# 参照元スレッドの状態を判定
				my($referer_thread) = Mebius::BBS::thread_url_to_thread_data($param->{'referer_url'});

					if(!$referer_thread->{'f'}){
						push(@error,qq(参照元のスレッド \( ).e($param->{'referer_url'}).qq( \) は存在しません。));
					} elsif($referer_thread->{'keylevel'} < 1){
						push(@error,"参照元のスレッド \( ).e($param->{'referer_url'}).qq( \) は現行スレッドではありません。");
					} elsif($referer_thread->{'bbs_kind'} eq $param->{'moto'} && $referer_thread->{'thread_number'} eq $param->{'no'}){
						push(@error,"同じスレッドは、参照元のスレッドとして報告出来ません。");
					} elsif($referer_thread->{'bbs_kind'} ne $param->{'moto'} && $param->{'report_reason'} eq "1"){
						push(@error,"他の掲示板のスレッドは、重複記事として報告出来ません。");
					} elsif($thread->{'res'} >= $referer_thread->{'res'} && $param->{'report_reason'} eq "1"){
						push(@error,"あなたが報告したスレッドは、参照スレッドより、レス数が多いです。");
					} elsif($thread->{'posttime'} < $referer_thread->{'posttime'} && $param->{'report_reason'} eq "1"){
						push(@error,"あなたが報告したスレッドは、参照スレッドより、昔に作られました。");
					}

			}

	}

@error;

}

#-----------------------------------------------------------
# 警告
#-----------------------------------------------------------
sub send_report_basic_alert_check{

my $use = shift if(ref $_[0] eq "HASH");
my($param) = Mebius::query_single_param();
my(@alert);
my $report_detail = $param->{'report_detail'};

# 文字コード
gq_utf8($report_detail);

	# ●掲示板用のエラーチェック
	if(bbs_thread_judge()){

		my($thread) = Mebius::BBS::thread_state($param->{'no'},$param->{'moto'});

			# ▼スレッド報告時の判定
			if(report_mode_judge_for_thread()){

					# 古いスレッドの場合は警告を出す
					if(time > $thread->{'posttime'} + 3*30*24*60*60){
						my($how_long_ago) = Mebius::second_to_howlong({ TopUnit => 1 } , time - $thread->{'posttime'});
						push(@alert,e($how_long_ago).qq(前に作られたスレッドです。時効となっている可能性がありますが、よろしいですか？));
					}

					# レスが多い場合は警告を出す
					if($thread->{'res'} >= 200){
						push(@alert,e($thread->{'res'}).qq(個のレスがあるスレッドです。時効となっている可能性がありますが、よろしいですか？));
					}
			}

	}

# 報告本文のキーワードチェック
push @alert,(alert_keyword_check($report_detail));


@alert;

}

#-----------------------------------------------------------
# アラートを出すキーワード
#-----------------------------------------------------------
sub alert_keyword_check{

my($report_detail) = @_;
my(@alert);

	# ネタバレ
	if($report_detail =~ /(ネタバレ)/){
			push(@alert,"「ネタバレ」はルール違反ではないため、基本的に削除されませんが、よろしいですか？");
	}

	# フレコ
	if($report_detail =~ /(フレコ|フレンド(コード|登録))/){
		push(@alert,"違反報告で「フレンドコード」を交換しようとしていませんか？　こちらに送信しても、フレンドコードは交換出来ません。");
	}

	# 投稿ミス
	if($report_detail =~ /(二重投稿|(投稿|送信)ミス|同じ内容|(間違)(.*)(投稿))/){
		push(@alert,"投稿ミスを報告しようとしていませんか？　投稿ミスは基本的に、放置するか、訂正投稿をするなどして対応してください。もし他の方に迷惑がかかっていたり、いちじるしくスレッド進行の邪魔になっている場合は、何をどのように書き間違ったのか、具体的に教えてください。");
	}

@alert;

}

#-----------------------------------------------------------
# 掲示板用の報告を送る
#-----------------------------------------------------------
sub send_report{

my($view_line);
my($q) = Mebius::query_state();
my($param) = Mebius::query_single_param();
my($thread,@BCL,$file_type);

	# 元記事をチェック
	if(bbs_thread_judge()){
		($thread) = Mebius::BBS::thread_state($param->{'no'},$param->{'moto'});
		my($subject_utf8) = utf8_return($thread->{'subject'});
		push(@BCL,q(<a href=").e($thread->{'url'}).q(">).e($subject_utf8).qq(</a>));
		$file_type = "bbs_thread";
	} elsif(sns_diary_judge()){
		$file_type = "sns_diary";
	}

push(@BCL,"報告の送信");

# 重複チェックなど
my($report) =  bbs_report_file({ file_type => $file_type ,  GetData => 1 } );
	if($report->{'unique_char'}->{$q->param('char')} && !Mebius::AlocalJudge()){ main::error("この報告は既に完了しています。ブラウザの「戻る」を使って報告を送ると、このエラーが出る場合があります。"); }

# レポート用のファイルを更新
bbs_report_file({ file_type => $file_type , Renew => 1 , NewLine => 1 } );

$view_line .= qq(<strong class="red">違反報告</strong>を送信しました！);

# Cookieをセット
Mebius::Cookie::set_main({ name => $q->param('name') , email => $q->param('email') });

# ヘッダ

main::header({ BodyPrint => 1 , Title => "報告の送信" , BCL => \@BCL , source => "utf8" , UTF8 => 1 });	

# 表示
print shift_jis($view_line);

# 振った
main::footer({ BodyPrint => 1 });

exit;

}


#-----------------------------------------------------------
# クエリを元に、ファイルに新しい行を追加
#-----------------------------------------------------------
sub add_new_line{

my $use = shift if(ref $_[0] eq "HASH");
my(@self,@query,%report,$new_report_type_res_or_thread);
my($q) = Mebius::query_state();
my($param) = Mebius::query_single_param();
my($my_connection) = Mebius::my_connection();
my($thread) = Mebius::BBS::thread_state($param->{'no'},$param->{'moto'});

# 筆名
my ($new_reporter_handle) = shift_jis(Mebius::Regist::name_check($param->{'name'}));
my ($new_reporter_trip) = main::trip($param->{'name'});
my $new_unique_number = $use->{'new_unique_number'};

	# ●クエリの展開方法 (レス)
	if(report_mode_judge_for_res()){

			# ▼複数選択モード
			if(select_reason_per_res_judge()){

					# すべてのクエリを展開
					foreach($q->param()){

						my($res_number,$report_type);

							# 特定のクエリ以外は、関係がないので無視して次の処理へ
							if($_ =~ /^report_(res|handle)_(\d+)$/){
								$report_type = $1;
								$res_number = $2;
							} else {
								next;
							}

							# 値が存在しない場合は、無視して次の処理へ
							if($q->param($_) eq ""){ next; }

							# 本文に対してのレポートの場合
							if($report_type eq "res" && !Mebius::BBS::comment_deleted_judge($thread->{'res_data'}->{$res_number})){
								($report{$res_number}{'main_reason'},$report{$res_number}{'sub_reason'}) = split(/-/,$q->param($_));
								$report{$res_number}{'comment_control_flag'} = 1;

							# 筆名に対してのレポートの場合
							} elsif ($report_type eq "handle") {
									if(!Mebius::BBS::handle_deleted_judge($thread->{'res_data'}->{$res_number})){
										$report{$res_number}{'handle_control_flag'} = 1;
									}
							}

					}

			# ▼単一選択モード
			} else {

					# 本文に対するレポートクエリを展開
					foreach my $res_number ($q->param('report_res')){
							if(!Mebius::BBS::comment_deleted_judge($thread->{'res_data'}->{$res_number})){
								($report{$res_number}{'main_reason'},$report{$res_number}{'sub_reason'}) = split(/-/,$q->param('report_reason'));
								$report{$res_number}{'comment_control_flag'} = 1;
							}
					}

					# 筆名に対するレポートクエリを展開
					foreach my $res_number ($q->param('report_handle')){
							if(!Mebius::BBS::handle_deleted_judge($thread->{'res_data'}->{$res_number})){
								$report{$res_number}{'handle_control_flag'} = 1;
							}
					}
			}

	# ● スレッド
	} elsif(report_mode_judge_for_thread()){
		$report{'0'} = { report_reason_for_thread => $q->param('report_reason') };
		$new_report_type_res_or_thread = "Thread";
	}

	# ●クエリを展開して、報告数分の行を増やす
	foreach my $res_number ( keys %report ){

		my(@renew_buffer_line,$targetA,$targetB,$targetC);

		# 各種代入
		my $new_category = Mebius::BBS::bbs_kind_to_category_kind($q->param('moto'));
		my $report_main_reason = $report{$res_number}->{'main_reason'};
		my $report_sub_reason = $report{$res_number}->{'sub_reason'};
		my $report_handle_check = "1" if($report{$res_number}->{'handle_control_flag'});
		my $report_reason_for_thread = $report{$res_number}->{'report_reason_for_thread'};

			# ターゲット
			if(bbs_thread_judge()){
				$targetA = $param->{'moto'};
				$targetB = $param->{'no'};
			} elsif(sns_diary_judge()){
				$targetA = $param->{'account'};

					if($param->{'mode'} =~ /^d-([0-9]+)/){
						$targetB = $1;
					}
			}

			# タイプが存在しない場合 … リストと対照させて不正チェックをおこないたい 
			#if($report_main_reason eq "" || $report_sub_reason eq ""){ next; }

		my $input_name = $param->{'name'};
		my(@data_seriese_9) = shift_jis(Mebius::data_seriese_9($input_name));
		my($new_report_detail) = Mebius::format_query_with_paragraph($param->{'report_detail'});

		# ユニーク番号を増やす
		$new_unique_number++;

		# 基本追加行
		push(@renew_buffer_line,
			"",
			Mebius::server_domain(),
			$new_unique_number, #通し番号 # $self{'report_count'}+1
			$param->{'char'},
			$new_category,
			$targetA,
			$targetB, 
			$targetC,
			$res_number,
			$new_report_type_res_or_thread,
			$report_reason_for_thread,
			$report_main_reason,
			$report_sub_reason,
			time,
			$new_report_detail,
			$param->{'referer_url'},
			my $new_referer_reses,
			my $report_self_check,
			$report_handle_check ,
			@data_seriese_9,
			$param->{'email'},
			"",
			"",
			"",
			"",
			"",
		);

		unshift(@self,Mebius::add_line_for_file_and_format(\@renew_buffer_line));

	}

\@self,$new_unique_number;

}


#-----------------------------------------------------------
# 報告モードかどうかを判定する ( 全体 )
#-----------------------------------------------------------
sub report_mode_judge{

my($q) = Mebius::query_state();
my($self);

	if(report_mode_judge_for_res() || report_mode_judge_for_thread()){
		$self = 1;
	}

}


#-----------------------------------------------------------
# 報告モードかどうかを判定する ( レス )
#-----------------------------------------------------------
sub report_mode_judge_for_res{

my($q) = Mebius::query_state();
my($self);

	if($q->param('report_mode') eq "res" || $q->param('report_mode_for_res')){
		$self = 1;
	}

}


#-----------------------------------------------------------
# 報告モードかどうかを判定する ( スレッド )
#-----------------------------------------------------------
sub report_mode_judge_for_thread{

my($q) = Mebius::query_state();
my($self);

	if($q->param('report_mode') eq "thread" || $q->param('report_mode_for_thread')){
		$self = 1;
	}

}


#-----------------------------------------------------------
# 報告を送っているかどうかを判定する
#-----------------------------------------------------------
sub send_report_judge{

my($q) = Mebius::query_state();
my($self);

	if($ENV{'REQUEST_METHOD'} eq "POST" && $q->param('send_report')){
		$self = 1;
	}

$self;

}

#-----------------------------------------------------------
# 報告 本送信チェック (レス)
#-----------------------------------------------------------
sub send_report_justy_judge{

my $use = shift if(ref $_[0] eq "HASH");
my($q) = Mebius::query_state();
my($param) = Mebius::query_single_param();
my($self);

	# そもそも送信モードでなければリターン
	if(!send_report_judge()){ return(); }

	# 投稿制限
	main::axscheck("User-report-send");

	# モード判定
	#if($use->{'ResMode'}){
	#		if(!report_mode_judge_for_res()){ return(); }
	#} elsif($use->{'ThreadMode'}){
	#		if(!report_mode_judge_for_thread()){ return(); }
	#} else{
	#	die("Perl Die! Plase select mode , Res or Thread.");
	#}

# 基本エラーチェック
my(@error) = send_report_basic_error_check();

# 基本エラーチェック
my(@alert) = send_report_basic_alert_check();

	# エラーでもプレビューでもなければ
	if(@error <= 0 && !$q->param('preview') && (@alert <= 0 || $param->{'break_alert'})){
		$self = 1;
	}

$self;

}

#-----------------------------------------------------------
# 掲示板スレッドへの報告であることを判定
#-----------------------------------------------------------
sub bbs_thread_judge{

my($flag);
my($param) = Mebius::query_single_param();

	if(Mebius::BBS::bbs_script_judge() && $param->{'mode'} eq "view" && $param->{'no'} =~ /^(\d+)$/){
		$flag = 1;
	}

$flag;

}


#-----------------------------------------------------------
# SNS への違反報告であることを判定
#-----------------------------------------------------------
sub sns_diary_judge{

my($flag);
my($param) = Mebius::query_single_param();

	if($ENV{'SCRIPT_NAME'} =~ m!/auth\.cgi$!){
		$flag = 1;
	}

$flag;

}

1;