
use strict;
package Mebius::Report;


1;
