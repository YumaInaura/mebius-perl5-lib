

use utf8;
use strict;
package Mebius::Ads;
use Mebius::Export;

#-----------------------------------------------------------
# オブジェクト関連付け
#-----------------------------------------------------------
sub new{

my $class = shift;
bless {} ,$class;

}

#-----------------------------------------------------------
# コードのコア部分
#-----------------------------------------------------------
sub code_core{

my $class = shift;
my $use = shift if(ref $_[0] eq "HASH");
my $select = shift;
my($self,$slot_number_smart,$comment_out_smart);

my $option =  {
	big_bunner => {
		slot_number => 7385702374 , comment_out => "general" , type => "big_bunner"
	} , 
	mobile_bunner => {
		slot_number => 6357659744 , comment_out => "general smart" , type => "mobile_bunner" 
	} , 

};

my $slot_number = $option->{$select}->{'slot_number'};
my $comment_out = $option->{$select}->{'comment_out'};
my $ad_type = $option->{$select}->{'type'};

	if(!$slot_number || !$comment_out || !$ad_type){
		die("Perl Die! Can't decide slot_number or comment_out_text or ad_type.");
	}

	{
		my($width,$height);

			if($ad_type eq "big_bunner"){
				$width = 728;
				$height = 90;
			} elsif($ad_type eq "mobile_bunner") {
				$width = 320;
				$height = 50;
			} else {
				die("Perl Die! Ad type is not in justy list. $ad_type");
			}

		$self .= qq(\n);
		$self .= qq(<script type="text/javascript"><!--\n);
		$self .= qq(google_ad_client = "ca-pub-7808967024392082";\n);
		$self .= qq(/* ).e($comment_out).qq( */\n);
		$self .= qq(google_ad_slot = ").e($slot_number).qq(";\n);
		$self .= qq(google_ad_width = ).e($width).qq(;\n);
		$self .= qq(google_ad_height = ).e($height).qq(;\n);
		$self .= qq(//-->\n);
		$self .= qq(</script>\n);
		$self .= qq(<script type="text/javascript"\n);
		$self .= qq(src="http://pagead2.googlesyndication.com/pagead/show_ads.js">\n);
		$self .= qq(</script>\n);

	}

$self;

}

#-----------------------------------------------------------
# 汎用バナー
#-----------------------------------------------------------
sub bunner{

my $class = shift;
my $use = shift if(ref $_[0] eq "HASH");
my($my_use_device) = Mebius::my_use_device();
my($self);

	if(Mebius::AlocalJudge()){
		($self) = big_bunner_dammy()
	} else {
			if($my_use_device->{'smart_flag'}){
				$self = code_core(undef,"mobile_bunner");
			} else {
				$self = code_core(undef,"big_bunner");
			}
	}

$self;

}
#-----------------------------------------------------------
# ビッグバナー ( ダミー )
#-----------------------------------------------------------
sub big_bunner_dammy{

my($my_use_device) = Mebius::my_use_device();
my($self);

	if($my_use_device->{'smart_flag'}){
		$self .= qq(<div style="width:320px;height:50px;border:solid 1px #000;margin:auto;">Ads</div>);
	} else {
		$self .= qq(<div style="width:728px;height:90px;border:solid 1px #000;margin:auto;">Ads</div>);

	}

}

1;
