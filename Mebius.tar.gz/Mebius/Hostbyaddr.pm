
use strict;
package Mebius::Host;

#-----------------------------------------------------------
# メインテーブル名
#-----------------------------------------------------------
sub main_table_name{
"addr_data";
}

#-----------------------------------------------------------
# 自分のリモートIPアドレスから、キャッシュされたホスト名情報を返す。データベースにレコードが存在しない場合は登録する。
#-----------------------------------------------------------
sub gethostbyaddr_cache{

my($main_table_name) = main_table_name() || die;
my($self);

	# IPアドレスが変な場合
	if(addr_format_error($ENV{'REMOTE_ADDR'})){
		return();
	}

# DBIからデータを取得
my($data,$result) = Mebius::DBI::fetchrow_hashref_on_arrayref_head("SELECT * from `$main_table_name` WHERE addr='$ENV{'REMOTE_ADDR'}'");

	# ●レコードが存在しない場合
	if(!$result){

		# 逆引き
		($self) = Mebius::get_host();

		my $insert = { addr => $ENV{'REMOTE_ADDR'} , host => $self , last_gethostbyaddr_time => time , last_update_time => time };

		# データベースに登録
		Mebius::DBI::insert(undef,$main_table_name,$insert,"addr");

	# ●レコードが存在しない or 前回の逆引きから一定時間経過している or 前回逆引きできずに、さらに一定時間経過している場合は、レコードを更新
	} elsif(time > $data->{'last_gethostbyaddr_time'} + 7*24*60*60 || ($data->{'host'} eq "" && $data->{'last_gethostbyaddr_time'} + 1*24*60*60)){

		# 逆引き
		($self) = Mebius::get_host();

		my $insert = { addr => $ENV{'REMOTE_ADDR'} , host => $self , last_gethostbyaddr_time => time , last_update_time => time };

		Mebius::DBI::update(undef,$main_table_name,$insert,"WHERE addr='$ENV{'REMOTE_ADDR'}'");

	# ●逆引きせずにキャッシュ（データベースの値）を使う場合
	} else {
		$self = $data->{'host'};
	}

$self;

}

#-----------------------------------------------------------
# マルチにデータを取得
#-----------------------------------------------------------
sub gethostbyaddr_cache_multi{

my($multi_host) = Mebius::GetHostMulti({ TypeByCache => 1 });

}


#-----------------------------------------------------------
# メインテーブルの作成
#-----------------------------------------------------------
sub create_main_table{

my($dbh) = Mebius::DBI::connect();
my($table_name) = main_table_name() || die;

$dbh->do("
CREATE TABLE IF NOT EXISTS `$table_name` 
	(
		`addr` char(20) NOT NULL PRIMARY KEY ,
		`host` char(100) default NULL , 
		`last_gethostbyaddr_time` int NOT NULL , 
		`last_update_time` int NOT NULL 
	)
ENGINE=MEMORY
;
");

}

#-----------------------------------------------------------
# IPアドレスの形式チェック
#-----------------------------------------------------------
sub addr_format_error{

my($addr) = @_;

	my($error) = Mebius::AddrFormat({ TypeReturnErrorFlag => 1 , Addr => $addr } );

$error;

}


1;

